from enum import Enum
import struct
import os
import time


# MAGIC值
# 文件头
MAGIC_EXPECTED = 0x42beef42
#exten_block
EXTENSION_MAGIC_EXPECTED = 0xAB12D34


#buffer的类型
class BufferType(Enum):
    UNDEFINED = 0
    NETWORK_INPUT = 1
    NETWORK_OUTPUT = 2
    INTERMEDIATE = 3
    COMMAND_STREAM = 4
    COEFFICIENTS = 5
    TEMPORARY = 6
    SOFTWARE = 7
    LOCAL = 8
    SHARED = 9
    INTERNAL_STATE = 10
    SOFTWARE_PARAMS = 11

def get_buffer_type_name(buffer_type):
    for member in BufferType:
        if member.value == buffer_type:
            return member.name
    return 'UNKNOWN'



class SegmentType(Enum):
    CNN = 0
    Scalar = 1
    HOST = 2
    CNN_MULTI = 3


class SegmentFlag(Enum):
    NONE = 0
    STANDARD = 1
    GET_STATE = 2
    SET_STATE = 4



class MemoryFormat:
    def __init__(self, value):
        self.value = value
        self.ZERO_POINT = (value >> 24) & 0xFF
        self.IS_Q8A = (value >> 23) & 0x1
        self.IS_FLOAT = (value >> 22) & 0x1
        self.IS_SIGNED = (value >> 16) & 0x1
        self.EXPONENT = (value >> 8) & 0xF
        self.PLANE_PACK = (value >> 4) & 0xF
        self.BITDEPTH = value & 0xF


class BufferFlags:
    def __init__(self, value):
        self.value = value
        self.BURST = (value >> 8) & 0xF
        self.ALIGNMENT = (value >> 4) & 0xF
        self.ORDER = value & 0xF




class MBSParser:
    def __init__(self, data):
        self.data = data
        self.index = 0

    #读取指定格式的数据
    def read(self, format_str):
        size = struct.calcsize(format_str)
        if self.index + size > len(self.data):
            raise ValueError("Insufficient data")
        value = struct.unpack_from(format_str, self.data, self.index)
        self.index += size
        return value[0] if len(value) == 1 else value

    #解析文件头
    def parse_header(self):
        header = {}
        header['magic'] = self.read('I')
        if header['magic'] != MAGIC_EXPECTED:
            raise ValueError("Invalid magic value")
        header['version'] = self.read('I')
        header['command_stream_flags'] = self.read('I')
        header['command_stream_flags'] = header['command_stream_flags'] & 0xF
        header['reserved_1'] = self.read('I')
        header['hw_capabilities_lo'] = self.read('I')
        header['hw_capabilities_hi'] = self.read('I')
        return header

    #解析模型的输入输出信息
    def parse_network_io_descriptor(self):
        descriptor = {}
        descriptor['size'] = self.read('I')
        descriptor['tensor_length'] = self.read('I')
        descriptor['tensor_value'] = self.read('I' * descriptor['tensor_length'])
        descriptor['format'] = self.read('I')
        descriptor['memory_format'] = MemoryFormat(descriptor['format'])
        if descriptor['memory_format'].IS_Q8A:
            descriptor['format_scale'] = self.read('I')
        else:
            descriptor['format_scale'] = None
        descriptor['buffer_strides_length'] = self.read('I')
        if descriptor['buffer_strides_length'] > 0:
            descriptor['buffer_strides_value'] = self.read('I' * descriptor['buffer_strides_length'])
        else:
            descriptor['buffer_strides_value'] = []
        descriptor['buffer_flags'] = self.read('I')
        descriptor['buffer_flags_obj'] = BufferFlags(descriptor['buffer_flags'])
        descriptor['name_length'] = self.read('I')
        if descriptor['name_length'] > 0:
            descriptor['name'] = self.data[self.index:self.index + descriptor['name_length']]
            self.index += descriptor['name_length']
            # 检查对齐情况  对齐到32
            remaining = (4 - (descriptor['name_length'] % 4)) % 4
            if remaining > 0:
                # 跳过填充的字节
                self.index += remaining
        else:
            descriptor['name'] = b''
        return descriptor

    #解析每个segment的输出信息
    def parse_segment_io_descriptor(self):
        descriptor = {}
        descriptor['buffer_id'] = self.read('I')
        descriptor['buffer_offset'] = self.read('I')
        descriptor['buffer_size'] = self.read('I')
        descriptor['memory_format'] = MemoryFormat(self.read('I'))
        if descriptor['memory_format'].IS_Q8A:
            descriptor['format_scale'] = self.read('I')
        else:
            descriptor['format_scale'] = None
        descriptor['buffer_strides_length'] = self.read('I')
        if descriptor['buffer_strides_length'] > 0:
            descriptor['buffer_strides_value'] = self.read('I' * descriptor['buffer_strides_length'])
        else:
            descriptor['buffer_strides_value'] = []
        descriptor['buffer_order'] = self.read('I')
        descriptor['tensor_length'] = self.read('I')
        descriptor['tensor_value'] = self.read('I' * descriptor['tensor_length'])
        descriptor['tensor_id'] = self.read('I')

        descriptor['tensor_name_length'] = self.read('I')
        if descriptor['tensor_name_length'] > 0:
            descriptor['tensor_name_length'] = self.data[self.index:self.index + descriptor['tensor_name_length']]
            self.index += descriptor['tensor_name_length']
            # 检查对齐情况  对齐到32
            remaining = (4 - (descriptor['tensor_name_length'] % 4)) % 4
            if remaining > 0:
                # 跳过填充的字节
                self.index += remaining
        else:
            descriptor['name'] = b''
        return descriptor


    #解析模型的buffer信息
    def parse_buffer_section(self):
        buffer = {}
        buffer['num_buffers'] = self.read('I')
        buffer['buffer_type'] = []
        buffer['buffer_size'] = []
        for _ in range(buffer['num_buffers']):
            buffer['buffer_type'].append(self.read('I'))
            buffer['buffer_size'].append(self.read('I'))
        return buffer

    #解析segmments的信息
    def parse_segment_section(self):
        segment = {}
        segment['num_segments']  =  self.read('I')
        segment['segment_id'] = self.read('I')
        segment_flag = self.read('H')
        segment_type = self.read('H')
        segment['segment_type'] = SegmentType(segment_type )
        segment['segment_flag'] = SegmentFlag(segment_flag )
        segment['segment_estimated_cycles'] = self.read('I')
        segment['inputs_count'] = self.read('I')
        segment['inputs'] = []
        for _ in range(segment['inputs_count']):
            input_desc = self.parse_segment_io_descriptor()
            segment['inputs'].append(input_desc)
        segment['outputs_count'] = self.read('I')
        segment['outputs'] = []
        for _ in range(segment['outputs_count']):
            output_desc = self.parse_segment_io_descriptor()
            segment['outputs'].append(output_desc)

        segment['page_size'] = self.read('I')
        segment['page_count'] = self.read('I')
        if segment['page_count'] > 0:
            segment['page_idx'] = self.read('I' * segment['page_count'])
        else:
            segment['page_idx'] = []

        segment['cnn_num_mapped_regions'] = self.read('I')
        segment['cnn_mapped_region_buffer_id'] = self.read('I' * segment['cnn_num_mapped_regions'] )

        segment['cnn_command_stream_size'] = self.read('I')
        segment['cnn_command_stream_id'] = self.read('I')
        segment['cnn_command_stream'] = self.read('I' * segment['cnn_command_stream_size'])
        segment['cnn_command_stream'] = "ignore"
        return segment

    #解析权重的数据
    def parse_coefficients_section(self):
        coefficients = {}
        self.index = self.index
        coefficients['coefficients_size'] = self.read('I')
        coefficients['coefficients_data'] = self.read('I' * coefficients['coefficients_size'])
        return coefficients

    #解析blobs的信息
    def parse_general_blobs_section(self):
        blobs = {}
        blobs['blob_size'] = self.read('I')
        blobs['blob_buffer_id'] = self.read('I')
        if blobs['blob_size'] > 0:
            blobs['data'] = self.data[self.index:self.index + blobs['blob_size']]
            self.index += blobs['blob_size']
            # 检查对齐情况  对齐到32
            remaining = (4 - (blobs['blob_size'] % 4)) % 4
            if remaining > 0:
                # 跳过填充的字节
                self.index += remaining
        else:
            blobs['data'] = b''
        return blobs


    #extension block 的数据
    def parse_extension_section(self):
        extension = {}
        extension['magic'] = self.read('I')
        if extension['magic'] != EXTENSION_MAGIC_EXPECTED:
            raise ValueError("Invalid extension magic value")
        extension['extension_count'] = self.read('I')
        for i in range(extension['extension_count'] ):
            sub_extension = {}
            word = self.read('I')
            sub_extension['block_size'] = (word >> 8) & 0x00FFFFFF  # 高24位
            sub_extension['block_type'] = word & 0x000000FF      # 低8位

            if sub_extension['block_size'] > 0:
                sub_extension['data_data'] = self.data[self.index:self.index + sub_extension['block_size']]
                self.index += sub_extension['block_size']
                # 检查对齐情况  对齐到32
                remaining = (4 - (sub_extension['block_size'] % 4)) % 4
                if remaining > 0:
                    # 跳过填充的字节
                    self.index += remaining
            else:
                sub_extension['data_data'] = b''
            extension["extension_" + str(i)] = sub_extension
        return extension



def main():
    file_path = 'mbs_model/cnngraph.mbs1.bin'
    with open(file_path, 'rb') as file:
        data = file.read()
        parser = MBSParser(data)

        header = parser.parse_header()
        print("Header:")
        print(f"    Magic: {header['magic']:08X}")
        print(f"    Version: {header['version']}")
        print(f"    Command Stream Flags: {header['command_stream_flags']}")
        print(f"    HW Capabilities Lo: {header['hw_capabilities_lo']:08X}")
        print(f"    HW Capabilities Hi: {header['hw_capabilities_hi']:08X}")


        #解析模型的输入输出信息
        inputs_count = struct.unpack_from('I', data, parser.index)[0]
        print(f"\nInputs Count: {inputs_count}")
        parser.index += struct.calcsize('I')
        for _ in range(inputs_count):
            input_desc = parser.parse_network_io_descriptor()
            print("\nInput Descriptor:")
            print(f"    Size: {input_desc['size']}")
            print(f"    Tensor Length: {input_desc['tensor_length']}")
            print(f"    Tensor Value: {input_desc['tensor_value']}")
            print(f"    Memory Format:")
            print(f"      Zero Point: {input_desc['memory_format'].ZERO_POINT}")
            print(f"      Is Q8A: {input_desc['memory_format'].IS_Q8A}")
            print(f"      Is Float: {input_desc['memory_format'].IS_FLOAT}")
            print(f"      Is Signed: {input_desc['memory_format'].IS_SIGNED}")
            print(f"      Exponent: {input_desc['memory_format'].EXPONENT}")
            print(f"      Plane Pack: {input_desc['memory_format'].PLANE_PACK}")
            print(f"      Bitdepth: {input_desc['memory_format'].BITDEPTH}")
            if input_desc['format_scale'] is not None:
                print(f"    Format Scale: {input_desc['format_scale']}")
            print(f"    Buffer Strides Length: {input_desc['buffer_strides_length']}")
            print(f"    Buffer Strides Value: {input_desc['buffer_strides_value']}")
            print(f"    Buffer Flags:")
            print(f"    Burst: {input_desc['buffer_flags_obj'].BURST}")
            print(f"    Alignment: {input_desc['buffer_flags_obj'].ALIGNMENT}")
            print(f"    Order: {input_desc['buffer_flags_obj'].ORDER}")
            print(f"    Name: {input_desc['name']!r}")

        outputs_count = struct.unpack_from('I', data, parser.index)[0]
        parser.index += struct.calcsize('I')
        for _ in range(outputs_count):
            outp_desc = parser.parse_network_io_descriptor()
            print("\nOutput Descriptor:")
            print(f"    Size: {outp_desc['size']}")
            print(f"    Tensor Length: {outp_desc['tensor_length']}")
            print(f"    Tensor Value: {outp_desc['tensor_value']}")
            print(f"    Memory Format:")
            print(f"      Zero Point: {outp_desc['memory_format'].ZERO_POINT}")
            print(f"      Is Q8A: {outp_desc['memory_format'].IS_Q8A}")
            print(f"      Is Float: {outp_desc['memory_format'].IS_FLOAT}")
            print(f"      Is Signed: {outp_desc['memory_format'].IS_SIGNED}")
            print(f"      Exponent: {outp_desc['memory_format'].EXPONENT}")
            print(f"      Plane Pack: {outp_desc['memory_format'].PLANE_PACK}")
            print(f"      Bitdepth: {outp_desc['memory_format'].BITDEPTH}")
            if outp_desc['format_scale'] is not None:
                print(f"    Format Scale: {outp_desc['format_scale']}")
            print(f"    Buffer Strides Length: {outp_desc['buffer_strides_length']}")
            print(f"    Buffer Strides Value: {outp_desc['buffer_strides_value']}")
            print(f"    Buffer Flags:")
            print(f"    Burst: {outp_desc['buffer_flags_obj'].BURST}")
            print(f"    Alignment: {outp_desc['buffer_flags_obj'].ALIGNMENT}")
            print(f"    Order: {outp_desc['buffer_flags_obj'].ORDER}")
            print(f"    Name: {outp_desc['name']!r}")

        num_brns = struct.unpack_from('I', data, parser.index)[0]
        print(f"\nbrns Count: {num_brns}")
        parser.index += struct.calcsize('I')
        brns = struct.unpack_from('I' * num_brns, data, parser.index)
        print(f"brns : {brns}")
        parser.index += struct.calcsize('I' * num_brns)


        print("\nBuffer info:")
        buffer = parser.parse_buffer_section()
        print(f"    num_buffers: {buffer['num_buffers']}")
        for _ in range(buffer['num_buffers']):
            print(f"    buffer_type: {get_buffer_type_name(buffer['buffer_type'][_])}")
            print(f"    buffer_size: {buffer['buffer_size'][_]}")



        segments = parser.parse_segment_section()
        print("\nsegments:")
        print(f"    num_segments: {segments['num_segments']}")
        print(f"    segment_id: {segments['segment_id']}")
        print(f"    segment_type: {segments['segment_type']}")
        print(f"    segment_flag: {segments['segment_flag']}")
        print(f"    segment_estimated_cycles: {segments['segment_estimated_cycles']}")
        print(f"    inputs_count: {segments['inputs_count']}")
        # print(f"    inputs: {segments['inputs']}")
        print(f"\n        buffer_id: {segments['inputs'][0]['buffer_id']}")
        print(f"        buffer_offset: {segments['inputs'][0]['buffer_offset']}")
        print(f"        buffer_size: {segments['inputs'][0]['buffer_size']}")
        print(f"        memory_format: {segments['inputs'][0]['memory_format']}")
        print(f"        format_scale: {segments['inputs'][0]['format_scale']}")
        print(f"        buffer_strides_length: {segments['inputs'][0]['buffer_strides_length']}")
        print(f"        buffer_strides_value: {segments['inputs'][0]['buffer_strides_value']}")
        print(f"        buffer_order: {segments['inputs'][0]['buffer_order']}")
        print(f"        tensor_length: {segments['inputs'][0]['tensor_length']}")
        print(f"        tensor_value: {segments['inputs'][0]['tensor_value']}")
        print(f"        tensor_id: {segments['inputs'][0]['tensor_id']}")

        print(f"\n    outputs_count: {segments['outputs_count']}")
        print(f"        buffer_id: {segments['outputs'][0]['buffer_id']}")
        print(f"        buffer_offset: {segments['outputs'][0]['buffer_offset']}")
        print(f"        buffer_size: {segments['outputs'][0]['buffer_size']}")
        print(f"        memory_format: {segments['outputs'][0]['memory_format']}")
        print(f"        format_scale: {segments['outputs'][0]['format_scale']}")
        print(f"        buffer_strides_length: {segments['outputs'][0]['buffer_strides_length']}")
        print(f"        buffer_strides_value: {segments['outputs'][0]['buffer_strides_value']}")
        print(f"        buffer_order: {segments['outputs'][0]['buffer_order']}")
        print(f"        tensor_length: {segments['outputs'][0]['tensor_length']}")
        print(f"        tensor_value: {segments['outputs'][0]['tensor_value']}")
        print(f"        tensor_id: {segments['outputs'][0]['tensor_id']}")


        print(f"    cnn_num_mapped_regions: {segments['cnn_num_mapped_regions']}")
        print(f"    cnn_mapped_region_buffer_id: {segments['cnn_mapped_region_buffer_id']}")
        print(f"    cnn_command_stream_size: {segments['cnn_command_stream_size']}")
        print(f"    cnn_command_stream_id: {segments['cnn_command_stream_id']}")
        print(f"    cnn_command_stream: {segments['cnn_command_stream']}")

        coeff = parser.parse_coefficients_section()
        print(coeff['coefficients_size'])

        extension = parser.parse_extension_section()
        print("Extension:")
        print(f"    magic: {extension['magic']:08X}")
        print(f"    extension_count: {extension['extension_count']}")
        for i in range(extension['extension_count']):
            extension_i = extension["extension_" + str(i)]
            print(f"    extension {i + 1} :")
            print(f"        extension block_size: {extension_i['block_size']}")
            print(f"        extension block_type: {extension_i['block_type']}")
            print(f"        extension data_data: {extension_i['data_data']}")
        exit()




#TODO 多个segments的模型
#TODO hardware segment + soft segments


if __name__ == "__main__":
    main()

