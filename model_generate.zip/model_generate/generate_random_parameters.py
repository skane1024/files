

from common1 import *
from operatorsv1 import *


print(random_input_dims4())
print(random_kernel())
print(random_stride())
print(random_padding())
print(random_dilition())



def generate_random_conv(num = 3000):
    case_count = 0
    while(1):
        input_shape = random_input_dims4()
        weight_shape = random_weight_dims4()
        stride  = random_stride()
        padding = random_padding()
        dilition = random_dilition()
        weight_shape[2] = input_shape[3]
        if np.prod(input_shape[2:] + weight_shape[0:2]) > 1024 * 1024 * 320 * 320:
            print("too big")
            continue
        try:
            create_conv_v1(input_shape,weight_shape,stride,padding,dilition, save_path = "./model/")
        except:
            print("error")
            pass
        case_count = case_count + 1
        if case_count >= num:
            break
        
        

def generate_random_depthwiseconv(num = 3000):
    case_count = 0
    while(1):
        input_shape = random_input_dims4()
        weight_shape = random_weight_dims4()
        stride  = random_stride()
        stride = stride[:1] * 4
        padding = random_padding()
        dilition = random_dilition()
        weight_shape[2] = input_shape[3]
        weight_shape[3] = random.choice([1,2,3,1,2,2,3,2,2,2,3,3,3,2,2,1,1,2,2,3,1,1,1,1,4,5])
        if np.prod(input_shape[2:] + weight_shape[0:2]) > 1024 * 1024 * 320 * 320:
            print("too big")
            continue
        try:
            #  [filter_height, filter_width, in_channels, channel_multiplier]
            # print(input_shape,weight_shape,stride,padding,dilition)
            create_depthwise_conv2d_v1(input_shape,weight_shape,stride,padding,dilition, save_path = "./model/")
        except:
            print("error")
            pass
        case_count = case_count + 1
        if case_count >= num:
            break


def generate_random_pool(num = 3000):
    case_count = 0
    while(1):
        input_shape = random_input_dims4()
        ksize = random_kernel()
        stride  = random_stride()
        padding = random_padding()
        if padding == "SAME" and stride[0] == 1:
            continue
        try:
            create_pool2d_v1(input_shape= input_shape, ksize = ksize, strides = stride, padding=padding,pool_type="maxpool",save_path = "./model/maxpool")
            create_pool2d_v1(input_shape= input_shape, ksize = ksize, strides = stride, padding=padding,pool_type="avgpool",save_path = "./model/avgpool")
        except:
            print("error")
            pass
        case_count = case_count + 1
        if case_count >= num:
            break



def generate_random_mean(num = 3000):
    case_count = 0
    while(1):
        input_shape = random_input_dims4()
        try:
            create_mean_v1(input_shape=input_shape,axis=(1,2),keepdims = True,save_path = "./model/mean/")
        except:
            print("error")
            pass
        case_count = case_count + 1
        if case_count >= num:
            break



def generate_random_transpose(num = 3000):
    case_count = 0
    while(1):
        input_shape = random_input_dims4()
        permute = [(0,3,2,1),(0,2,1,3),(0,3,2,1),(3,1,2,0)]
        permute_index = np.random.choice([0,1,2,3])
        try:
            create_transpose_v1(input_shape=input_shape,permute=permute[permute_index],save_path = "./model/transpose")  #变成了reshape //TODO
        except:
            print("error")
            pass
        case_count = case_count + 1
        if case_count >= num:
            break



def generate_random_depth_to_space(num = 3000):
    case_count = 0
    while(1):
        input_shape = random_input_dims4()
        block_size = random.choice([2,3,4,5])
        try:
            create_depth_to_space_v1(input_shape = input_shape, block_size = block_size,save_path = "./model/depth_to_space")
        except:
            print("error")
            pass
        case_count = case_count + 1
        if case_count >= num:
            break



def generate_random_space_to_depth(num = 3000):
    case_count = 0
    while(1):
        input_shape = random_input_dims4()
        block_size = random.choice([2,3,4,5])
        try:
            create_space_to_depth_v1(input_shape = input_shape, block_size = block_size, save_path = "./model/space_to_depth")
        except:
            print("error")
            pass
        case_count = case_count + 1
        if case_count >= num:
            break



def generate_random_space_to_batch_nd(num = 3000):
    case_count = 0
    while(1):
        input_shape = random_input_dims4()
        block_size = random.choice([2,3,4,5])
        try:
            create_space_to_batch_nd_v1(input_shape = input_shape,block_shape = [block_size,block_size],padding = [[0,0],[0,0]], save_path = "./model/space_to_batch_nd")
            input_shape = [input_shape[0] * block_size*block_size,input_shape[1]/block_size,input_shape[2]/block_size, input_shape[3]]
            create_batch_to_space_nd_v1(input_shape = input_shape,block_shape = [block_size,block_size],crops = [[0,0],[0,0]], save_path = "./model/batch_to_space_nd")
            
        except:
            print("error")
            pass
        case_count = case_count + 1
        if case_count >= num:
            break
     

def generate_random_activation(num = 3000):
    case_count = 0
    while(1):
        input_shape = random_input_dims4()
        try:
            create_activation_v1(input_shape = input_shape, activation_type="relu", save_path = "./model/activation")
            create_activation_v1(input_shape = input_shape, activation_type="relu6", save_path = "./model/activation")
            create_activation_v1(input_shape = input_shape, activation_type="logistic", save_path = "./model/activation")
            create_activation_v1(input_shape = input_shape, activation_type="tanh", save_path = "./model/activation")
        except:
            print("error")
            pass
        case_count = case_count + 1
        if case_count >= num:
            break



def generate_random_fc(num = 3000):
    case_count = 0
    while(1):
        input_shape = random_input_dims4()
        in_1 = input_shape[3]
        in_2 = input_shape[1]
        input_shape = random_input_dims4()
        in_3 = input_shape[3]
        try:
            create_fc_v1(input_shape=(in_1,in_2), filter=(in_2,in_3), bias_enable=True, save_path = "./model/fc/")
        except:
            print("error")
            pass
        case_count = case_count + 1
        if case_count >= num:
            break




def generate_random_binary(num = 3000):
    case_count = 0
    while(1):
        input_shape = random_input_dims4()
       
        try:
            create_binary_v1(input_shape,(input_shape[-1],), False, "add")
            create_binary_v1(input_shape,(input_shape[-1],), False, "sub")
            create_binary_v1(input_shape,(input_shape[-1],), False, "mul")
            create_binary_v1(input_shape,(input_shape[-1],), False, "maximum")
            create_binary_v1(input_shape,(input_shape[-1],), False, "minimum")
        except:
            print("error")
            pass
        case_count = case_count + 1
        if case_count >= num:
            break


# generate_random_fc(200)
# generate_random_mean(500)
# generate_random_transpose(300)
# generate_random_pool(300)


# generate_random_space_to_depth(num = 300)
# generate_random_depth_to_space(num = 300)
# generate_random_space_to_batch_nd(300)


# generate_random_conv(num = 50)
# generate_random_depthwiseconv(num = 50)
# 


generate_random_activation(300)

# generate_random_binary(30)