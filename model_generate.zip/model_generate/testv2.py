from  operators import *



# create_activation_v2(input_shape = (1,300,300,2), activation_type = "relu")
# create_activation_v2(input_shape = (1,300,300,2), activation_type = "tanh")
# create_activation_v2(input_shape = (1,300,300,2), activation_type = "logistic")
# create_activation_v2(input_shape = (1,300,300,2), activation_type = "softmax")
# # create_activation(input_shape = (1,300,300,2),activation_type = "hard_sigmoid")


# create_depth_to_space_v2(input_shape = [1,32,32,64], block_size = 4)
# create_space_to_depth_v2(input_shape = [1,32,32,64], block_size = 4)

# create_transpose_v2(input_shape=(1,32,32,3),permute=(1,2,0,3), save_path = "model/")

# create_reshape_v2(input_shape=(1,2,3,4),output_shape=(1,2,6,2))


# create_mean_v2(input_shape=(1,32,32,3),axis=(1,2),keepdims = True)



# create_avg_pool2d_v2(input_shape=(1,32,32,3),pool_size=(3,3),strides=(2,2), padding="VALID")
# create_max_pool2d_v2(input_shape=(1,32,32,3),pool_size=(3,3),strides=(2,2), padding="VALID")



# ##input   NCHW     filter   [O I H W]
# create_conv_v2(input_shape=(1,32,32,9),filter=(64,9,3,3),strides=[1,1],padding="VALID", 
#                use_bias = False, dilation_rate = [1,1], groups = 1, save_path="model/")



# create_depthwiseconv_v2(input_shape=(1,32,32,3),filter=(3,3),depth_multiplier = 12, strides=[1,1],padding="VALID", save_path="model/")


create_transposeconv_v2(input_shape=(1,32,32,12),filter=(64,12,3,3), strides=[1,1], padding="VALID", use_bias = False, dilation_rate = [1,1], save_path="model/")





# create_stride_slice_v2((1,32,32,3),[0,0,0,0],[1,20,20,3],[1,1,1,1])

# # create_split_v2(input_shape = [1,32,32,3],num_or_size_splits = 4, axis = 2)

# # create_concat_v2(input_shapes=((1,2,3,4),(1,2,3,4)), axis=2)




# create_pool2d_v2(input_shape=(1,32,32,3),pool_size=(3,3),strides=(2,2),padding="VALID",pool_type= "maxpool")
# create_pool2d_v2(input_shape=(1,32,32,3),pool_size=(3,3),strides=(2,2),padding="VALID",pool_type= "avgpool")




# create_binary_v2(input_shape1=(1,32,32,3), input_shape2=(1,32,32,3), input2_constant=False, binary_type="add")
# create_binary_v2(input_shape1=(1,32,32,3), input_shape2=(1,32,32,3), input2_constant=False, binary_type="sub")
# create_binary_v2(input_shape1=(1,32,32,3), input_shape2=(1,32,32,3), input2_constant=False, binary_type="mul")
# create_binary_v2(input_shape1=(1,32,32,3), input_shape2=(1,32,32,3), input2_constant=False, binary_type="maximum")
# create_binary_v2(input_shape1=(1,32,32,3), input_shape2=(1,32,32,3), input2_constant=False, binary_type="minimum")











    
    