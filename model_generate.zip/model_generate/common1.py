import os
import random
import numpy as np
import tensorflow as tf
tf.compat.v1.disable_eager_execution()



def freeze_graph(input_checkpoint, output_graph, output_node_names):
    saver = tf.compat.v1.train.import_meta_graph(input_checkpoint + '.meta', clear_devices=True)
    graph = tf.compat.v1.get_default_graph()  # 获得默认的图
    input_graph_def = graph.as_graph_def()  # 返回一个序列化的图代表当前的图
    with tf.compat.v1.Session() as sess:
        saver.restore(sess, input_checkpoint)  # 恢复图并得到数据
        output_graph_def = tf.compat.v1.graph_util.convert_variables_to_constants(  # 模型持久化，将变量值固定
            sess=sess,
            input_graph_def=input_graph_def,  # 等于:sess.graph_def
            output_node_names=output_node_names)  # 如果有多个输出节点，以逗号隔开

        with tf.compat.v1.gfile.GFile(output_graph, "wb") as f:  # 保存模型
            f.write(output_graph_def.SerializeToString())  # 序列化输出
        # print("%d ops in the final graph." % len(output_graph_def.node))  # 得到当前图有几个操作节点


def quantize(pb_model_path,input_shapes, input_names, output_names):
        # #quantizer
    input_tensor = {input_names[0]:input_shapes}
    converter = tf.compat.v1.lite.TFLiteConverter.from_frozen_graph(pb_model_path, input_names, output_names, input_tensor)
    converter.inference_input_type = tf.int8
    converter.inference_output_type = tf.int8
    converter.inference_type = tf.int8
    # 启用量化
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    # input_arrays = converter.get_input_arrays()
    # converter.quantized_input_stats = {input_arrays[0]: (0, 2),} # mean, std_dev  输入量化参数
    # converter.default_ranges_stats = (0, 128)
    def input_gen():
        for i in range(100):
            data = [np.random.uniform(-1,1,size=input_shapes).astype(np.float32)]
            yield data
    converter.representative_dataset = tf.lite.RepresentativeDataset(input_gen)
    tflite_uint8_model = converter.convert()
    tflite_name = pb_model_path.replace(".pb", ".tflite")
    open(tflite_name, "wb").write(tflite_uint8_model)
    print("quantize finish!")







def to_str(my_list):
    return '_'.join(str(x) for x in my_list)

def random_TF(true_probability = 0.5):
    N_values = [True, False]
    return np.random.choice(N_values, p=(true_probability, 1-true_probability))




def  random_Batch():
    # N_values = np.arange(1, 16)
    # N_probs = np.where(N_values <= 1, 0.72, N_values)  # 1的概率高一点  0.55
    # N_probs = np.where((N_probs > 1) & (N_probs <= 6), 0.08, N_probs)     # [2-6]的概率中等   0.3
    # N_probs = np.where(N_probs > 6, 0.02, N_probs)    #[7,16] 的概率第一点  0.15
    # N_probs /= N_probs.sum()  # 确保概率之和为1
    N_values = [1,2,3,4,5]
    N_probs =  [0.80,0.05,0.05,0.05,0.05]
    return np.random.choice(N_values, p=N_probs)



def random_channel():
    # input_channels  = np.arange(1, 1024)
    # N_probs = np.where(input_channels <= 400, 0.7, input_channels)  # [1-400]的概率高一点0.46
    # N_probs = np.where((N_probs <= 800) & (N_probs > 400), 0.5, N_probs)  # [400-800]的概率中等 0.33
    # N_probs = np.where(N_probs > 800, 0.55, N_probs)  # [800, 1024]的概率 低一点 0.18
    # N_probs /= N_probs.sum()  # 确保概率之和为1

    # #channel 偶数的概率更大
    # channel = np.random.choice(input_channels, p=N_probs)
    # if channel % 2 != 0:
    #     if random_TF(true_probability = 0.5) and channel > 32:
    #         channel = channel - 1
    channel = np.random.choice([1,3,5,9,12,16,18,20,22,32,64,126,256,64,32,16,16,3,3,16,32,24,192,192,160,320,300,240,
                                88,56,32,32,224,36,12,20,80,98,120])
    return channel



def random_H_W():
    # input_HW  = np.arange(1, 2048)
    # N_probs = np.where(input_HW <= 800, 0.92, input_HW)  # [1-800]的概率高一点   0.50
    # N_probs = np.where((N_probs <= 1600) & (N_probs > 800), 0.63, N_probs)  # [800-1600]的概率中等  0.33
    # N_probs = np.where(N_probs > 1600, 0.51, N_probs)  # [1600，2048]的概率第一点   0.14
    # N_probs /= N_probs.sum()  # 确保概率之和为1

    # # H W相等的概率大一些 1/5的概率
    # if np.random.randint(1,11) % 4 == 0:
    #     input_H_W_data = [np.random.choice(input_HW, p=N_probs),] * 2
    # else:
    #     input_H_W_data = [np.random.choice(input_HW, p=N_probs), np.random.choice(input_HW, p=N_probs)]
    input_HW = ([14,14],[32,32],[64,64],[80,80],[120,120],[128,128],[160,160],[180,180],[182,182],[196,196],[200,200],
                [220,220],[230,230],[240,240],[256,256],[268,268],[280,280],[300,300],[320,320],[360,360],[380,380],[400,400],
                [420,420],[460,460],[480,480],[500,500],[520,520],[600,600],[640,640],[800,800],[1000,1000],[1024,1024],[1200,1200],
                [64,320],[64,160],[64,520],[128,1024],[128,800],[128,480],[256,1200],[256,800],[256,640],[256,480],[320,1024],[520,1200],
                [520,680],[640,1200],[640,320],[640,256],[640,128],[640,64],[820,1200],[820,640],[820,560],[820,480],[820,320],[820,160],
                [1024,640],[1024,320],[1024,160],[1024,280],[1024,120],[1200,320],[128,128],[256,256],[480,480],[500,500],[420,420],[360,360],
                [280,280],[256,256],[280,280],[120,64],[160,80],[320,160],[168,168],[172,172],[182,182],[190,190],[156,156],[172,172],[192,192],
                [128,144],[144,144],[158,158],[232,232],[300,300],[308,308],[420,410],[123,123],[142,142],[166,166],[168,168],[172,172],[178,178],
                [182,282],[232,232],[244,244],[246,246],[342,342],[190,190],[156,156],[98,98],[108,108],[340,340],[346,346],[388,388],[396,396],
                [402,402],[410,410],[426,426],[434,434],[444,444],[450,450],[380,420],[250,260],[360,420]
                )

    return input_HW[np.random.choice([i for i in range(len(input_HW))])]



def random_kernel():
    #从统计来看,1,3,5 的概率大一些
    kernel_HW  = [1,    2,    3,    4,    5,   6,    7,    8,    9]
    N_probs =    [0.28, 0.28, 0.28, 0.02, 0.1, 0.01, 0.01, 0.01, 0.01]
    #hw  相等的概率大很多
    if random_TF(true_probability = 0.98):
        kernel_H_W_data = [np.random.choice(kernel_HW ,p=N_probs),] * 2
    else:
        kernel_H_W_data = [np.random.choice(kernel_HW, p=N_probs),
                           np.random.choice(kernel_HW, p=N_probs)]
    return kernel_H_W_data


def random_stride():
    stride_HW  = [1,2,3,4,5]
    #从统计来看,值一般都比较小
    N_probs = [0.25,0.23,0.2,0.17,0.15]
    #stride h w  相等的概率大一些
    if random_TF(true_probability = 0.95):
        stride_H_W_data = [np.random.choice(stride_HW, p=N_probs),] * 2
    else:
        stride_H_W_data = [np.random.choice(stride_HW, p=N_probs),
                           np.random.choice(stride_HW, p=N_probs)]
    return stride_H_W_data



def random_dilition():
    stride_HW  = [1,2,3,4,5]
    #从统计来看,值一般都比较小
    N_probs = [0.9,0.07,0.01,0.01,0.01]
    #stride h w  相等的概率大一些
    if random_TF(true_probability = 0.95):
        stride_H_W_data = [np.random.choice(stride_HW, p=N_probs),] * 2
    else:
        stride_H_W_data = [np.random.choice(stride_HW, p=N_probs),
                           np.random.choice(stride_HW, p=N_probs)]
    return stride_H_W_data





def  random_scale():
    #for resize
    N_values = [2,3,4,5]
    N_probs =  [0.45,0.3,0.15,0.1]
    return np.random.choice(N_values, p=N_probs)



def random_padding():
    # 大约0.1%超过了 5
    padding_HW  = np.arange(0, 5)
    #padding比较小的值概率更大
    N_probs = [0.26, 0.21, 0.16, 0.14, 0.13, 0.1]
    #hw  相等的概率大一些
    if random_TF(true_probability = 0.48):
        padding_H_W_data = [np.random.choice(padding_HW),] * 2
    else:
        padding_H_W_data = [np.random.choice(padding_HW), np.random.choice(padding_HW)]
    # return padding_H_W_data
    return np.random.choice(["SAME","VALID"])



#生成二维的随机数据
def random_data_dims1():
    input_size  = np.arange(1, 1024*6)
    N_probs = np.where(input_size <= 1024, 0.98, input_size)  # [1-1024]的概率高一点
    N_probs = np.where((N_probs <= 1024*3) & (N_probs > 1024), 0.78, N_probs)  # [1024-1024 * 3]的概率中等
    N_probs = np.where(N_probs > 1024*3, 0.48, N_probs)  # [1024 * 3]的概率第一点
    N_probs /= N_probs.sum()  # 确保概率之和为1
    while True:
        input_1 = np.random.choice(input_size, p=N_probs)
        # 一般不会出现所有的数据都比较大的情况( 可以包含一些)
        return (input_1,)


#生成二维的随机数据   两种情况
#size <= 2048 * 2048  （4,194,304） &&  dims_1 < 2048    dims_2<2048 
#or size  < 1024 * 32
def random_data_dims2():
    if random_TF(true_probability = 0.3):
        while True:
            # 生成一个较大和一个较小的随机数
            input_1 = random.randint(1, 32)
            input_2 = random.randint(2048, 1024*32)
            if input_1 * input_2 >1024 * 32:
                continue
            if random_TF(true_probability = 0.5):
                return (input_1,input_2)
            else:
                return (input_2,input_1)
                
    input_size  = np.arange(1, 1024*4)
    N_probs = np.where(input_size <= 1024, 0.98, input_size)  # [1-1024]的概率高一点
    N_probs = np.where((N_probs <= 1024*2) & (N_probs > 1024), 0.78, N_probs)  # [1024-2048]的概率中等
    N_probs = np.where(N_probs > 1024*2, 0.48, N_probs)  # []的概率第一点
    N_probs /= N_probs.sum()  # 确保概率之和为1
    while True:
        input_1 = np.random.choice(input_size, p=N_probs)
        input_2 = np.random.choice(input_size, p=N_probs)
        #整体的数据输入不应该太大
        if input_1 * input_2 > 2048 * 2048:
            continue
        # 一般不会出现所有的数据都比较大的情况( 可以包含一些)
        return (input_1,input_2)




#生成三维的随机数据
def random_data_dims3():
    input_size  = np.arange(1, 1024*4)
    N_probs = np.where(input_size <= 1024, 0.98, input_size)  # [1-1024]的概率高一点
    N_probs = np.where((N_probs <= 1024*2) & (N_probs > 1024), 0.78, N_probs)  # [1024-2048]的概率中等
    N_probs = np.where(N_probs > 1024*2, 0.48, N_probs)  # []的概率第一点
    N_probs /= N_probs.sum()  # 确保概率之和为1
    while True:
        input_1 = np.random.choice(input_size, p=N_probs)
        input_2 = np.random.choice(input_size, p=N_probs)
        input_3 = np.random.choice(input_size, p=N_probs)
        #任意两个都不应该太大
        if  input_1 * input_2 > 2048*2048 or input_2 * input_3 > 2048*2048 or input_1 * input_3 > 2048*2048:
            continue

        #整体的数据输入不应该太大
        if input_1 * input_2 * input_3> 2048 * 2048 * 4:
            continue
        # 一般不会出现所有的数据都比较大的情况( 可以包含一些)
        return (input_1,input_2,input_3)



#生成四维的随机输入数据(NCHW)
def random_input_dims4():
    while True:
        input_H,input_W = random_H_W()
        input_channel = random_channel()
        batch = random_Batch()
        #整体的数据输入不应该太大
        if batch*input_channel*input_H*input_W > 1024 * 1024 * 32:
            continue
        #一般来讲channel的时候，Ｈ和Ｗ会小一些，不会都很大
        if input_channel  > 800 and (input_H > 1024 or input_W > 1024):
            if random_TF(true_probability = 0.40): #40% 的概率丢弃
                continue
        return [batch,input_H,input_W,input_channel]




#生成四维的权重
def random_weight_dims4():
    # OIHW
    while True:
        input_channel = random_channel()
        output_channel = random_channel()
        kernel_h,kernel_w = random_kernel()
        weight_shape = [kernel_h,kernel_w, input_channel, output_channel,]
        #一般来讲channel大的时候, kernel_h,kernel_w 要小一些
        if input_channel + output_channel > 1024 and kernel_h*kernel_w > 9:
            if random_TF(true_probability = 0.35): #35% 的概率丢弃
                continue
        if  np.prod(weight_shape) > 1024 * 1024 * 9:
            continue
        return weight_shape








def freeze_graph(input_checkpoint, output_graph, output_node_names):
    saver = tf.compat.v1.train.import_meta_graph(input_checkpoint + '.meta', clear_devices=True)
    graph = tf.compat.v1.get_default_graph()  # 获得默认的图
    input_graph_def = graph.as_graph_def()  # 返回一个序列化的图代表当前的图
    with tf.compat.v1.Session() as sess:
        saver.restore(sess, input_checkpoint)  # 恢复图并得到数据
        output_graph_def = tf.compat.v1.graph_util.convert_variables_to_constants(  # 模型持久化，将变量值固定
            sess=sess,
            input_graph_def=input_graph_def,  # 等于:sess.graph_def
            output_node_names=output_node_names)  # 如果有多个输出节点，以逗号隔开

        with tf.compat.v1.gfile.GFile(output_graph, "wb") as f:  # 保存模型
            f.write(output_graph_def.SerializeToString())  # 序列化输出
        # print("%d ops in the final graph." % len(output_graph_def.node))  # 得到当前图有几个操作节点




def quantize(pb_model_path,input_shapes, input_names, output_names):
        # #quantizer
    input_tensor = {input_names[i]:input_shapes[i] for i in range(len(input_names))}
    converter = tf.compat.v1.lite.TFLiteConverter.from_frozen_graph(pb_model_path, input_names, output_names, input_tensor)
    converter.inference_input_type = tf.int8
    converter.inference_output_type = tf.int8
    converter.inference_type = tf.int8
    # 启用量化
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    # input_arrays = converter.get_input_arrays()
    # converter.quantized_input_stats = {input_arrays[0]: (0, 2),} # mean, std_dev  输入量化参数
    # converter.default_ranges_stats = (0, 128)
    def input_gen():
        for i in range(50):
            data = []
            for i in range(len(input_shapes)):
                data.append(np.random.uniform(-1,1,size=input_shapes[i]).astype(np.float32))
            yield data
    converter.representative_dataset = tf.lite.RepresentativeDataset(input_gen)
    tflite_uint8_model = converter.convert()
    tflite_name = pb_model_path.replace(".pb", ".tflite")
    open(tflite_name, "wb").write(tflite_uint8_model)
    os.remove(pb_model_path.replace(".pb",".meta"))
    os.remove(pb_model_path.replace(".pb",".index"))
    os.remove(pb_model_path.replace(".pb",".pb"))
    os.remove(pb_model_path.replace(".pb",".data-00000-of-00001"))
    os.remove(os.path.join(os.path.dirname(pb_model_path),"checkpoint"))
    print("quantize finish!")



def quant_model_v2(model_path, input_shape):
    #生成校准数据 默认范围[-1,1]  随机数
    # 支支持keras模型
    def input_gen():
        for i in range(50):
            data = [np.random.uniform(-1,1,size=input_shape).astype(np.float32)]
            yield data
    model = tf.keras.models.load_model(model_path, compile=False)
    # Converting a tf.Keras model to a TensorFlow Lite model.
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations = [tf.lite.Optimize.OPTIMIZE_FOR_SIZE]
    # converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    converter.inference_input_type = tf.int8   #输入类型
    converter.inference_output_type = tf.int8  # 输出类型
    converter.representative_dataset = tf.lite.RepresentativeDataset(input_gen)
    tflite_model = converter.convert()

    save_model_name = model_path.replace(".h5", ".tflite")
    os.remove(model_path)
    # Save the TF Lite model.
    with tf.io.gfile.GFile(save_model_name, 'wb') as f:
        f.write(tflite_model)