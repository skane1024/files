
#!usr/bin/env python
# -*- coding:utf-8 _*-
"""
# author:yongkang.shu
# time:
"""

import uuid
import time
import shutil
from werkzeug.utils import secure_filename
# from flask_socketio import SocketIO, emit
from flask import Flask, render_template, request,  json, redirect, url_for,jsonify,Blueprint,session
from config import *

from model_generate.operatorsv1 import *
from model_generate.operatorsv2 import *



model_generate = Blueprint('model_generate', __name__, url_prefix="/model_generate", template_folder="templates", static_folder="static")




@model_generate.route('/', methods=['GET'])
def modelGenerate():
    if session.get("name") == None:
            session["name"] = str(uuid.uuid4().hex)[:6]
    return render_template('model_generate.html',name= session["name"])




@model_generate.route('/activation', methods=['GET', 'POST'])
def activation():
    if request.method == 'GET':
        if session.get("name") == None:
            session["name"] = str(uuid.uuid4().hex)[:6]
        return render_template('activation.html',name= session["name"])
    else:
        name = session["name"]
        form_data = request.form
        request_data = dict(form_data)
        if request_data is None:
            return {'message': "post data is null!. ",'code': 400},400

        input_shape = eval(request_data["input_shape"])
        activation_type = request_data["activation_type"]
        model_type = request_data["model_type"]
        
        save_path = os.path.join("model_generate/static/temp_model/", session["name"])
        if os.path.exists(save_path):
            shutil.rmtree(save_path)
        os.mkdir(save_path)
        
        
        if model_type == "tflite":
            model_path = create_activation_v2(input_shape, activation_type, save_path = save_path)
            
        
        file_download_url = url_for('static', filename=model_path)
        
        print(file_download_url)
        data_json = {'status': "success","file_download_url": file_download_url}
        socketio.emit(name, {'data': "文件生成成功", 'progress': "100%"})
        return json.dumps(data_json, ensure_ascii=False), 200
        
        



@model_generate.route('/binary', methods=['GET', 'POST'])
def binary():
    if request.method == 'GET':
        if session.get("name") == None:
            session["name"] = str(uuid.uuid4().hex)[:6]
        return render_template('binary.html',name= session["name"])
    else:
        name = session["name"]
        form_data = request.form
        request_data = dict(form_data)
        print(request_data)
        if request_data is None:
            return {'message': "post data is null!. ",'code': 400},400
        
        
        input1_shape = eval(request_data["input1_shape"])
        input2_shape = eval(request_data["input2_shape"])
        input2_constant =  True if request_data["input2_constant"] == "true" else False
        
        binary_type = request_data["binary_type"]
        model_type = request_data["model_type"]
        
        save_path = os.path.join("model_generate/static/temp_model/", session["name"])
        if os.path.exists(save_path):
            shutil.rmtree(save_path)
        os.mkdir(save_path)
        
        if model_type == "tflite":
            model_path = create_binary_v1(input1_shape,input2_shape, input2_constant, binary_type, save_path =save_path)
        file_download_url = url_for('static', filename=model_path)
        
        data_json = {'status': "success","file_download_url": file_download_url}
        socketio.emit(name, {'data': "文件生成成功", 'progress': "100%"})
        return json.dumps(data_json, ensure_ascii=False), 200
        
        
    
    
    
@model_generate.route('/stride_slice', methods=['GET', 'POST'])
def stride_slice():
    if request.method == 'GET':
        if session.get("name") == None:
            session["name"] = str(uuid.uuid4().hex)[:6]
        return render_template('stride_slice.html',name= session["name"])
    else:
        name = session["name"]
        form_data = request.form
        request_data = dict(form_data)
        if request_data is None:
            return {'message': "post data is null!. ",'code': 400},400
        
        
        input_shape = eval(request_data["input_shape"])
        begin = eval(request_data["begin"])
        end = eval(request_data["end"])
        stride = eval(request_data["stride"])
        
        model_type = request_data["model_type"]
        

        save_path = os.path.join("model_generate/static/temp_model/", session["name"])
        if os.path.exists(save_path):
            shutil.rmtree(save_path)
        os.mkdir(save_path)
        
        if model_type == "tflite":
            model_path = create_stride_slice_v1(input_shape, begin, end, stride, save_path = save_path)
        file_download_url = url_for('static', filename=model_path)
        
        data_json = {'status': "success","file_download_url": file_download_url}
        socketio.emit(name, {'data': "文件生成成功", 'progress': "100%"})
        return json.dumps(data_json, ensure_ascii=False), 200
    
    


        
@model_generate.route('/batch_to_space_nd', methods=['GET', 'POST'])
def batch_to_space_nd():
    if request.method == 'GET':
        if session.get("name") == None:
            session["name"] = str(uuid.uuid4().hex)[:6]
        return render_template('batch_to_space_nd.html',name= session["name"])
    else:
        name = session["name"]
        form_data = request.form
        request_data = dict(form_data)
        if request_data is None:
            return {'message': "post data is null!. ",'code': 400},400
        
        input_shape = eval(request_data["input_shape"])
        block_shape = eval(request_data["block_shape"])
        crops = eval(request_data["block_shape"])
        model_type = request_data["model_type"]
    
        save_path = os.path.join("model_generate/static/temp_model/", session["name"])
        if os.path.exists(save_path):
            shutil.rmtree(save_path)
        os.mkdir(save_path)
        
        if model_type == "tflite":
            model_path = create_batch_to_space_nd_v1(input_shape,block_shape,crops, save_path = save_path)
        file_download_url = url_for('static', filename=model_path)
        
        data_json = {'status': "success","file_download_url": file_download_url}
        socketio.emit(name, {'data': "文件生成成功", 'progress': "100%"})
        return json.dumps(data_json, ensure_ascii=False), 200 
        
        
    

@model_generate.route('/reshape', methods=['GET','POST'])
def reshape():
    if request.method == 'GET':
        if session.get("name") == None:
            session["name"] = str(uuid.uuid4().hex)[:6]
        return render_template('reshape.html',name= session["name"])
    else:
        name = session["name"]
        form_data = request.form
        request_data = dict(form_data)
        if request_data is None:
            return {'message': "post data is null!. ",'code': 400},400
        
        
        
        input_shape = eval(request_data["input_shape"])
        target_shape = eval(request_data["target_shape"])
        model_type = request_data["model_type"]
    
        save_path = os.path.join("model_generate/static/temp_model/", session["name"])
        if os.path.exists(save_path):
            shutil.rmtree(save_path)
        os.mkdir(save_path)
        
        if model_type == "tflite":
            model_path = create_reshape_v1(input_shape = input_shape, output_shape = target_shape, save_path = save_path)
        file_download_url = url_for('static', filename=model_path)
        
        data_json = {'status': "success","file_download_url": file_download_url}
        socketio.emit(name, {'data': "文件生成成功", 'progress': "100%"})
        return json.dumps(data_json, ensure_ascii=False), 200 
    
        


@model_generate.route('/transpose', methods=['GET','POST'])
def transpose():
    if request.method == 'GET':
        if session.get("name") == None:
            session["name"] = str(uuid.uuid4().hex)[:6]
        return render_template('transpose.html',name= session["name"])
    else:
        name = session["name"]
        form_data = request.form
        request_data = dict(form_data)
        if request_data is None:
            return {'message': "post data is null!. ",'code': 400},400
        
    
        input_shape = eval(request_data["input_shape"])
        perm = eval(request_data["perm"])
        model_type = request_data["model_type"]
    
        save_path = os.path.join("model_generate/static/temp_model/", session["name"])
        if os.path.exists(save_path):
            shutil.rmtree(save_path)
        os.mkdir(save_path)
        
        if model_type == "tflite":
            model_path = create_transpose_v1(input_shape = input_shape, permute = perm, save_path = save_path)
        file_download_url = url_for('static', filename=model_path)
        
        data_json = {'status': "success","file_download_url": file_download_url}
        socketio.emit(name, {'data': "文件生成成功", 'progress': "100%"})
        return json.dumps(data_json, ensure_ascii=False), 200 
        

        
        
    
@model_generate.route('/mean', methods=['GET','POST'])
def mean():
    if request.method == 'GET':
        if session.get("name") == None:
            session["name"] = str(uuid.uuid4().hex)[:6]
        return render_template('mean.html',name= session["name"])
    else:
        name = session["name"]
        form_data = request.form
        request_data = dict(form_data)
        if request_data is None:
            return {'message': "post data is null!. ",'code': 400},400
        
        input_shape = eval(request_data["input_shape"])
        axis = eval(request_data["axis"])
        keep_dims =  True if request_data["keep_dims"] == "true" else False
        model_type = request_data["model_type"]
    
        save_path = os.path.join("model_generate/static/temp_model/", session["name"])
        if os.path.exists(save_path):
            shutil.rmtree(save_path)
        os.mkdir(save_path)
        
        if model_type == "tflite":
            model_path = create_mean_v1(input_shape = input_shape, axis = axis, keepdims=keep_dims, save_path = save_path)
        file_download_url = url_for('static', filename=model_path)
        
        data_json = {'status': "success","file_download_url": file_download_url}
        socketio.emit(name, {'data': "文件生成成功", 'progress': "100%"})
        return json.dumps(data_json, ensure_ascii=False), 200 
      
        


    
@model_generate.route('/pool', methods=['GET','POST'])
def pool():
    if request.method == 'GET':
        if session.get("name") == None:
            session["name"] = str(uuid.uuid4().hex)[:6]
        return render_template('pool.html',name= session["name"])
    else:
        name = session["name"]
        form_data = request.form
        request_data = dict(form_data)
        if request_data is None:
            return {'message': "post data is null!. ",'code': 400},400
        
        input_shape = eval(request_data["input_shape"])
        ksize = eval(request_data["kernel"])
        strides =  eval(request_data["strides"])
        padding =  request_data["padding"]
        pool_type = request_data["pool_type"]
        model_type = request_data["model_type"]
        
        save_path = os.path.join("model_generate/static/temp_model/", session["name"])
        if os.path.exists(save_path):
            shutil.rmtree(save_path)
        os.mkdir(save_path)
        
        if model_type == "tflite":
            model_path = create_pool2d_v1(input_shape,ksize,strides,padding,pool_type, save_path = save_path)
        file_download_url = url_for('static', filename=model_path)
        
        data_json = {'status': "success","file_download_url": file_download_url}
        socketio.emit(name, {'data': "文件生成成功", 'progress': "100%"})
        return json.dumps(data_json, ensure_ascii=False), 200 
    



@model_generate.route('/fc', methods=['GET','POST'])
def fc():
    if request.method == 'GET':
        if session.get("name") == None:
            session["name"] = str(uuid.uuid4().hex)[:6]
        return render_template('fc.html',name= session["name"])
    else:
        name = session["name"]
        form_data = request.form
        request_data = dict(form_data)
        if request_data is None:
            return {'message': "post data is null!. ",'code': 400},400
        
        
        input_shape = eval(request_data["input_shape"])
        weight_shape = eval(request_data["weight_shape"])
        bias  = True if request_data["bias"] == "true" else False
        model_type = request_data["model_type"]
        
        save_path = os.path.join("model_generate/static/temp_model/", session["name"])
        if os.path.exists(save_path):
            shutil.rmtree(save_path)
        os.mkdir(save_path)
        
        if model_type == "tflite":
            model_path = create_fc_v1(input_shape, filter = weight_shape, bias_enable=bias,save_path = save_path)
        file_download_url = url_for('static', filename=model_path)
        
        data_json = {'status': "success","file_download_url": file_download_url}
        socketio.emit(name, {'data': "文件生成成功", 'progress': "100%"})
        return json.dumps(data_json, ensure_ascii=False), 200 
        
        

@model_generate.route('/conv', methods=['GET', 'POST'])
def conv():
    if request.method == 'GET':
        if session.get("name") == None:
            session["name"] = str(uuid.uuid4().hex)[:6]
        return render_template('conv.html',name= session["name"])
    else:
        name = session["name"]
        form_data = request.form
        request_data = dict(form_data)
        if request_data is None:
            return {'message': "post data is null!. ",'code': 400},400
        
        input_shape = eval(request_data["input_shape"])
        output_c = int(request_data["output_c"])
        ksize = eval(request_data["kernel"])
        strides =  eval(request_data["strides"])
        dilations =  eval(request_data["dilations"])
        bias  = True if request_data["bias"] == "true" else False
        group = int(request_data["group"])
        padding =  request_data["padding"]
        model_type = request_data["model_type"]
        
        #filter    [filter_height, filter_width, in_channels, out_channels]
        weight = [ksize[0], ksize[1], input_shape[-1], output_c]
        save_path = os.path.join("model_generate/static/temp_model/", session["name"])
        if os.path.exists(save_path):
            shutil.rmtree(save_path)
        os.mkdir(save_path)
        
        if model_type == "tflite":
            model_path = create_conv_v1(input_shape = input_shape, filter = weight,strides = strides,
                                        padding = padding,dilations=dilations, save_path = save_path)
        file_download_url = url_for('static', filename=model_path)
        
        data_json = {'status': "success","file_download_url": file_download_url}
        socketio.emit(name, {'data': "文件生成成功", 'progress': "100%"})
        return json.dumps(data_json, ensure_ascii=False), 200 






@model_generate.route('/depthwiseconv', methods=['GET', 'POST'])
def depthwiseconv():
    if request.method == 'GET':
        if session.get("name") == None:
            session["name"] = str(uuid.uuid4().hex)[:6]
        return render_template('depthwiseconv.html',name= session["name"])
    else:
        name = session["name"]
        form_data = request.form
        request_data = dict(form_data)
        print(request_data)
        if request_data is None:
            return {'message': "post data is null!. ",'code': 400},400
        
        input_shape = eval(request_data["input_shape"])
        channel_multiplier = int(request_data["channel_multiplier"])
        ksize = eval(request_data["kernel"])
        strides =  eval(request_data["strides"])
        dilations =  eval(request_data["dilations"])
        bias  = True if request_data["bias"] == "true" else False
        padding =  request_data["padding"]
        model_type = request_data["model_type"]
        
        #filter    [filter_height, filter_width, in_channels, channel_multiplier]
        weight = [ksize[0], ksize[1], input_shape[-1], channel_multiplier]
        save_path = os.path.join("model_generate/static/temp_model/", session["name"])
        if os.path.exists(save_path):
            shutil.rmtree(save_path)
        os.mkdir(save_path)
        
        #filter   [filter_height, filter_width, in_channels, channel_multiplier]
        strides = [1,strides[0],strides[1],1]

        if model_type == "tflite":
            model_path = create_depthwise_conv2d_v1(input_shape = input_shape,filter = weight,strides = strides,
                                                    padding = padding,dilations=dilations, save_path = save_path)
        file_download_url = url_for('static', filename=model_path)
        
        data_json = {'status': "success","file_download_url": file_download_url}
        socketio.emit(name, {'data': "文件生成成功", 'progress': "100%"})
        return json.dumps(data_json, ensure_ascii=False), 200 




@model_generate.route('/transposeconv', methods=['GET', 'POST'])
def transposeconv():
    if request.method == 'GET':
        if session.get("name") == None:
            session["name"] = str(uuid.uuid4().hex)[:6]
        return render_template('transposeconv.html',name= session["name"])
    else:
        name = session["name"]
        form_data = request.form
        request_data = dict(form_data)
        if request_data is None:
            return {'message': "post data is null!. ",'code': 400},400
        
        input_shape = eval(request_data["input_shape"])
        output_c = int(request_data["output_c"])
        ksize = eval(request_data["kernel"])
        strides =  eval(request_data["strides"])
        dilations =  eval(request_data["dilations"])
        bias  = True if request_data["bias"] == "true" else False
        padding =  request_data["padding"]
        model_type = request_data["model_type"]
        
        #filter    [height, width, output_channels, in_channels]. 
        weight = [ksize[0], ksize[1], output_c, input_shape[-1], ]
        save_path = os.path.join("model_generate/static/temp_model/", session["name"])
        if os.path.exists(save_path):
            shutil.rmtree(save_path)
        os.mkdir(save_path)
        
        if model_type == "tflite":
            model_path = create_transpose_conv2d_v1(input_shape = input_shape, filter = weight,strides = strides,
                                        padding = padding,dilations=dilations, save_path = save_path)
        file_download_url = url_for('static', filename=model_path)
        
        data_json = {'status': "success","file_download_url": file_download_url}
        socketio.emit(name, {'data': "文件生成成功", 'progress': "100%"})
        return json.dumps(data_json, ensure_ascii=False), 200 




@model_generate.route('/split', methods=['GET','POST'])
def split():
    if request.method == 'GET':
        if session.get("name") == None:
            session["name"] = str(uuid.uuid4().hex)[:6]
        return render_template('split.html',name= session["name"])
    else:
        name = session["name"]
        form_data = request.form
        request_data = dict(form_data)
        if request_data is None:
            return {'message': "post data is null!. ",'code': 400},400
        
        input_shape = eval(request_data["input_shape"])
        split_output = eval(request_data["split_output"])
        axis = int(request_data["axis"])

        model_type = request_data["model_type"]
        
        save_path = os.path.join("model_generate/static/temp_model/", session["name"])
        if os.path.exists(save_path):
            shutil.rmtree(save_path)
        os.mkdir(save_path)
        
        if model_type == "tflite":
            model_path = create_split_v1(input_shape = input_shape,num_or_size_splits = split_output, axis=axis, save_path = save_path)
        file_download_url = url_for('static', filename=model_path)
        
        data_json = {'status': "success","file_download_url": file_download_url}
        socketio.emit(name, {'data': "文件生成成功", 'progress': "100%"})
        return json.dumps(data_json, ensure_ascii=False), 200 
    

    
@model_generate.route('/concat', methods=['GET','POST'])
def concat():
    if request.method == 'GET':
        if session.get("name") == None:
            session["name"] = str(uuid.uuid4().hex)[:6]
        return render_template('concat.html',name= session["name"])
    else:
        name = session["name"]
        form_data = request.form
        request_data = dict(form_data)
        if request_data is None:
            return {'message': "post data is null!. ",'code': 400},400
        
        # dimension = request_data.get("dimension", None)
        # if dimension is None or dimension == "":
        #     socketio.emit(name, {'data': "dimension  is None", 'progress': "0%"})
        #     return json.dumps({"status": "fail"}, ensure_ascii=False), 200
        # try:
        #     dimension = eval(str(dimension))
        # except:
        #     socketio.emit(name, {'data': "input shape  is invalid", 'progress': "0%"})
        #     return json.dumps({"status": "fail"}, ensure_ascii=False), 200
        print(request_data)
        time.sleep(1)
        save_path = os.path.join(app.config['MODEL_UPLOAD_PATH'], session["name"])
        if os.path.exists(save_path):
                shutil.rmtree(save_path)
        os.mkdir(save_path)
        
        #TODO gegnnerate
        
        file_path = ""
        file_download_url = url_for('static', filename="uploads/models/mobilebert_quant.tflite")
        data_json = {'status': "success","file_download_url": file_download_url}
        socketio.emit(name, {'data': "文件生成成功", 'progress': "100%"})
        return json.dumps(data_json, ensure_ascii=False), 200