
#include <fstream>
#include <iostream>
#include <string>
#include <cstdlib>
#include <vector>
#include <iomanip>
#include <limits>
#include <sstream>
#include <algorithm>
#include <unistd.h>
#include <cmath>
#include "nna_implementation.h"

// namespace fs = std::__fs::filesystem;

std::vector<char> readFile(const char *filename)
{
  std::ifstream file(filename, std::ios::binary);
  if (!file)
  {
    std::cerr << "Failed to open file: " << filename << std::endl;
    return {};
  }

  file.seekg(0, std::ios::end);
  std::streampos fileSize = file.tellg();
  file.seekg(0, std::ios::beg);

  std::vector<char> fileData(fileSize);
  if (!file.read(fileData.data(), fileSize))
  {
    std::cerr << "Failed to read file: " << filename << std::endl;
    return {};
  }
  return fileData;
}

float fixed_to_float(int32_t x, int exponent)
{
  return x * pow(2.0, exponent);
}

/* RNE - round ties to even */
static inline long round_rne(float f)
{
  float sm = f;
  sm -= remainder(sm, 1.0); // subtract the fractional part
  return round(sm);
}

/* RNA - round ties away */
static inline long round_rna(float f)
{
  return round(f);
}

int32_t float_to_fixed(float x, uint32_t depth, int32_t exponent, bool is_signed, bool rne = true,
                       const std::string &location = "undefined")
{
  double sm = x * pow(2.0, -exponent);

  long tm = 0;
  if (rne)
    tm = round_rne(sm);
  else
    tm = round_rna(sm);

  int min = -(1 << (depth - 1));
  int max = (1 << (depth - 1)) - 1;

  if (!is_signed)
  {
    min = 0;
    max = (1 << depth) - 1;
  }

  if (tm > max)
  {
    tm = max;
  }
  if (tm < min)
  {
    tm = min;
  }
  return tm;
}

long convert_value(float val, long max_m, int E)
{

  double sm = val * pow(2.0, -E);

  long tm = round_rne(sm);

  if (tm >= max_m)
  {
    tm = max_m - 1;
  }
  if (tm < -max_m)
  {
    tm = -max_m;
  }

  return tm;
}

void writeBin(std::string path, char *buf, int size)
{
  std::ofstream outfile(path, std::ifstream::binary);
  outfile.write((char *)(buf), size);
  outfile.close();
}

// local copies taken from imgdnn ife
template <typename T>
std::string convertParamToString(const T param)
{
  std::ostringstream oss;
  oss << param;
  std::string oss_str = oss.str();
  return oss_str;
}

template <typename T>
std::string convertParamToString(const T &param, int size)
{
  std::ostringstream oss;
  for (int i = 0; i < size; i++)
  {
    if (i == 0)
      oss << "(";
    oss << convertParamToString(param[i]);
    if (i == (size - 1))
    {
      oss << ")";
    }
    else
    {
      oss << ",";
    }
  }
  std::string oss_str = oss.str();
  return oss_str;
}

// specialization handling proper precision of 'float'
template <>
std::string convertParamToString(const float param)
{
  std::ostringstream oss;
  oss << std::setprecision(std::numeric_limits<float>::max_digits10);
  oss << param;
  std::string oss_str = oss.str();
  return oss_str;
}

void checkStatus(imgdnn_err_code errcode_ret, std::string message)
{
  if (errcode_ret != IMGDNN_SUCCESS)
  {
    std::cout << message << " " << "Failed!!!!!  " << errcode_ret << std::endl;
    exit(1);
  }
  else
  {
    std::cout << message << " " << "success." << std::endl;
  }
}

std::string convertTypeString(imgdnn_type type)
{
  switch (type)
  {
  case IMGDNN_TYPE_I8:
    return "IMGDNN_TYPE_I8";
  case IMGDNN_TYPE_U8:
    return "IMGDNN_TYPE_U8";
  case IMGDNN_TYPE_I16:
    return "IMGDNN_TYPE_I16";
  case IMGDNN_TYPE_U16:
    return "IMGDNN_TYPE_U16";
  case IMGDNN_TYPE_I32:
    return "IMGDNN_TYPE_I32";
  case IMGDNN_TYPE_U32:
    return "IMGDNN_TYPE_U32";
  case IMGDNN_TYPE_F16:
    return "IMGDNN_TYPE_F16";
  case IMGDNN_TYPE_F32:
    return "IMGDNN_TYPE_F32";
  case IMGDNN_TYPE_Q_I8:
    return "IMGDNN_TYPE_Q_I8";
  case IMGDNN_TYPE_Q_U8:
    return "IMGDNN_TYPE_Q_U8";
  case IMGDNN_TYPE_QPA_I8:
    return "IMGDNN_TYPE_QPA_I8";
  case IMGDNN_TYPE_QPA_U8:
    return "IMGDNN_TYPE_QPA_U8";
  case IMGDNN_TYPE_MAX:
    return "IMGDNN_TYPE_MAX";
  default:
    return "UNKNOW type!!";
  }
}

// 回调函数
void err_callback(imgdnn_report_flags flags, const char **tensor_names, int num_tensor_names,
                  imgdnn_err_code error_code, const char *error_message)
{
  std::string msg_prefix;
  switch (flags)
  {
  case imgdnn_report_flags::IMGDNN_REPORT_ERROR:
    msg_prefix = "ERROR";
    break;
  case imgdnn_report_flags::IMGDNN_REPORT_VERBOSE:
    msg_prefix = "VERBOSE";
    break;
  case imgdnn_report_flags::IMGDNN_REPORT_INFO:
    msg_prefix = "INFO";
    break;
  case imgdnn_report_flags::IMGDNN_REPORT_WARNING:
    msg_prefix = "WARNING";
    break;
  default:
    std::cerr << "unknown report flag in error callback" << std::endl;
  }

  std::cerr << msg_prefix << ": " << error_message << std::endl;
}




//----- Printing functions: only use colour codes if stdout/stderr is a terminal
void print_red(const std::string& str) {
  if (isatty(fileno(stderr))) {
      std::cerr << "\033[1;31m" << str << "\033[0m" << std::endl;  // red
  } else {
      std::cerr << str << std::endl;
  }
}

void print_green(const std::string& str) {
  if (isatty(fileno(stdout))) {
      std::cout << "\033[1;32m" << str << "\033[0m" << std::endl;  // green
  } else {
      std::cout << str << std::endl;
  }
}

void print_yellow(const std::string& str) {
  if (isatty(fileno(stderr))) {
      std::cerr << "\033[1;33m" << str << "\033[0m" << std::endl;  // yellow
  } else {
      std::cerr << str << std::endl;
  }
}

void print_blue(const std::string& str) {
  if (isatty(fileno(stdout))) {
      std::cout << "\033[1;34m" << str << "\033[0m" << std::endl;  // blue
  } else {
      std::cout << str << std::endl;
  }
}


void print_err(const std::string& str) { print_red("ERROR: " + str); }
void print_info(const std::string& str) { print_green("INFO: " + str); }
void print_warning(const std::string& str) { print_yellow("WARNING: " + str); }
void print_verbose(const std::string& str) { print_blue("VERBOSE: " + str); }

