ANDROID_NDK=$HOME/test/adnroid/android-ndk-r24
export ANDROID_NDK=$ANDROID_NDK
export ANDROID_NDK_TOOLCHAIN_ROOT=$ANDROID_NDK/toolchains/llvm/prebuild/linux-x86_64
export PATH=$ANDROID_NDK_TOOLCHAIN_ROOT/bin:$PATH

rm -rf build_android_arm64
mkdir build_android_arm64 && cd build_android_arm64
cmake .. -DCMAKE_SYSTEM_NAME=Android \
     -DCMAKE_SYSTEM_VERSION=29 \
     -DCMAKE_ANDROID_ARCH_ABI=arm64-v8a \
     -DCMAKE_ANDROID_NDK=$ANDROID_NDK \
     -DCMAKE_ANDROID_STL_TYPE=c++_static \
     -DCMAKE_BUILD_TYPE=DEBUG \
     -DCMAKE_EXE_LINKER_FLAGS="-llog -lz"

make -j32
cd ..