
rm -rf build_linux_x86
mkdir build_linux_x86 && cd build_linux_x86

# -DCMAKE_TOOLCHAIN_FILE=cmake/linux/toolchain-aarch64.cmake

cmake .. \
    -DCMAKE_SYSTEM_NAME=Linux \
    -DCMAKE_BUILD_TYPE=Release
make -j32
cd ..\

