/*
 * data_types.h - External dependencies for OpCtrl implementation
 *
 * This file contains ONLY the types, constants, and on-disk layout
 * definitions that come from the hardware / driver / binary-format
 * layer.  OpCtrl implementation code includes this file but does NOT
 * place any of its own implementation types here.
 *
 * On-disk op_ctrl binary layout:
 *
 *   +------------------+
 *   | opctrl_header    |   fixed-size header (24 bytes)
 *   +------------------+
 *   | segment 0        |   either unisoc_npu_opctrl (TENSOR)
 *   | ...              |   or    OPCTRL_SEGTYPE_VECTOR + op_count + vdsp_op_info_entry[]
 *   +------------------+
 *   | segment 1        |
 *   | ...              |
 *   +------------------+
 *   | ...              |
 *   +------------------+
 *   | param area       |   VDSP op parameters (op_param_offset points here)
 *   +------------------+
 *
 * NPU segment layout (TENSOR):
 *   [uint32_t segment_type = 0]  [vha_user_cnn_submit_multi_cmd multi_cmd]
 *   Total = sizeof(unisoc_npu_opctrl), packed
 *
 * VDSP segment layout (VECTOR):
 *   [uint32_t segment_type = 1]  [uint32_t op_count]
 *   [vdsp_op_info_entry × op_count]
 *   op_param_offset in each entry is relative to the start of the param area.
 */

#ifndef _OPCTRL_DATA_TYPES_H
#define _OPCTRL_DATA_TYPES_H

#include <stdint.h>
#include <string.h>

/* ========================================================================
 *  Segment type constants
 *
 *  Each segment in the op_ctrl binary starts with a uint32_t tag that
 *  identifies whether it is an NPU (TENSOR) or VDSP (VECTOR) segment.
 * ======================================================================== */

#define OPCTRL_SEGTYPE_TENSOR   0       /* NPU tensor operation segment */
#define OPCTRL_SEGTYPE_VECTOR   1       /* VDSP vector operation segment */

/* ========================================================================
 *  VDSP op type enum
 *
 *  Identifies the kind of compute operation a VDSP op performs.
 *  VDSP_OP_TSU is special: it is a data-sync op (DMA load/store)
 *  inserted dynamically at runtime by the op_ctrl model layer.
 * ======================================================================== */

enum vdsp_op_type {
    VDSP_OP_RMSNORM = 0,            /* RMS normalisation */
    VDSP_OP_SOFTMAX_V,             /* softmax (variant V) */
    VDSP_OP_MATMUL,                /* matrix multiplication */
    VDSP_OP_ELEMENTWISE_ALGEBRA,   /* element-wise algebraic op */
    VDSP_OP_ROPE,                  /* rotary position embedding */
    VDSP_OP_CPY,                   /* buffer copy / gather */
    VDSP_OP_TSU,                   /* dynamic data-sync (DMA load/store) */
    VDSP_OP_MAX,                   /* sentinel, not a real op */
    VDSP_OP_SOFTMAX_FIX            /* softmax (fixed-point variant) */
};

/* Human-readable name for a vdsp_op_type value; returns "UNKNOWN" for
 * out-of-range inputs. */
static inline const char *vdsp_op_type_str(enum vdsp_op_type t)
{
    static const char *names[] = {
        "VDSP_OP_RMSNORM",
        "VDSP_OP_SOFTMAX_V",
        "VDSP_OP_MATMUL",
        "VDSP_OP_ELEMENTWISE_ALGEBRA",
        "VDSP_OP_ROPE",
        "VDSP_OP_CPY",
        "VDSP_OP_TSU",
        "VDSP_OP_MAX",
        "VDSP_OP_SOFTMAX_FIX"
    };
    if (t < 0 || t >= VDSP_OP_MAX)
        return "UNKNOWN";
    return names[t];
}

/* ========================================================================
 *  Sync type constants
 *
 *  BLOCK  -- the consumer must wait for this op to finish before the
 *            next op can start (sequential dependency).
 *  ASYNC  -- the next op may overlap with this op's execution
 *            (pipeline parallelism).
 * ======================================================================== */

#define OPCTRL_SYNC_BLOCK  0            /* blocking wait */
#define OPCTRL_SYNC_ASYNC  1            /* overlap with subsequent compute */

/* ========================================================================
 *  OpCtrl binary header (on-disk, fixed layout)
 *
 *  This is the very first thing in every op_ctrl buffer.
 *  total_size is written last during serialisation (back-patched)
 *  so that it reflects the true byte count including the param area.
 * ======================================================================== */

#pragma pack(push, 1)
struct opctrl_header {
    uint32_t magic;                  /* must equal OPCTRL_MAGIC ("OCTR") */
    uint32_t version;                /* format version, currently 1 */
    uint32_t total_subgraph_count;   /* NPU segments + VDSP segments */
    uint32_t npu_subgraph_count;     /* count of TENSOR segments */
    uint32_t vdsp_subgraph_count;    /* count of VECTOR segments */
    uint32_t total_size;             /* total buffer size in bytes (including header) */
};

/* ========================================================================
 *  VHA NPU dimensions
 *
 *  These come from the hardware specification and define the maximum
 *  array sizes in vha_user_cnn_submit_multi_cmd.
 * ======================================================================== */

#define VHA_MAX_CORES          8       /* max NPU cores per segment */
#define VHA_CORE_MAX_ALT_ADDRS 16      /* max alt-register buffer slots */
#define VHA_OCM_TYPE_MAX       4       /* max on-chip RAM (OCM) types */

/* ========================================================================
 *  VHA NPU submit command structure
 *
 *  This structure mirrors the hardware command submission format used
 *  by the VHA (Vision Hardware Accelerator) driver.  It is embedded
 *  verbatim inside each TENSOR segment in the op_ctrl binary.
 *
 *  Key fields:
 *    cmdbuf[]        -- buffer IDs containing the compiled cmdstream
 *    cmdbuf_offset[] -- byte offset within each cmdstream buffer
 *    cmdbuf_size[]   -- byte length of each core's cmdstream
 *    bufs[]          -- buffer IDs for alternate-register weights/biases
 *    bufoffsets[]    -- offsets into those buffers
 *    bufsizes[]      -- sizes of those buffers
 *    regidx[]        -- which alt-register each buffer maps to
 *    num_cores       -- how many NPU cores this segment uses
 *    onchipram_bufs[]-- buffer IDs for on-chip RAM (OCM) sections
 *
 *  Fields marked (unused) are reserved for future hardware support.
 * ======================================================================== */

struct vha_user_cnn_submit_multi_cmd {
    uint32_t cmdbuf[VHA_MAX_CORES];             /* cmdstream buffer IDs */
    uint32_t cmdbuf_offset[VHA_MAX_CORES];      /* offset within cmdstream buffer */
    uint32_t cmdbuf_size[VHA_MAX_CORES];        /* size of cmdstream data */
    uint32_t bufs[VHA_CORE_MAX_ALT_ADDRS];      /* buffer IDs for alt regs */
    uint32_t bufoffsets[VHA_CORE_MAX_ALT_ADDRS];/* offsets into buffers */
    uint32_t bufsizes[VHA_CORE_MAX_ALT_ADDRS];  /* sizes of buffers */
    uint8_t  regidx[VHA_CORE_MAX_ALT_ADDRS];    /* register index for each buf */
    uint8_t  num_cores;                         /* NPU core count */
    uint32_t onchipram_bufs[VHA_OCM_TYPE_MAX];  /* OCM buffer IDs */
    uint32_t crcs[VHA_MAX_CORES];               /* CRC (unused) */
    uint64_t exec_time;                         /* (unused) */
    uint32_t shared_circ_buf_offs;              /* (unused) */
    uint32_t estimates_cycles;                  /* (unused) */
    uint64_t expected_ip_capab;                 /* (unused) */
    uint64_t hw_brns;                           /* (unused) */
} __attribute__((aligned(8)));

/* ========================================================================
 *  NPU segment on-disk representation
 *
 *  Each TENSOR segment is stored as this packed structure.
 *  segment_type is always OPCTRL_SEGTYPE_TENSOR (0).
 *  multi_cmd contains the full hardware submission descriptor.
 * ======================================================================== */

struct unisoc_npu_opctrl {
    uint32_t segment_type;                          /* OPCTRL_SEGTYPE_TENSOR */
    struct vha_user_cnn_submit_multi_cmd multi_cmd;
} __attribute__((packed));

/* ========================================================================
 *  VDSP op info entry (on-disk, inside VECTOR segment)
 *
 *  Each VDSP op is represented by one vdsp_op_info_entry in the
 *  binary.  op_param_offset is relative to the start of the param
 *  area (i.e. after all segments), not from the buffer start.
 *
 *  depend_id establishes a sequential dependency chain: this op
 *  will not start until the op with id == depend_id has completed.
 *  depend_id == 0 means "no predecessor" (first op in segment).
 *
 *  sync_type determines whether the next op may overlap this one
 *  (ASYNC) or must wait (BLOCK).
 * ======================================================================== */

struct vdsp_op_info_entry {
    uint32_t global_op_id;          /* unique identifier across all segments */
    uint32_t op_type;               /* enum vdsp_op_type value */
    uint32_t op_param_offset;       /* byte offset into param area */
    uint32_t depend_id;             /* predecessor op id (0 = none) */
    uint32_t sync_type;             /* OPCTRL_SYNC_BLOCK / OPCTRL_SYNC_ASYNC */
};
#pragma pack(pop)

/* ========================================================================
 *  OpCtrl magic / version
 * ======================================================================== */

#define OPCTRL_MAGIC   0x4F435452  /* "OCTR" in ASCII */
#define OPCTRL_VERSION 1

#endif /* _OPCTRL_DATA_TYPES_H */
