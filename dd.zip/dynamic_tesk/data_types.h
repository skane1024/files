#pragma once
#include <cstdint>
#include <vector>
#include <unordered_map>
#include <memory>
#include <stdexcept>
#include <cstring>

// ------------------ segment / op 类型枚举 ------------------
enum SegType : uint32_t {
    SEG_TYPE_NPU  = 0,
    SEG_TYPE_VDSP = 1
};

enum VdspOpType : uint32_t {
    OP_TYPE_RMSNORM = 0,
    OP_VDSP_TYPE_SOFTMAX = 1,
    OP_TYPE_MATMUL,
    OP_TYPE_ELEMENTWISE_ALGEBRA,
    OP_TYPE_ROPE,
    OP_TYPE_CPY,
    OP_TYPE_TSU,        // 动态插入的数据同步算子
    OP_TYPE_MAX,
    OP_TYPE_SOFTMAX_PLACEHOLDER_FIX
};


const char* VdspOpTypeToString(VdspOpType type) {
    static const char* names[] = {
        "OP_TYPE_RMSNORM",
        "OP_VDSP_TYPE_SOFTMAX",
        "OP_TYPE_MATMUL",
        "OP_TYPE_ELEMENTWISE_ALGEBRA",
        "OP_TYPE_ROPE",
        "OP_TYPE_CPY",
        "OP_TYPE_TSU",
        "OP_TYPE_MAX",
        "OP_TYPE_SOFTMAX_PLACEHOLDER_FIX"
    };

    if (type < 0 || type >= OP_TYPE_MAX) {
        return "UNKNOWN";
    }
    return names[type];
}

enum SyncType : uint32_t {
    SYNC_TYPE_BLOCK = 0,  // 阻塞等待
    SYNC_TYPE_ASYNC = 1   // 与后续计算并行
};

// ------------------ op_ctrl 二进制上使用的定长结构 ------------------
#pragma pack(push, 1)
struct OpCtrlHeader {
    uint32_t magic;
    uint32_t version;
    uint32_t total_subgraph_count;
    uint32_t npu_subgraph_count;
    uint32_t vdsp_subgraph_count;
    uint32_t total_size;
};





struct NpuCoreInfoEntry {
    uint32_t cmd_buffer_id;
    uint32_t cmd_size;
    uint32_t cmd_offset;
    uint32_t weight_buffer_id;
    uint32_t weight_size;
    uint32_t weight_offset;
};

struct VdspOpInfoEntry {
    uint32_t global_op_id;
    uint32_t op_type;
    uint32_t op_param_offset;
    uint32_t depend_id;
    uint32_t sync_type;
};
#pragma pack(pop)

constexpr uint32_t OP_CTRL_MAGIC   = 0x4F435452; // "OCTR"
constexpr uint32_t OP_CTRL_VERSION = 1;
