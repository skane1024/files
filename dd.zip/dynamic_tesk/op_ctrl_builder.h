// 编译期/模型转换阶段使用：从空白状态逐步添加segment和算子，
// 最终交出一个RuntimeOpCtrlModel，后续查询/插入都基于这个model进行。
class OpCtrlBuilder {
public:
    // 新增一个NPU子图segment，返回其segment_index，后续AddNpuCore依附该index
    uint32_t AddNpuSegment() {
        InternalSegment seg;
        seg.seg_type = SEG_TYPE_NPU;
        segments_.push_back(std::move(seg));
        return static_cast<uint32_t>(segments_.size() - 1);
    }

    void AddNpuCore(uint32_t seg_idx, const NpuCoreInfo& core) {
        CheckSegType(seg_idx, SEG_TYPE_NPU);
        segments_[seg_idx].npu_core_info.push_back(core);
    }

    // 新增一个VDSP子图segment，返回其segment_index
    uint32_t AddVdspSegment() {
        InternalSegment seg;
        seg.seg_type = SEG_TYPE_VDSP;
        segments_.push_back(std::move(seg));
        return static_cast<uint32_t>(segments_.size() - 1);
    }

    // 向指定VDSP segment追加一个算子，depend_id按追加顺序自动串联，
    // 返回分配到的global_op_id，供后续插入TSU时作为锚点使用
    uint32_t AddVdspOp(uint32_t seg_idx, uint32_t op_type, std::vector<uint8_t> op_param) {
        CheckSegType(seg_idx, SEG_TYPE_VDSP);
        InternalVdspOp op;
        op.global_op_id = next_global_op_id_++;
        op.op_type = op_type;
        op.op_param = std::move(op_param);
        op.sync_type = SYNC_TYPE_BLOCK;

        auto& ops = segments_[seg_idx].vdsp_ops;
        op.depend_id = ops.empty() ? 0 : ops.back().global_op_id;
        ops.push_back(std::move(op));
        return ops.back().global_op_id;
    }

    // 构建完成，交出一个可查询/可插入的RuntimeOpCtrlModel
    std::unique_ptr<RuntimeOpCtrlModel> Build() {
        return RuntimeOpCtrlModel::CreateFromSegments(std::move(segments_), next_global_op_id_);
    }

private:
    void CheckSegType(uint32_t seg_idx, uint32_t expect_type) {
        if (seg_idx >= segments_.size()) throw std::out_of_range("segment index out of range");
        if (segments_[seg_idx].seg_type != expect_type) throw std::logic_error("segment type mismatch");
    }

    std::vector<InternalSegment> segments_;
    uint32_t next_global_op_id_ = 0;
};