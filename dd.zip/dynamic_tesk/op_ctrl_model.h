/*
 * op_ctrl_model.h - OpCtrl runtime model, builder, and visualisation
 *
 * This file defines the op_ctrl implementation layer.  It depends on
 * the external types in data_types.h (hardware structs, binary format)
 * but does not place any of its own types there.
 *
 * Architecture overview:
 *
 *   opctrl_builder                      opctrl_model
 *   --------------                      -----------
 *   add_npu_segment()  ──build()──>    load_from_binary()
 *   add_vdsp_segment()                 serialize()
 *                                      apply_insert_plan()
 *                                      get_exec_order()
 *                                      dump()
 *
 *   Usage pattern 1: Build from scratch
 *     opctrl_builder b;
 *     b.add_npu_segment(&npu);
 *     b.add_vdsp_segment(raw, len);
 *     auto model = b.build();
 *     model->dump();
 *     auto bin = model->serialize();
 *
 *   Usage pattern 2: Load existing binary
 *     auto model = opctrl_model::load_from_binary(data, size);
 *     model->apply_insert_plan(plan);
 *     auto bin = model->serialize();
 *
 *   Usage pattern 3: Visualise raw binary (no model needed)
 *     opctrl_dump_binary(data, size);
 */

#ifndef _OPCTRL_MODEL_H
#define _OPCTRL_MODEL_H

#include "data_types.h"
#include <cstdint>
#include <cstring>
#include <vector>
#include <unordered_map>
#include <memory>
#include <stdexcept>
#include <algorithm>
#include <iostream>
#include <iomanip>

/* ========================================================================
 *  Internal VDSP op representation
 *
 *  This is the in-memory form of a single VDSP operation.  Unlike the
 *  on-disk vdsp_op_info_entry (which stores op_param_offset), the
 *  internal representation holds op_param as an inline byte vector,
 *  making it self-contained and independent of the param area layout.
 *
 *  op_param is only non-empty for VDSP_OP_TSU ops, where it stores
 *  a packed opctrl_tsu_param structure.
 * ======================================================================== */

struct opctrl_vdsp_op_internal {
    uint32_t global_op_id;              /* unique identifier across all segments */
    uint32_t op_type;                   /* enum vdsp_op_type value */
    std::vector<uint8_t> op_param;      /* packed op-specific parameters (TSU only) */
    uint32_t depend_id;                 /* predecessor op id (0 = none) */
    uint32_t sync_type;                 /* OPCTRL_SYNC_BLOCK / OPCTRL_SYNC_ASYNC */
};

/* ========================================================================
 *  Internal segment representation
 *
 *  A segment is either an NPU segment (seg_type == OPCTRL_SEGTYPE_TENSOR)
 *  or a VDSP segment (seg_type == OPCTRL_SEGTYPE_VECTOR).
 *
 *  For NPU: npu_multi_cmd is populated, vdsp_ops is empty.
 *  For VDSP: vdsp_ops is populated, npu_multi_cmd is zero-initialised.
 * ======================================================================== */

struct opctrl_segment_internal {
    uint32_t seg_type;                  /* OPCTRL_SEGTYPE_TENSOR or OPCTRL_SEGTYPE_VECTOR */
    struct vha_user_cnn_submit_multi_cmd npu_multi_cmd;  /* valid when TENSOR */
    std::vector<opctrl_vdsp_op_internal> vdsp_ops;       /* valid when VECTOR */
};

/* ========================================================================
 *  Read-only op node view (for execution order queries)
 *
 *  opctrl_op_node_view is a lightweight snapshot of one node in the
 *  execution order.  It does not own any data; it is a value struct
 *  that can be freely copied.
 *
 *  For NPU nodes:
 *    - global_op_id = 0xFFFFFFFF (sentinel, NPU has no op-level id)
 *    - local_op_type = 0 (unused)
 *
 *  For VDSP nodes:
 *    - global_op_id = the op's unique id
 *    - local_op_type = enum vdsp_op_type value
 * ======================================================================== */

struct opctrl_op_node_view {
    uint32_t global_op_id;              /* 0xFFFFFFFF for NPU, op id for VDSP */
    uint32_t segment_index;             /* which segment this node belongs to */
    uint32_t segment_type;              /* OPCTRL_SEGTYPE_TENSOR or OPCTRL_SEGTYPE_VECTOR */
    uint32_t local_op_type;             /* enum vdsp_op_type (meaningful for VDSP only) */
    uint32_t depend_id;                 /* predecessor op id */
};

/*
 * opctrl_op_sequence_view -- read-only ordered list of op nodes
 *
 * Returned by opctrl_model::get_exec_order().  The view is a snapshot:
 * mutations to the model after calling get_exec_order() are NOT
 * reflected in previously returned views.
 */
class opctrl_op_sequence_view {
public:
    explicit opctrl_op_sequence_view(std::vector<opctrl_op_node_view> nodes)
        : nodes_(std::move(nodes)) {}

    /* Total number of nodes (NPU segments count as 1 node each,
     * VDSP ops count as 1 node per op). */
    size_t get_op_count() const { return nodes_.size(); }

    /* Access node by index; throws std::out_of_range if out of bounds. */
    const opctrl_op_node_view& at(size_t idx) const {
        if (idx >= nodes_.size())
            throw std::out_of_range("opctrl_op_sequence_view index out of range");
        return nodes_[idx];
    }

private:
    std::vector<opctrl_op_node_view> nodes_;
};

/* ========================================================================
 *  TSU insertion request types
 *
 *  TSU (Transfer Setup Unit) ops are DMA load/store instructions
 *  inserted dynamically at runtime to overlap data movement with
 *  compute.  The caller provides an opctrl_insert_plan that specifies
 *  where to insert each TSU op (relative to an anchor VDSP op).
 *
 *  Limitation: all TSU insertions must target VDSP ops; inserting
 *  into an NPU segment is not supported and will cause
 *  apply_insert_plan() to return false.
 * ======================================================================== */

#define OPCTRL_INSERT_BEFORE  0        /* insert before the anchor op */
#define OPCTRL_INSERT_AFTER   1        /* insert after the anchor op */

/* TSU op parameters: describes a single DMA transfer */
struct opctrl_tsu_param {
    uint32_t src_addr;                 /* source address (device memory) */
    uint32_t dst_addr;                 /* destination address (device memory) */
    uint32_t data_size;                /* transfer size in bytes */
    uint32_t direction;                /* 0 = LOAD (into SRAM), 1 = STORE (out of SRAM) */
    bool     run_parallel;             /* true -> sync_type = ASYNC (overlap with compute) */
};

/* One insertion request: place a TSU op near an existing VDSP op */
struct opctrl_tsu_insert_req {
    uint32_t anchor_global_op_id;      /* id of the existing op to insert near */
    uint32_t position;                 /* OPCTRL_INSERT_BEFORE / OPCTRL_INSERT_AFTER */
    struct opctrl_tsu_param param;     /* the DMA transfer descriptor */
};

/* A batch of insertion requests applied atomically.
 *
 * IMPORTANT: requests within one plan are processed sequentially.
 * If two requests target ops in the same VDSP segment, the second
 * request's anchor_global_op_id must still refer to the ORIGINAL
 * (pre-insertion) op ids.  For multiple insertions into the same
 * segment, call apply_insert_plan() separately for each request
 * so that the index is rebuilt between calls.
 */
struct opctrl_insert_plan {
    std::vector<opctrl_tsu_insert_req> requests;
};

/* ========================================================================
 *  Runtime mutable model
 *
 *  opctrl_model holds the in-memory representation of an op_ctrl
 *  buffer.  It supports:
 *    - Loading from a binary buffer (load_from_binary)
 *    - Serialising back to binary (serialize)
 *    - Inserting TSU ops (apply_insert_plan)
 *    - Querying execution order (get_exec_order)
 *    - Visualisation (dump)
 *
 *  Internal state:
 *    segments         -- ordered list of NPU/VDSP segments
 *    op_id_index      -- global_op_id → (segment_index, local_op_index) map
 *    next_global_op_id-- monotonically increasing counter for new op ids
 * ======================================================================== */

class opctrl_model {
public:
    /*
     * load_from_binary -- deserialise an op_ctrl binary buffer into a
     * mutable model.  Validates magic, segment types, and buffer
     * bounds.  Throws std::runtime_error on malformed input.
     */
    static std::unique_ptr<opctrl_model> load_from_binary(const uint8_t *data, size_t size);

    /*
     * create_from_segments -- factory used by opctrl_builder::build().
     * Takes ownership of the segment list and rebuilds the op_id_index.
     */
    static std::unique_ptr<opctrl_model> create_from_segments(
        std::vector<opctrl_segment_internal> segments, uint32_t next_global_op_id)
    {
        auto m = std::make_unique<opctrl_model>();
        m->segments = std::move(segments);
        m->next_global_op_id = next_global_op_id;
        m->rebuild_full_index();
        return m;
    }

    /*
     * get_exec_order -- return a read-only view of the global execution
     * order across all segments.  NPU segments appear as single nodes
     * (with global_op_id = 0xFFFFFFFF); VDSP ops appear as individual
     * nodes with their op type and dependency info.
     */
    std::shared_ptr<const opctrl_op_sequence_view> get_exec_order() const;

    /*
     * apply_insert_plan -- insert TSU ops as specified by the plan.
     * Returns true if all insertions succeeded, false if any anchor
     * was not found or if an anchor belongs to an NPU segment.
     * On failure, no insertions are performed (atomic).
     *
     * After insertion, the dependency chain within each affected
     * VDSP segment is rebuilt so that the new TSU ops are properly
     * chained with their neighbours.
     */
    bool apply_insert_plan(const opctrl_insert_plan& plan);

    /*
     * serialize -- convert the model back to an op_ctrl binary buffer.
     * The binary can be passed to load_from_binary() for a round-trip.
     * The param area is appended after all segments; op_param_offset
     * in each vdsp_op_info_entry is set relative to the param area start.
     */
    std::vector<uint8_t> serialize() const;

    /*
     * dump -- print a human-readable representation of the model to
     * the given stream.  Includes header stats, per-segment details,
     * execution order, and dependency chain graph.
     */
    void dump(std::ostream& os = std::cout) const;

private:
    /* rebuild_depend_chain -- re-link depend_id within a VDSP segment
     * so each op depends on its immediate predecessor (sequential chain). */
    void rebuild_depend_chain(opctrl_segment_internal& seg);

    /* rebuild_op_id_index -- rebuild the op_id_index entries for one
     * segment (NPU segments are skipped since they have no VDSP ops). */
    void rebuild_op_id_index(uint32_t seg_idx);

    /* rebuild_full_index -- rebuild the entire op_id_index from scratch. */
    void rebuild_full_index();

    /* alloc_global_op_id -- return the next available global op id
     * and increment the counter.  Used when inserting new TSU ops. */
    uint32_t alloc_global_op_id();

    std::vector<opctrl_segment_internal> segments;

    /* op_id_index maps global_op_id → (segment_index, local_op_index)
     * for fast lookup during TSU insertion.  Only VDSP ops are indexed;
     * NPU segments do not have individual op ids. */
    std::unordered_map<uint32_t, std::pair<uint32_t, uint32_t>> op_id_index;

    /* next_global_op_id is the next unused id for a new op.  It starts
     * at 0 and is updated when VDSP segments are loaded (to be at least
     * max(global_op_id) + 1) and when TSU ops are inserted. */
    uint32_t next_global_op_id = 0;
};

/* ========================================================================
 *  Builder: construct opctrl_model incrementally
 *
 *  opctrl_builder provides two ways to add segments:
 *
 *    add_npu_segment(&npu_ctrl)
 *      -- takes a pointer to a fully-populated unisoc_npu_opctrl;
 *         the multi_cmd is copied into the builder's internal segment.
 *      -- returns the segment index (0-based).
 *
 *    add_vdsp_segment(data, size)
 *      -- takes a raw binary blob (WITHOUT the segment_type header;
 *         the builder adds OPCTRL_SEGTYPE_VECTOR automatically).
 *         The blob must start with a uint32_t op_count followed by
 *         op_count × vdsp_op_info_entry structs.
 *      -- validates that the data is large enough for the claimed
 *         op_count; throws std::runtime_error on underflow.
 *      -- returns the segment index (0-based).
 *
 *  build() moves the accumulated segments into a new opctrl_model.
 *  The builder is left in an empty state and should not be reused.
 * ======================================================================== */

class opctrl_builder {
public:
    /*
     * add_npu_segment -- add an NPU (TENSOR) segment.
     * npu_ctrl->multi_cmd is deep-copied; caller retains ownership.
     */
    uint32_t add_npu_segment(const struct unisoc_npu_opctrl *npu_ctrl) {
        opctrl_segment_internal seg;
        seg.seg_type = OPCTRL_SEGTYPE_TENSOR;
        seg.npu_multi_cmd = npu_ctrl->multi_cmd;
        segments.push_back(std::move(seg));
        return static_cast<uint32_t>(segments.size() - 1);
    }

    /*
     * add_vdsp_segment -- add a VDSP (VECTOR) segment from raw binary.
     *
     * Input format (what the caller provides):
     *   [uint32_t op_count]
     *   [vdsp_op_info_entry × op_count]
     *
     * Note: the caller does NOT include the segment_type uint32_t;
     * the builder prepends OPCTRL_SEGTYPE_VECTOR internally.
     *
     * next_global_op_id is updated to be at least max(global_op_id)+1
     * across all VDSP ops seen so far.
     */
    uint32_t add_vdsp_segment(const void *data, size_t size) {
        opctrl_segment_internal seg;
        seg.seg_type = OPCTRL_SEGTYPE_VECTOR;

        const uint8_t *ptr = static_cast<const uint8_t*>(data);
        if (size < sizeof(uint32_t))
            throw std::runtime_error("VDSP segment data too small");

        uint32_t op_count;
        std::memcpy(&op_count, ptr, sizeof(uint32_t));
        size_t expected = sizeof(uint32_t) + op_count * sizeof(struct vdsp_op_info_entry);
        if (size < expected)
            throw std::runtime_error("VDSP segment data truncated");

        const struct vdsp_op_info_entry *entries =
            reinterpret_cast<const struct vdsp_op_info_entry*>(ptr + sizeof(uint32_t));

        seg.vdsp_ops.resize(op_count);
        for (uint32_t i = 0; i < op_count; ++i) {
            opctrl_vdsp_op_internal op;
            op.global_op_id = entries[i].global_op_id;
            op.op_type      = entries[i].op_type;
            op.depend_id    = entries[i].depend_id;
            op.sync_type    = entries[i].sync_type;
            seg.vdsp_ops[i] = std::move(op);
            next_global_op_id = std::max(next_global_op_id, entries[i].global_op_id + 1);
        }

        segments.push_back(std::move(seg));
        return static_cast<uint32_t>(segments.size() - 1);
    }

    /*
     * build -- finalise construction and return an immutable model.
     * The builder's internal state is moved out; the builder should
     * not be used after calling build().
     */
    std::unique_ptr<opctrl_model> build() {
        return opctrl_model::create_from_segments(std::move(segments), next_global_op_id);
    }

private:
    std::vector<opctrl_segment_internal> segments;
    uint32_t next_global_op_id = 0;
};

/* ========================================================================
 *  Binary dump helper (raw binary → stdout)
 *
 *  opctrl_dump_binary parses an op_ctrl binary buffer without creating
 *  a model and prints a human-readable representation including header
 *  validation, per-segment field values, and a hex dump of the param
 *  area.  Useful for debugging when only raw binary is available.
 * ======================================================================== */

void opctrl_dump_binary(const uint8_t *data, size_t size, std::ostream& os = std::cout);

#endif /* _OPCTRL_MODEL_H */
