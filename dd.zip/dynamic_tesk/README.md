模型编译阶段，会生成模型的执行信息，runtime加载模型以后，会解析模型的执行信息，构建一个op_ctrl的描述信息，发送给kernel，kernel根据这个信息，在对应的cluster上调度执行。模型的执行信息就是一个一个的segment，segment的类型有两种，一种是VDSP segment，一种是NPU segment，一个segment中会有多个算子，算子的类型不同，会有对应的op_param,会从模型中解析出来,对于一个NPU segment, 对应的就是一个NPU子图，NPU子图是一个多核的任务。

对于这个op_ctrl的描述信息，同时也需要把segment的执行信息构建一个简易的副本(描述算子的先后顺序)，提供给用户，用户会根据算子的执行顺序，添加一些数据同步的操作节点， 因为NPU算子计算的数据需要放在SRAM中，但SRAM 的size是有限的，需要在执行前，做一个数据同步的操作，加载数据到SRAM中，TSU操作完成数据搬运，数据的搬运要和计算并行起来。也就是runtime会提供一个对外接口，返回当前模型算子列表的执行顺序信息(只读的信息)。用户获取信息以后，用户根据这个信息，构建一个描述信息，在对应的算子前后插入新的算子，插入一些动态task(tsu算子)，runtime接收到这个信息后，在内部实际的算子列表中，在VDSP算子前后插入对应的算子，同时更新op_ctrl的信息，发送给kernel。这个描述信息我觉得就简单的描述算子的执行顺序就好，不需要描述太多的信息。

对于一个NPU的segment,有这样的结构定义描述
开始uint32描述NPU的核数，然后每个核对应的执行信息，先是CMD的信息，cmd_buffer_id, cmd_size和cmd_offset, 再是权重的信息，weight_buffer_id, weight_size和weight_offset,

struct npu_segment_t {
    uint32_t core_count; // NPU核的个数
    struct {
        uint32_t cmd_buffer_id; // CMD buffer ID
        uint32_t cmd_size;      // CMD数据大小
        uint32_t cmd_offset;    // CMD数据在buffer中的偏移
        uint32_t weight_buffer_id; // 权重buffer ID
        uint32_t weight_size;      // 权重数据大小
        uint32_t weight_offset;    // 权重数据在buffer中的偏移
    } core_info[]; // 每个核对应的执行信息
};

struct vdsp_segment_t {
    uint32_t op_count; // VDSP算子的个数
    struct {
        uint32_t op_type;          // 算子类型
        uint32_t op_param_offset;  // 算子参数在参数buffer中的偏移
        uint32_t op_id;            // 算子ID
        uint32_t depend_id;        // 依赖的前驱操作ID
        uint32_t sync_type;        // 同步类型
    } op_info[]; // 每个算子的参数信息
};

对于一个VDSP的segment,有这样的结构定义描述，先描述核数，再描述算子的个数，每个算子的参数信息为算子类型(op_type),算子参数在参数buffer中的偏移(op_param_offset),算子ID(op_id),依赖的前驱操作ID(depend_id),同步类型(sync_type)。

在整体op_ctrl中，按照segment的执行顺序，依次存储NPU和VDSP的segment信息,

1. 头部信息（共 3 个 32 位无符号整数，小端序）：
   • 字段 1：total_subgraph_count  表示模型中子图的总数（NPU + VDSP）。
   • 字段 2：npu_subgraph_count   表示其中 NPU 子图的数量。
   • 字段 3：vdsp_subgraph_count  表示其中 VDSP 子图的数量。
   注：应满足 total_subgraph_count == npu_subgraph_count + vdsp_subgraph_count
   开头会存储总的segment个数, 然后是第一个segement的类型和对应的segment信息, 第二个segment的类型和对应的segment信息, 依次类推。对于NPU segment,存储NPU segment的结构体信息，对于VDSP segment,存储VDSP segment的结构体信息。

enum seg_type_t {
    OP_TYPE_NPU = 0,
    OP_TYPE_VDSP = 1
};

typedef enum {
    OP_TYPE_RMSNORM = 0,
    OP_VDSP_TYPE_SOFTMAX = 1,
    OP_TYPE_MATMUL,
    OP_TYPE_ELEMENTWISE_ALGEBRA,
    OP_TYPE_ROPE,
    OP_TYPE_CPY,
    OP_TYPE_MAX,
} VdspOpType;

关于对外的接口，是一个c++ 的接口，

typedef struct {
    std::vector`<int>`  segment_type; //表示segment的类型，0表示NPU segment, 1表示VDSP segment
    std::vector< std::vector`<int>`>  //表示每个segment中算子的类型，0表示NPU算子, 1表示VDSP算子
    std::vector`<int>`  coeff_hbf_addr;
    std::vector`<int>`  coeff_size;
} OpInfo;

对外查询接口和 op_ctrl 二进制格式必须彻底解耦。op_ctrl 是给 kernel 用的、追求解析效率的二进制布局，而"算子执行顺序视图"是给用户看的、追求简单易用的只读描述。把两者混在一起会导致每次插入算子都要重新设计对外接口的兼容性，得不偿失。

op_ctrl 需要从"顺序追加"改为"索引表 + 数据块"的布局,原来的设计里，NPU segment 和 VDSP segment 是变长结构体顺序拼接，kernel 必须从头顺序扫描才能定位到某个 segment，且一旦某个 VDSP segment 因插入算子而变长，后面所有 segment 的偏移都要整体平移。改成头部索引表后，kernel 可以 O(1) 跳转到任意 segment，runtime 插入算子时也只需重建被影响的那一个 segment，不需要搬动整个 buffer。

算子需要一个全局唯一 ID（global_op_id）贯穿查询视图和插入请求,现有的 op_id/depend_id 只是 segment 内部局部编号，用户在插入 TSU 节点时需要跨 segment 定位"某个算子之前/之后"，因此必须有一个贯穿整个模型执行序列的全局编号，作为用户插入请求的锚点。




size_t offset = sizeof(struct OpCtrlHeader);
for (uint32_t i = 0; i < header->total_subgraph_count; ++i) {
    uint32_t seg_type = *(const uint32_t*)(base + offset);
    size_t body_offset = offset + sizeof(uint32_t);

    if (seg_type == SEG_TYPE_NPU) {
        uint32_t core_count =*(const uint32_t*)(base + body_offset);
        const NpuCoreInfoEntry* cores =
            (const NpuCoreInfoEntry*)(base + body_offset + sizeof(uint32_t));
        dispatch_npu_subgraph(cores, core_count);
        offset = body_offset + sizeof(uint32_t) + core_count * sizeof(NpuCoreInfoEntry);
    } else {
        uint32_t op_count = *(const uint32_t*)(base + body_offset);
        const VdspOpInfoEntry* ops =
            (const VdspOpInfoEntry*)(base + body_offset + sizeof(uint32_t));
        dispatch_vdsp_subgraph(ops, op_count);
        offset = body_offset + sizeof(uint32_t) + op_count * sizeof(VdspOpInfoEntry);
    }
}
