/*
 * op_ctrl_model.cpp - OpCtrl model implementation
 *
 * Implements load/serialize/TSU-insert/dump for the opctrl_model,
 * and the raw binary dump helper opctrl_dump_binary().
 *
 * Key design decisions:
 *   - Binary parsing is strict: any bounds violation, magic mismatch,
 *     or unknown segment type causes an immediate throw.
 *   - TSU insertion is atomic: if any request in the plan fails,
 *     no insertions are performed (the model state is not rolled back
 *     because the failure is detected before any mutation occurs).
 *   - The dependency chain is always rebuilt after mutation: each
 *     VDSP segment's depend_id values are rewritten as a simple
 *     sequential chain (op[i] depends on op[i-1]).
 *   - op_param_offset in the serialised binary is relative to the
 *     start of the param area (after all segments), not to the
 *     start of the buffer.
 */

#include "op_ctrl_model.h"
#include <algorithm>
#include <sstream>

/* ========================================================================
 *  Deserialisation: op_ctrl binary → mutable model
 *
 *  Walks the binary buffer segment by segment, copying each segment's
 *  data into the model's internal representation.
 *
 *  For NPU (TENSOR) segments:
 *    The raw unisoc_npu_opctrl struct is reinterpreted and its
 *    multi_cmd field is deep-copied into opctrl_segment_internal.
 *
 *  For VDSP (VECTOR) segments:
 *    The op_count and vdsp_op_info_entry array are read; each entry
 *    is converted to an opctrl_vdsp_op_internal.  Note that
 *    op_param_offset is stored but the actual param data is NOT
 *    loaded into opctrl_vdsp_op_internal::op_param at this point
 *    (the param area is only needed for TSU ops, which carry their
 *    params in opctrl_tsu_insert_req::param at insertion time).
 *    If param loading is needed in the future, the param area can
 *    be parsed from (data + segments_end + op_param_offset).
 *
 *  After all segments are loaded, rebuild_full_index() populates
 *  the op_id_index so that apply_insert_plan() can locate ops by id.
 * ======================================================================== */

std::unique_ptr<opctrl_model> opctrl_model::load_from_binary(const uint8_t *data, size_t size)
{
    auto model = std::make_unique<opctrl_model>();

    /* Validate minimum size and magic */
    if (size < sizeof(struct opctrl_header))
        throw std::runtime_error("op_ctrl too small");

    struct opctrl_header hdr;
    std::memcpy(&hdr, data, sizeof(struct opctrl_header));
    if (hdr.magic != OPCTRL_MAGIC)
        throw std::runtime_error("op_ctrl magic mismatch");

    size_t offset = sizeof(struct opctrl_header);
    model->segments.reserve(hdr.total_subgraph_count);

    for (uint32_t i = 0; i < hdr.total_subgraph_count; ++i) {
        /* Each segment starts with a uint32_t seg_type tag */
        if (offset + sizeof(uint32_t) > size)
            throw std::runtime_error("op_ctrl truncated at seg_type");

        uint32_t seg_type;
        std::memcpy(&seg_type, data + offset, sizeof(uint32_t));

        opctrl_segment_internal seg;

        if (seg_type == OPCTRL_SEGTYPE_TENSOR) {
            /* ---- NPU segment: read the full unisoc_npu_opctrl ---- */
            if (offset + sizeof(struct unisoc_npu_opctrl) > size)
                throw std::runtime_error("op_ctrl truncated at NPU segment");

            const struct unisoc_npu_opctrl *npu_ctrl =
                reinterpret_cast<const struct unisoc_npu_opctrl*>(data + offset);
            seg.seg_type = OPCTRL_SEGTYPE_TENSOR;
            seg.npu_multi_cmd = npu_ctrl->multi_cmd;
            offset += sizeof(struct unisoc_npu_opctrl);

        } else if (seg_type == OPCTRL_SEGTYPE_VECTOR) {
            /* ---- VDSP segment: read seg_type + op_count + entries ---- */
            /* Skip past the seg_type uint32_t to the body */
            size_t body_offset = offset + sizeof(uint32_t);

            /* Read op_count */
            uint32_t op_count;
            std::memcpy(&op_count, data + body_offset, sizeof(uint32_t));

            /* Read the vdsp_op_info_entry array that follows op_count */
            const struct vdsp_op_info_entry *entries =
                reinterpret_cast<const struct vdsp_op_info_entry*>(
                    data + body_offset + sizeof(uint32_t));

            seg.seg_type = OPCTRL_SEGTYPE_VECTOR;
            seg.vdsp_ops.resize(op_count);
            for (uint32_t o = 0; o < op_count; ++o) {
                opctrl_vdsp_op_internal op;
                op.global_op_id = entries[o].global_op_id;
                op.op_type      = entries[o].op_type;
                op.depend_id    = entries[o].depend_id;
                op.sync_type    = entries[o].sync_type;
                seg.vdsp_ops[o] = std::move(op);

                /* Track the highest global_op_id so that future TSU ops
                 * get ids that don't collide with existing ones. */
                model->next_global_op_id = std::max(
                    model->next_global_op_id, entries[o].global_op_id + 1);
            }

            /* Advance offset past: seg_type(4) + op_count(4) + entries */
            offset = body_offset + sizeof(uint32_t) + op_count * sizeof(struct vdsp_op_info_entry);
        } else {
            throw std::runtime_error("unknown segment type");
        }

        model->segments.push_back(std::move(seg));
    }

    /* Build the lookup index so apply_insert_plan can find ops by id */
    model->rebuild_full_index();
    return model;
}

/* ========================================================================
 *  Read-only execution order query
 *
 *  Produces a flat, ordered list of "nodes" representing the global
 *  execution order across all segments:
 *
 *    - Each NPU segment contributes one node (the whole segment runs
 *      as one unit on the NPU; there is no op-level granularity).
 *      These nodes get global_op_id = 0xFFFFFFFF as a sentinel.
 *
 *    - Each VDSP op contributes one node with its op id, type,
 *      and dependency info.
 *
 *  The returned opctrl_op_sequence_view is a snapshot of the current
 *  model state; it is not updated if the model is later mutated.
 * ======================================================================== */

std::shared_ptr<const opctrl_op_sequence_view> opctrl_model::get_exec_order() const
{
    std::vector<opctrl_op_node_view> nodes;
    for (uint32_t seg_idx = 0; seg_idx < segments.size(); ++seg_idx) {
        const auto& seg = segments[seg_idx];
        if (seg.seg_type == OPCTRL_SEGTYPE_TENSOR) {
            /* NPU: emit a single aggregate node */
            opctrl_op_node_view node{};
            node.global_op_id  = 0xFFFFFFFF;    /* sentinel: NPU has no op-level id */
            node.segment_index = seg_idx;
            node.segment_type  = OPCTRL_SEGTYPE_TENSOR;
            node.local_op_type = 0;
            node.depend_id     = 0;
            nodes.push_back(node);
        } else {
            /* VDSP: emit one node per op */
            for (const auto& op : seg.vdsp_ops) {
                opctrl_op_node_view node{};
                node.global_op_id  = op.global_op_id;
                node.segment_index = seg_idx;
                node.segment_type  = OPCTRL_SEGTYPE_VECTOR;
                node.local_op_type = op.op_type;
                node.depend_id     = op.depend_id;
                nodes.push_back(node);
            }
        }
    }
    return std::make_shared<opctrl_op_sequence_view>(std::move(nodes));
}

/* ========================================================================
 *  TSU op insertion
 *
 *  apply_insert_plan processes each request in order:
 *    1. Look up the anchor op by global_op_id in op_id_index.
 *    2. Verify the anchor's segment is a VDSP segment.
 *    3. Compute the insertion position (before/after the anchor).
 *    4. Allocate a new global_op_id and create the TSU op.
 *    5. Insert the TSU op into the segment's vdsp_ops vector.
 *
 *  After all requests are processed, the affected segments have their
 *  dependency chains and index entries rebuilt.
 *
 *  NOTE: if two requests in the same plan target ops in the same
 *  segment, the index entries for the first insertion become stale.
 *  For reliable multi-insert into the same segment, call
 *  apply_insert_plan() separately for each insertion so the index
 *  is rebuilt between calls.
 * ======================================================================== */

uint32_t opctrl_model::alloc_global_op_id()
{
    return next_global_op_id++;
}

bool opctrl_model::apply_insert_plan(const opctrl_insert_plan& plan)
{
    /* Collect which segments were mutated so we can rebuild their
     * index entries after all insertions are done. */
    std::vector<uint32_t> affected_segments;

    for (const auto& req : plan.requests) {
        /* Step 1: find the anchor op */
        auto it = op_id_index.find(req.anchor_global_op_id);
        if (it == op_id_index.end())
            return false;   /* anchor not found */

        uint32_t seg_idx   = it->second.first;
        uint32_t local_idx = it->second.second;
        opctrl_segment_internal& seg = segments[seg_idx];

        /* Step 2: only VDSP segments support TSU insertion */
        if (seg.seg_type != OPCTRL_SEGTYPE_VECTOR)
            return false;

        /* Step 3: compute insertion position */
        uint32_t insert_pos = local_idx + (req.position == OPCTRL_INSERT_AFTER ? 1 : 0);

        /* Step 4: create the TSU op */
        opctrl_vdsp_op_internal new_op;
        new_op.global_op_id = alloc_global_op_id();
        new_op.op_type = VDSP_OP_TSU;

        /* Pack the TSU parameters into op_param as a raw byte blob.
         * This will be written to the param area during serialisation. */
        new_op.op_param.resize(sizeof(struct opctrl_tsu_param));
        std::memcpy(new_op.op_param.data(), &req.param, sizeof(struct opctrl_tsu_param));

        /* Determine sync type from run_parallel flag */
        new_op.sync_type = req.param.run_parallel ? OPCTRL_SYNC_ASYNC : OPCTRL_SYNC_BLOCK;
        new_op.depend_id = 0;  /* will be fixed by rebuild_depend_chain */

        /* Step 5: insert into the vdsp_ops vector */
        seg.vdsp_ops.insert(seg.vdsp_ops.begin() + insert_pos, std::move(new_op));
        affected_segments.push_back(seg_idx);
    }

    /* Deduplicate affected segment indices */
    std::sort(affected_segments.begin(), affected_segments.end());
    affected_segments.erase(
        std::unique(affected_segments.begin(), affected_segments.end()),
        affected_segments.end());

    /* Rebuild the dependency chain and index for each affected segment.
     * The dependency chain is a simple sequential link: each op depends
     * on the op immediately before it in the vector. */
    for (uint32_t seg_idx : affected_segments) {
        rebuild_depend_chain(segments[seg_idx]);
        rebuild_op_id_index(seg_idx);
    }
    return true;
}

/* rebuild_depend_chain -- rewrite depend_id in a VDSP segment so that
 * each op depends on its immediate predecessor.  The first op gets
 * depend_id = 0 (no predecessor). */
void opctrl_model::rebuild_depend_chain(opctrl_segment_internal& seg)
{
    uint32_t prev_id = 0;
    bool has_prev = false;
    for (auto& op : seg.vdsp_ops) {
        op.depend_id = has_prev ? prev_id : 0;
        prev_id = op.global_op_id;
        has_prev = true;
    }
}

/* rebuild_op_id_index -- recreate the op_id_index entries for one
 * segment.  Each VDSP op is mapped: global_op_id → (seg_idx, local_idx).
 * NPU segments are skipped (they have no VDSP ops to index). */
void opctrl_model::rebuild_op_id_index(uint32_t seg_idx)
{
    const auto& seg = segments[seg_idx];
    if (seg.seg_type != OPCTRL_SEGTYPE_VECTOR)
        return;
    for (uint32_t local_idx = 0; local_idx < seg.vdsp_ops.size(); ++local_idx) {
        op_id_index[seg.vdsp_ops[local_idx].global_op_id] = {seg_idx, local_idx};
    }
}

/* rebuild_full_index -- clear and rebuild the entire op_id_index
 * from scratch by iterating over all segments. */
void opctrl_model::rebuild_full_index()
{
    op_id_index.clear();
    for (uint32_t seg_idx = 0; seg_idx < segments.size(); ++seg_idx)
        rebuild_op_id_index(seg_idx);
}

/* ========================================================================
 *  Serialisation: mutable model → op_ctrl binary
 *
 *  Produces a byte buffer in the on-disk op_ctrl format:
 *
 *    [opctrl_header]
 *    [segment 0]
 *    [segment 1]
 *    ...
 *    [param area]
 *
 *  NPU segments are serialised as a raw unisoc_npu_opctrl struct.
 *
 *  VDSP segments are serialised as:
 *    [uint32_t OPCTRL_SEGTYPE_VECTOR]
 *    [uint32_t op_count]
 *    [vdsp_op_info_entry × op_count]
 *
 *  The param area is appended after all segments.  Each VDSP op's
 *  op_param_offset is set to its byte offset within the param area.
 *
 *  The header's total_size field is back-patched at the end.
 * ======================================================================== */

std::vector<uint8_t> opctrl_model::serialize() const
{
    std::vector<uint8_t> buffer;

    /* Count NPU and VDSP segments for the header */
    uint32_t npu_count = 0, vdsp_count = 0;
    for (const auto& seg : segments) {
        if (seg.seg_type == OPCTRL_SEGTYPE_TENSOR) npu_count++;
        else vdsp_count++;
    }

    /* Write header (total_size is placeholder; will be back-patched) */
    struct opctrl_header hdr{};
    hdr.magic                = OPCTRL_MAGIC;
    hdr.version              = OPCTRL_VERSION;
    hdr.total_subgraph_count = static_cast<uint32_t>(segments.size());
    hdr.npu_subgraph_count   = npu_count;
    hdr.vdsp_subgraph_count  = vdsp_count;
    hdr.total_size           = 0;

    buffer.resize(sizeof(struct opctrl_header));
    std::memcpy(buffer.data(), &hdr, sizeof(struct opctrl_header));

    /* Param area is built separately and appended at the end */
    std::vector<uint8_t> param_area;

    /* Helper: append a uint32_t to the buffer */
    auto append_u32 = [&buffer](uint32_t v) {
        size_t old = buffer.size();
        buffer.resize(old + sizeof(uint32_t));
        std::memcpy(buffer.data() + old, &v, sizeof(uint32_t));
    };

    for (const auto& seg : segments) {
        if (seg.seg_type == OPCTRL_SEGTYPE_TENSOR) {
            /* ---- NPU segment: write the full packed struct ---- */
            struct unisoc_npu_opctrl npu_entry;
            npu_entry.segment_type = OPCTRL_SEGTYPE_TENSOR;
            npu_entry.multi_cmd = seg.npu_multi_cmd;
            size_t old = buffer.size();
            buffer.resize(old + sizeof(struct unisoc_npu_opctrl));
            std::memcpy(buffer.data() + old, &npu_entry, sizeof(struct unisoc_npu_opctrl));

        } else {
            /* ---- VDSP segment: seg_type + op_count + entries ---- */
            append_u32(OPCTRL_SEGTYPE_VECTOR);
            append_u32(static_cast<uint32_t>(seg.vdsp_ops.size()));

            for (const auto& op : seg.vdsp_ops) {
                /* Calculate this op's param offset relative to the
                 * start of the param area (not the buffer start). */
                uint32_t param_offset = static_cast<uint32_t>(param_area.size());

                /* Append the op's param data to the param area */
                param_area.insert(param_area.end(), op.op_param.begin(), op.op_param.end());

                /* Write the on-disk entry */
                struct vdsp_op_info_entry entry{
                    op.global_op_id, op.op_type, param_offset, op.depend_id, op.sync_type
                };
                size_t old = buffer.size();
                buffer.resize(old + sizeof(struct vdsp_op_info_entry));
                std::memcpy(buffer.data() + old, &entry, sizeof(struct vdsp_op_info_entry));
            }
        }
    }

    /* Append the param area after all segments */
    buffer.insert(buffer.end(), param_area.begin(), param_area.end());

    /* Back-patch total_size in the header */
    uint32_t total_size = static_cast<uint32_t>(buffer.size());
    std::memcpy(buffer.data() + offsetof(struct opctrl_header, total_size),
                &total_size, sizeof(uint32_t));

    return buffer;
}

/* ========================================================================
 *  Visualisation: model dump
 *
 *  Prints a structured, human-readable representation of the model:
 *    1. Header statistics (segment counts, next_global_op_id)
 *    2. Per-segment detail:
 *       - NPU: all multi_cmd fields (cmdbuf, offsets, sizes, bufs, OCM, etc.)
 *       - VDSP: each op's id, type, dependency, sync; TSU params are expanded
 *    3. Execution order table
 *    4. Dependency chain graph (id(X) <-- id(Y) format)
 * ======================================================================== */

static std::string seg_type_str(uint32_t t)
{
    switch (t) {
    case OPCTRL_SEGTYPE_TENSOR: return "NPU(TENSOR)";
    case OPCTRL_SEGTYPE_VECTOR: return "VDSP(VECTOR)";
    default:                    return "UNKNOWN(" + std::to_string(t) + ")";
    }
}

static std::string sync_type_str(uint32_t s)
{
    switch (s) {
    case OPCTRL_SYNC_BLOCK: return "BLOCK";
    case OPCTRL_SYNC_ASYNC: return "ASYNC";
    default:                return "UNKNOWN(" + std::to_string(s) + ")";
    }
}

void opctrl_model::dump(std::ostream& os) const
{
    os << "============================================================\n";
    os << "                  OpCtrl Model Dump\n";
    os << "============================================================\n\n";

    /* statistics */
    uint32_t npu_count = 0, vdsp_count = 0;
    for (const auto& seg : segments) {
        if (seg.seg_type == OPCTRL_SEGTYPE_TENSOR) npu_count++;
        else vdsp_count++;
    }

    os << "[Header]\n";
    os << "  segment_count   : " << segments.size() << "\n";
    os << "  npu_segments    : " << npu_count << "\n";
    os << "  vdsp_segments   : " << vdsp_count << "\n";
    os << "  next_global_op  : " << next_global_op_id << "\n\n";

    /* per-segment detail */
    for (uint32_t seg_idx = 0; seg_idx < segments.size(); ++seg_idx) {
        const auto& seg = segments[seg_idx];
        os << "------------------------------------------------------------\n";
        os << "Segment [" << seg_idx << "]  type=" << seg_type_str(seg.seg_type) << "\n";
        os << "------------------------------------------------------------\n";

        if (seg.seg_type == OPCTRL_SEGTYPE_TENSOR) {
            const auto& m = seg.npu_multi_cmd;
            os << "  [NPU multi_cmd]\n";
            os << "    num_cores       : " << static_cast<uint32_t>(m.num_cores) << "\n";

            os << "    cmdbuf          : [";
            for (uint32_t c = 0; c < VHA_MAX_CORES; ++c) {
                if (c > 0) os << ", ";
                os << m.cmdbuf[c];
            }
            os << "]\n";

            os << "    cmdbuf_offset   : [";
            for (uint32_t c = 0; c < VHA_MAX_CORES; ++c) {
                if (c > 0) os << ", ";
                os << "0x" << std::hex << m.cmdbuf_offset[c] << std::dec;
            }
            os << "]\n";

            os << "    cmdbuf_size     : [";
            for (uint32_t c = 0; c < VHA_MAX_CORES; ++c) {
                if (c > 0) os << ", ";
                os << m.cmdbuf_size[c];
            }
            os << "]\n";

            os << "    bufs            : [";
            for (uint32_t i = 0; i < VHA_CORE_MAX_ALT_ADDRS; ++i) {
                if (i > 0) os << ", ";
                os << m.bufs[i];
            }
            os << "]\n";

            os << "    bufoffsets      : [";
            for (uint32_t i = 0; i < VHA_CORE_MAX_ALT_ADDRS; ++i) {
                if (i > 0) os << ", ";
                os << "0x" << std::hex << m.bufoffsets[i] << std::dec;
            }
            os << "]\n";

            os << "    bufsizes        : [";
            for (uint32_t i = 0; i < VHA_CORE_MAX_ALT_ADDRS; ++i) {
                if (i > 0) os << ", ";
                os << m.bufsizes[i];
            }
            os << "]\n";

            os << "    regidx          : [";
            for (uint32_t i = 0; i < VHA_CORE_MAX_ALT_ADDRS; ++i) {
                if (i > 0) os << ", ";
                os << static_cast<uint32_t>(m.regidx[i]);
            }
            os << "]\n";

            os << "    onchipram_bufs  : [";
            for (uint32_t i = 0; i < VHA_OCM_TYPE_MAX; ++i) {
                if (i > 0) os << ", ";
                os << "0x" << std::hex << m.onchipram_bufs[i] << std::dec;
            }
            os << "]\n";

            os << "    crcs            : [";
            for (uint32_t c = 0; c < VHA_MAX_CORES; ++c) {
                if (c > 0) os << ", ";
                os << "0x" << std::hex << m.crcs[c] << std::dec;
            }
            os << "]\n";

            os << "    exec_time       : " << m.exec_time << "\n";
            os << "    shared_circ_buf : 0x" << std::hex << m.shared_circ_buf_offs << std::dec << "\n";
            os << "    estimates_cycles: " << m.estimates_cycles << "\n";
            os << "    expected_ip_cap : 0x" << std::hex << m.expected_ip_capab << std::dec << "\n";
            os << "    hw_brns         : 0x" << std::hex << m.hw_brns << std::dec << "\n";

        } else {
            os << "  [VDSP ops]  count=" << seg.vdsp_ops.size() << "\n";
            for (uint32_t o = 0; o < seg.vdsp_ops.size(); ++o) {
                const auto& op = seg.vdsp_ops[o];
                os << "    op[" << o << "] id=" << op.global_op_id
                   << "  type=" << vdsp_op_type_str(static_cast<enum vdsp_op_type>(op.op_type))
                   << "  depend=" << op.depend_id
                   << "  sync=" << sync_type_str(op.sync_type)
                   << "  param_size=" << op.op_param.size() << "\n";
                /* Expand TSU params for readability */
                if (op.op_type == VDSP_OP_TSU && op.op_param.size() == sizeof(struct opctrl_tsu_param)) {
                    struct opctrl_tsu_param p;
                    std::memcpy(&p, op.op_param.data(), sizeof(struct opctrl_tsu_param));
                    os << "           TSU: src=0x" << std::hex << p.src_addr
                       << " dst=0x" << p.dst_addr
                       << " size=" << std::dec << p.data_size
                       << " dir=" << (p.direction == 0 ? "LOAD" : "STORE")
                       << " parallel=" << (p.run_parallel ? "Y" : "N") << "\n";
                }
            }
        }
        os << "\n";
    }

    /* execution order */
    os << "============================================================\n";
    os << "                Execution Order\n";
    os << "============================================================\n";
    auto view = get_exec_order();
    for (size_t i = 0; i < view->get_op_count(); ++i) {
        const auto& n = view->at(i);
        os << "  [" << std::setw(2) << i << "] ";
        if (n.segment_type == OPCTRL_SEGTYPE_TENSOR) {
            os << "NPU  seg=" << n.segment_index;
        } else {
            os << "VDSP seg=" << n.segment_index
               << "  id=" << std::setw(3) << n.global_op_id
               << "  type=" << std::setw(28) << vdsp_op_type_str(static_cast<enum vdsp_op_type>(n.local_op_type))
               << "  depend=" << std::setw(3) << n.depend_id;
        }
        os << "\n";
    }

    /* dependency chain */
    os << "\n============================================================\n";
    os << "             Dependency Chain Graph\n";
    os << "============================================================\n";
    for (size_t i = 0; i < view->get_op_count(); ++i) {
        const auto& n = view->at(i);
        os << "  ";
        if (n.segment_type == OPCTRL_SEGTYPE_TENSOR) {
            os << "NPU(seg" << n.segment_index << ")";
        } else {
            os << "id=" << n.global_op_id
               << "(" << vdsp_op_type_str(static_cast<enum vdsp_op_type>(n.local_op_type)) << ")";
        }
        if (n.depend_id != 0 || (n.segment_type == OPCTRL_SEGTYPE_VECTOR && i > 0)) {
            os << " <-- id=" << n.depend_id;
        }
        os << "\n";
    }

    os << "============================================================\n";
}

/* ========================================================================
 *  Visualisation: raw binary dump
 *
 *  Walks the binary buffer without creating a model, printing each
 *  field.  Validates magic and size consistency; reports truncation
 *  or unknown segment types as [ERROR].
 *
 *  Also prints a hex dump of the trailing param area (first 64 bytes).
 * ======================================================================== */

void opctrl_dump_binary(const uint8_t *data, size_t size, std::ostream& os)
{
    os << "============================================================\n";
    os << "             OpCtrl Binary Dump\n";
    os << "============================================================\n\n";

    if (size < sizeof(struct opctrl_header)) {
        os << "  [ERROR] data too small for header (" << size << " < "
           << sizeof(struct opctrl_header) << ")\n";
        return;
    }

    struct opctrl_header hdr;
    std::memcpy(&hdr, data, sizeof(struct opctrl_header));

    os << "[Header]\n";
    os << "  magic           : 0x" << std::hex << hdr.magic << std::dec
       << (hdr.magic == OPCTRL_MAGIC ? " (valid)" : " (INVALID!)") << "\n";
    os << "  version         : " << hdr.version << "\n";
    os << "  total_subgraphs : " << hdr.total_subgraph_count << "\n";
    os << "  npu_subgraphs   : " << hdr.npu_subgraph_count << "\n";
    os << "  vdsp_subgraphs  : " << hdr.vdsp_subgraph_count << "\n";
    os << "  total_size      : " << hdr.total_size << " bytes\n";
    os << "  actual_size     : " << size << " bytes"
       << (hdr.total_size == size ? " (match)" : " (MISMATCH!)") << "\n\n";

    size_t offset = sizeof(struct opctrl_header);
    for (uint32_t i = 0; i < hdr.total_subgraph_count; ++i) {
        if (offset + sizeof(uint32_t) > size) {
            os << "  [ERROR] truncated at segment " << i << " seg_type\n";
            break;
        }

        uint32_t seg_type;
        std::memcpy(&seg_type, data + offset, sizeof(uint32_t));

        os << "------------------------------------------------------------\n";
        os << "Segment [" << i << "]  offset=0x" << std::hex << offset << std::dec
           << "  type=" << seg_type_str(seg_type) << "\n";
        os << "------------------------------------------------------------\n";

        if (seg_type == OPCTRL_SEGTYPE_TENSOR) {
            /* ---- NPU segment ---- */
            if (offset + sizeof(struct unisoc_npu_opctrl) > size) {
                os << "  [ERROR] truncated NPU segment\n";
                break;
            }
            const struct unisoc_npu_opctrl *npu =
                reinterpret_cast<const struct unisoc_npu_opctrl*>(data + offset);
            const auto& m = npu->multi_cmd;

            os << "  segment_type    : 0x" << std::hex << npu->segment_type << std::dec << "\n";
            os << "  num_cores       : " << static_cast<uint32_t>(m.num_cores) << "\n";

            os << "  cmdbuf          : [";
            for (uint32_t c = 0; c < VHA_MAX_CORES; ++c) {
                if (c > 0) os << ", ";
                os << m.cmdbuf[c];
            }
            os << "]\n";

            os << "  cmdbuf_offset   : [";
            for (uint32_t c = 0; c < VHA_MAX_CORES; ++c) {
                if (c > 0) os << ", ";
                os << "0x" << std::hex << m.cmdbuf_offset[c] << std::dec;
            }
            os << "]\n";

            os << "  cmdbuf_size     : [";
            for (uint32_t c = 0; c < VHA_MAX_CORES; ++c) {
                if (c > 0) os << ", ";
                os << m.cmdbuf_size[c];
            }
            os << "]\n";

            os << "  bufs            : [";
            for (uint32_t j = 0; j < VHA_CORE_MAX_ALT_ADDRS; ++j) {
                if (j > 0) os << ", ";
                os << m.bufs[j];
            }
            os << "]\n";

            os << "  bufoffsets      : [";
            for (uint32_t j = 0; j < VHA_CORE_MAX_ALT_ADDRS; ++j) {
                if (j > 0) os << ", ";
                os << "0x" << std::hex << m.bufoffsets[j] << std::dec;
            }
            os << "]\n";

            os << "  bufsizes        : [";
            for (uint32_t j = 0; j < VHA_CORE_MAX_ALT_ADDRS; ++j) {
                if (j > 0) os << ", ";
                os << m.bufsizes[j];
            }
            os << "]\n";

            os << "  regidx          : [";
            for (uint32_t j = 0; j < VHA_CORE_MAX_ALT_ADDRS; ++j) {
                if (j > 0) os << ", ";
                os << static_cast<uint32_t>(m.regidx[j]);
            }
            os << "]\n";

            os << "  onchipram_bufs  : [";
            for (uint32_t j = 0; j < VHA_OCM_TYPE_MAX; ++j) {
                if (j > 0) os << ", ";
                os << "0x" << std::hex << m.onchipram_bufs[j] << std::dec;
            }
            os << "]\n";

            os << "  crcs            : [";
            for (uint32_t c = 0; c < VHA_MAX_CORES; ++c) {
                if (c > 0) os << ", ";
                os << "0x" << std::hex << m.crcs[c] << std::dec;
            }
            os << "]\n";

            os << "  exec_time       : " << m.exec_time << "\n";
            os << "  shared_circ_buf : 0x" << std::hex << m.shared_circ_buf_offs << std::dec << "\n";
            os << "  estimates_cycles: " << m.estimates_cycles << "\n";
            os << "  expected_ip_cap : 0x" << std::hex << m.expected_ip_capab << std::dec << "\n";
            os << "  hw_brns         : 0x" << std::hex << m.hw_brns << std::dec << "\n";
            os << "  struct_size     : " << sizeof(struct unisoc_npu_opctrl) << " bytes\n";
            offset += sizeof(struct unisoc_npu_opctrl);

        } else if (seg_type == OPCTRL_SEGTYPE_VECTOR) {
            /* ---- VDSP segment ---- */
            size_t body = offset + sizeof(uint32_t);
            if (body + sizeof(uint32_t) > size) {
                os << "  [ERROR] truncated VDSP op_count\n";
                break;
            }
            uint32_t op_count;
            std::memcpy(&op_count, data + body, sizeof(uint32_t));
            os << "  op_count        : " << op_count << "\n";

            const struct vdsp_op_info_entry *entries =
                reinterpret_cast<const struct vdsp_op_info_entry*>(
                    data + body + sizeof(uint32_t));

            for (uint32_t o = 0; o < op_count; ++o) {
                os << "  op[" << o << "] id=" << entries[o].global_op_id
                   << "  type=" << vdsp_op_type_str(static_cast<enum vdsp_op_type>(entries[o].op_type))
                   << "  param_off=0x" << std::hex << entries[o].op_param_offset << std::dec
                   << "  depend=" << entries[o].depend_id
                   << "  sync=" << sync_type_str(entries[o].sync_type) << "\n";
            }

            os << "  data_size       : "
               << (sizeof(uint32_t) + op_count * sizeof(struct vdsp_op_info_entry))
               << " bytes (body only)\n";
            offset = body + sizeof(uint32_t) + op_count * sizeof(struct vdsp_op_info_entry);
        } else {
            os << "  [ERROR] unknown segment type: " << seg_type << "\n";
            break;
        }
        os << "\n";
    }

    /* Print the trailing param area */
    if (offset < size) {
        os << "------------------------------------------------------------\n";
        os << "Param Area: " << (size - offset) << " bytes at offset 0x"
           << std::hex << offset << std::dec << "\n";
        size_t remain = size - offset;
        size_t show = remain > 64 ? 64 : remain;
        os << "  hex (first " << show << " bytes): ";
        for (size_t b = 0; b < show; ++b) {
            os << std::hex << std::setw(2) << std::setfill('0')
               << static_cast<uint32_t>(data[offset + b]) << " ";
        }
        os << std::dec << std::setfill(' ') << "\n";
    }

    os << "============================================================\n";
}
