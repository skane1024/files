/*
 * mock_data_test.cpp - Mock-data integration tests for opctrl_model
 *
 * Exercises NPU (unisoc_npu_opctrl) and VDSP construction, serialisation,
 * deserialisation, TSU insertion, and dump visualisation with realistic
 * mock data covering all multi_cmd fields.
 */

#include "op_ctrl_model.h"
#include <cassert>
#include <iostream>
#include <iomanip>
#include <sstream>

/* ========================================================================
 *  Mock data construction helpers
 * ======================================================================== */

static struct unisoc_npu_opctrl make_mock_npu_ctrl(
    uint8_t num_cores, uint32_t cmd_buf_base, uint32_t weight_buf_base)
{
    struct unisoc_npu_opctrl ctrl{};
    ctrl.segment_type = OPCTRL_SEGTYPE_TENSOR;
    ctrl.multi_cmd.num_cores = num_cores;

    for (uint32_t c = 0; c < num_cores; ++c) {
        ctrl.multi_cmd.cmdbuf[c]        = cmd_buf_base;
        ctrl.multi_cmd.cmdbuf_offset[c] = c * 0x2000;
        ctrl.multi_cmd.cmdbuf_size[c]   = 0x2000;
        ctrl.multi_cmd.crcs[c]          = 0xDEAD0000 + c;
    }
    for (uint32_t i = 0; i < VHA_CORE_MAX_ALT_ADDRS; ++i) {
        ctrl.multi_cmd.bufs[i]       = weight_buf_base;
        ctrl.multi_cmd.bufoffsets[i] = i * 0x1000;
        ctrl.multi_cmd.bufsizes[i]   = 0x1000;
        ctrl.multi_cmd.regidx[i]     = static_cast<uint8_t>(i % 4);
    }
    for (uint32_t i = 0; i < VHA_OCM_TYPE_MAX; ++i) {
        ctrl.multi_cmd.onchipram_bufs[i] = 0xBEEF0000 + i;
    }
    ctrl.multi_cmd.exec_time            = 0;
    ctrl.multi_cmd.shared_circ_buf_offs = 0;
    ctrl.multi_cmd.estimates_cycles      = 0;
    ctrl.multi_cmd.expected_ip_capab     = 0;
    ctrl.multi_cmd.hw_brns              = 0;
    return ctrl;
}

static std::vector<uint8_t> make_mock_vdsp_raw(
    const std::vector<std::pair<uint32_t, enum vdsp_op_type>>& ops)
{
    std::vector<struct vdsp_op_info_entry> entries;
    for (size_t i = 0; i < ops.size(); ++i) {
        entries.push_back(vdsp_op_info_entry{
            ops[i].first,
            static_cast<uint32_t>(ops[i].second),
            0,
            i == 0 ? 0 : ops[i-1].first,
            i == 0 ? OPCTRL_SYNC_BLOCK : OPCTRL_SYNC_ASYNC
        });
    }
    std::vector<uint8_t> buf;
    uint32_t op_count = static_cast<uint32_t>(entries.size());
    buf.resize(sizeof(uint32_t) + entries.size() * sizeof(struct vdsp_op_info_entry));
    std::memcpy(buf.data(), &op_count, sizeof(uint32_t));
    std::memcpy(buf.data() + sizeof(uint32_t), entries.data(),
                entries.size() * sizeof(struct vdsp_op_info_entry));
    return buf;
}

/* ========================================================================
 *  Test A: dump model with interleaved NPU/VDSP segments
 * ======================================================================== */

static void test_mock_dump_from_model(void)
{
    opctrl_builder builder;

    auto npu0 = make_mock_npu_ctrl(4, 0xA0, 0xB0);
    builder.add_npu_segment(&npu0);

    auto vdsp0 = make_mock_vdsp_raw({{100, VDSP_OP_RMSNORM}, {101, VDSP_OP_MATMUL}, {102, VDSP_OP_CPY}});
    builder.add_vdsp_segment(vdsp0.data(), vdsp0.size());

    auto npu1 = make_mock_npu_ctrl(2, 0xC0, 0xD0);
    builder.add_npu_segment(&npu1);

    auto vdsp1 = make_mock_vdsp_raw({
        {200, VDSP_OP_ROPE},
        {201, VDSP_OP_ELEMENTWISE_ALGEBRA},
        {202, VDSP_OP_SOFTMAX_FIX},
        {203, VDSP_OP_RMSNORM}
    });
    builder.add_vdsp_segment(vdsp1.data(), vdsp1.size());

    auto model = builder.build();

    std::cout << "\n>>>> Test A: opctrl_model::dump() - interleaved segments\n\n";
    model->dump();

    auto view = model->get_exec_order();
    assert(view->get_op_count() == 9);
    std::cout << "\n  [PASS] test_mock_dump_from_model\n";
}

/* ========================================================================
 *  Test B: dump raw binary via opctrl_dump_binary()
 * ======================================================================== */

static void test_mock_dump_from_binary(void)
{
    opctrl_builder builder;

    auto npu = make_mock_npu_ctrl(4, 0xA0, 0xB0);
    builder.add_npu_segment(&npu);

    auto vdsp0 = make_mock_vdsp_raw({{10, VDSP_OP_RMSNORM}, {11, VDSP_OP_ROPE}});
    builder.add_vdsp_segment(vdsp0.data(), vdsp0.size());

    auto npu1 = make_mock_npu_ctrl(1, 0xC0, 0xD0);
    builder.add_npu_segment(&npu1);

    auto vdsp1 = make_mock_vdsp_raw({
        {20, VDSP_OP_MATMUL},
        {21, VDSP_OP_ELEMENTWISE_ALGEBRA},
        {22, VDSP_OP_CPY}
    });
    builder.add_vdsp_segment(vdsp1.data(), vdsp1.size());

    auto model = builder.build();
    auto bin = model->serialize();

    std::cout << "\n>>>> Test B: opctrl_dump_binary() - raw binary\n\n";
    opctrl_dump_binary(bin.data(), bin.size());

    std::cout << "\n  [PASS] test_mock_dump_from_binary\n";
}

/* ========================================================================
 *  Test C: NPU 8-core full field round-trip
 * ======================================================================== */

static void test_mock_npu_full_field_round_trip(void)
{
    opctrl_builder builder;

    auto npu = make_mock_npu_ctrl(8, 0xAA, 0xBB);
    builder.add_npu_segment(&npu);

    auto model = builder.build();
    auto bin = model->serialize();

    std::cout << "\n>>>> Test C: NPU 8-core full-field round-trip\n";
    std::cout << "  sizeof(opctrl_header)=" << sizeof(struct opctrl_header) << "\n";
    std::cout << "  sizeof(unisoc_npu_opctrl)=" << sizeof(struct unisoc_npu_opctrl) << "\n";
    std::cout << "  serialised size: " << bin.size() << " bytes\n";

    auto reloaded = opctrl_model::load_from_binary(bin.data(), bin.size());
    auto bin2 = reloaded->serialize();
    assert(bin == bin2);
    std::cout << "  second serialisation identical\n";

    /* field-by-field check */
    const struct unisoc_npu_opctrl *raw_npu =
        reinterpret_cast<const struct unisoc_npu_opctrl*>(
            bin.data() + sizeof(struct opctrl_header));
    struct vha_user_cnn_submit_multi_cmd orig_cmd;
    std::memcpy(&orig_cmd, &npu.multi_cmd, sizeof(orig_cmd));
    const auto& restored = raw_npu->multi_cmd;

    assert(restored.num_cores == 8);
    for (uint32_t c = 0; c < 8; ++c) {
        assert(restored.cmdbuf[c]        == orig_cmd.cmdbuf[c]);
        assert(restored.cmdbuf_offset[c] == orig_cmd.cmdbuf_offset[c]);
        assert(restored.cmdbuf_size[c]   == orig_cmd.cmdbuf_size[c]);
        assert(restored.crcs[c]          == orig_cmd.crcs[c]);
    }
    for (uint32_t i = 0; i < VHA_CORE_MAX_ALT_ADDRS; ++i) {
        assert(restored.bufs[i]       == orig_cmd.bufs[i]);
        assert(restored.bufoffsets[i] == orig_cmd.bufoffsets[i]);
        assert(restored.bufsizes[i]   == orig_cmd.bufsizes[i]);
        assert(restored.regidx[i]     == orig_cmd.regidx[i]);
    }
    for (uint32_t i = 0; i < VHA_OCM_TYPE_MAX; ++i) {
        assert(restored.onchipram_bufs[i] == orig_cmd.onchipram_bufs[i]);
    }
    std::cout << "  all fields verified\n";

    std::cout << "\n  --- reloaded model dump ---\n";
    reloaded->dump();

    std::cout << "\n  [PASS] test_mock_npu_full_field_round_trip\n";
}

/* ========================================================================
 *  Test D: load → TSU insert → re-serialise
 * ======================================================================== */

static void test_mock_load_insert_reserialize(void)
{
    opctrl_builder builder;
    auto npu = make_mock_npu_ctrl(2, 0xA0, 0xB0);
    builder.add_npu_segment(&npu);

    auto vdsp = make_mock_vdsp_raw({
        {0, VDSP_OP_RMSNORM},
        {1, VDSP_OP_MATMUL},
        {2, VDSP_OP_CPY}
    });
    builder.add_vdsp_segment(vdsp.data(), vdsp.size());

    auto orig_model = builder.build();
    auto bin = orig_model->serialize();

    auto loaded = opctrl_model::load_from_binary(bin.data(), bin.size());

    std::cout << "\n>>>> Test D: load -> TSU insert -> re-serialise\n\n";
    std::cout << "--- after load ---\n";
    loaded->dump();

    /* insert TSU STORE (async, after MATMUL) */
    struct opctrl_insert_plan plan;
    struct opctrl_tsu_param store_param{0x8000, 0x9000, 0x1000, 1, true};
    plan.requests.push_back({1, OPCTRL_INSERT_AFTER, store_param});
    assert(loaded->apply_insert_plan(plan));

    /* insert TSU LOAD (blocking, before CPY) */
    struct opctrl_insert_plan plan2;
    struct opctrl_tsu_param load_param{0x5000, 0x6000, 0x800, 0, false};
    plan2.requests.push_back({2, OPCTRL_INSERT_BEFORE, load_param});
    assert(loaded->apply_insert_plan(plan2));

    std::cout << "\n--- after TSU(STORE) + TSU(LOAD) insert ---\n";
    loaded->dump();

    /* re-serialise and verify */
    auto bin2 = loaded->serialize();
    std::cout << "\n--- serialised binary dump ---\n";
    opctrl_dump_binary(bin2.data(), bin2.size());

    auto reloaded = opctrl_model::load_from_binary(bin2.data(), bin2.size());
    auto v_before = loaded->get_exec_order();
    auto v_after  = reloaded->get_exec_order();
    assert(v_before->get_op_count() == v_after->get_op_count());
    for (size_t i = 0; i < v_before->get_op_count(); ++i) {
        assert(v_before->at(i).global_op_id == v_after->at(i).global_op_id);
        assert(v_before->at(i).segment_type  == v_after->at(i).segment_type);
    }

    std::cout << "\n  [PASS] test_mock_load_insert_reserialize\n";
}

/* ========================================================================
 *  Test E: edge cases
 * ======================================================================== */

static void test_mock_edge_cases(void)
{
    std::cout << "\n>>>> Test E: edge cases\n";

    /* single NPU 8-core */
    {
        opctrl_builder builder;
        auto npu = make_mock_npu_ctrl(8, 0xFF, 0xFE);
        builder.add_npu_segment(&npu);
        auto model = builder.build();
        auto bin = model->serialize();
        auto reloaded = opctrl_model::load_from_binary(bin.data(), bin.size());
        assert(reloaded->get_exec_order()->get_op_count() == 1);
        std::cout << "  E1: single NPU 8-core -> ok\n";
    }

    /* single VDSP 1 op */
    {
        opctrl_builder builder;
        auto vdsp = make_mock_vdsp_raw({{42, VDSP_OP_ROPE}});
        builder.add_vdsp_segment(vdsp.data(), vdsp.size());
        auto model = builder.build();
        auto bin = model->serialize();
        auto reloaded = opctrl_model::load_from_binary(bin.data(), bin.size());
        assert(reloaded->get_exec_order()->get_op_count() == 1);
        assert(reloaded->get_exec_order()->at(0).global_op_id == 42);
        std::cout << "  E2: single VDSP 1 op -> ok\n";
    }

    /* error: VDSP data too small */
    {
        opctrl_builder builder;
        bool caught = false;
        try {
            uint8_t dummy[2] = {0};
            builder.add_vdsp_segment(dummy, 2);
        } catch (const std::runtime_error&) {
            caught = true;
        }
        assert(caught);
        std::cout << "  E3: VDSP data too small -> exception caught\n";
    }

    /* error: VDSP data truncated */
    {
        opctrl_builder builder;
        bool caught = false;
        try {
            uint8_t fake[8];
            uint32_t fake_count = 3;
            std::memcpy(fake, &fake_count, 4);
            builder.add_vdsp_segment(fake, 8);
        } catch (const std::runtime_error&) {
            caught = true;
        }
        assert(caught);
        std::cout << "  E4: VDSP data truncated -> exception caught\n";
    }

    std::cout << "  [PASS] test_mock_edge_cases\n";
}

/* ========================================================================
 *  Main
 * ======================================================================== */

int main(void)
{
    test_mock_dump_from_model();
    test_mock_dump_from_binary();
    test_mock_npu_full_field_round_trip();
    test_mock_load_insert_reserialize();
    test_mock_edge_cases();

    std::cout << "\n========================================\n";
    std::cout << "All mock data tests passed.\n";
    return 0;
}
