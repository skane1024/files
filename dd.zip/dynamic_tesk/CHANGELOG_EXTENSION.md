# OpCtrl 扩展变更指南

本文档说明当 VDSP segment 结构或 TSU 插入算子发生变化时，需要修改哪些文件和位置。

---

## 1. VDSP Segment 结构变更

VDSP segment 的 on-disk 布局当前为：

```
[uint32_t segment_type = OPCTRL_SEGTYPE_VECTOR]
[uint32_t op_count]
[vdsp_op_info_entry × op_count]
[param area]
```

### 1.1 如果 `vdsp_op_info_entry` 增减字段

**需要修改的位置：**

| 文件 | 位置 | 修改内容 |
|------|------|----------|
| `data_types.h` | `struct vdsp_op_info_entry` | 增删字段定义 |
| `data_types.h` | `struct vdsp_op_info_entry` 上方注释 | 更新字段说明 |
| `op_ctrl_model.h` | `struct opctrl_vdsp_op_internal` | 对应增删内部字段 |
| `op_ctrl_model.h` | `opctrl_builder::add_vdsp_segment()` | 解析 raw binary 时读取新字段 |
| `op_ctrl_model.cpp` | `load_from_binary()` VDSP 分支 | 反序列化时读取新字段 |
| `op_ctrl_model.cpp` | `serialize()` VDSP 分支 | 序列化时写入新字段 |
| `op_ctrl_model.cpp` | `dump()` / `opctrl_dump_binary()` VDSP 部分 | 打印新字段 |
| `op_ctrl_test.cpp` | `build_vdsp_raw_binary()` | 构造测试数据时填充新字段 |
| `mock_data_test.cpp` | `make_mock_vdsp_raw()` | mock 数据填充新字段 |

### 1.2 如果 VDSP segment 整体布局变化（如增加 segment 级字段）

例如在 `op_count` 之后、`vdsp_op_info_entry[]` 之前增加 segment 级参数：

**需要修改的位置：**

| 文件 | 位置 | 修改内容 |
|------|------|----------|
| `data_types.h` | VDSP segment 布局注释 | 更新 on-disk 布局图 |
| `data_types.h` | 新增 segment 级结构体定义（如需要） | 例如 `struct vdsp_segment_header` |
| `op_ctrl_model.h` | `struct opctrl_segment_internal` | 增加新字段存储 |
| `op_ctrl_model.h` | `opctrl_builder::add_vdsp_segment()` | 解析新 segment header |
| `op_ctrl_model.cpp` | `load_from_binary()` VDSP 分支 | 读取新 segment header，调整 offset 计算 |
| `op_ctrl_model.cpp` | `serialize()` VDSP 分支 | 写入新 segment header，调整 param_area 逻辑 |
| `op_ctrl_model.cpp` | `dump()` / `opctrl_dump_binary()` | 打印新 segment 级信息 |
| `op_ctrl_test.cpp` / `mock_data_test.cpp` | 测试数据构造 | 包含新 segment header |

### 1.3 如果 VDSP segment 增加新的 op 类型

**需要修改的位置：**

| 文件 | 位置 | 修改内容 |
|------|------|----------|
| `data_types.h` | `enum vdsp_op_type` | 添加新枚举值（在 `VDSP_OP_MAX` 之前） |
| `data_types.h` | `vdsp_op_type_str()` | 在 `names[]` 数组中添加对应字符串 |

其余代码无需修改，因为 op_type 作为 `uint32_t` 透传，不参与逻辑分支（除了 TSU 的特殊处理）。

---

## 2. TSU 插入算子变更

### 2.1 如果 `opctrl_tsu_param` 增减字段

**需要修改的位置：**

| 文件 | 位置 | 修改内容 |
|------|------|----------|
| `op_ctrl_model.h` | `struct opctrl_tsu_param` | 增删字段 |
| `op_ctrl_model.h` | `opctrl_tsu_param` 注释 | 更新字段说明 |
| `op_ctrl_model.cpp` | `apply_insert_plan()` | `op_param.resize(sizeof(opctrl_tsu_param))` 和 `memcpy` 不变（因为按 sizeof 自动适配），但如果新字段需要初始化则需修改 |
| `op_ctrl_model.cpp` | `dump()` TSU 展开部分 | 打印新字段 |
| `op_ctrl_model.cpp` | `opctrl_dump_binary()` | 如果 TSU param 也要在二进制 dump 中展开，需修改 |
| `op_ctrl_test.cpp` | 构造 `opctrl_tsu_param` 的测试代码 | 填充新字段 |
| `mock_data_test.cpp` | `make_mock_npu_ctrl` 等使用 TSU 的测试 | 填充新字段 |

### 2.2 如果 TSU 插入策略变化（如支持插入到 NPU segment）

当前 TSU 只能插入到 VDSP segment。如果需要支持 NPU：

**需要修改的位置：**

| 文件 | 位置 | 修改内容 |
|------|------|----------|
| `op_ctrl_model.h` | `opctrl_segment_internal` | NPU segment 需要支持持有 vdsp_ops（或独立的 tsu_ops 列表） |
| `op_ctrl_model.h` | `opctrl_insert_plan` 注释 | 删除"NPU segment 不支持"的限制说明 |
| `op_ctrl_model.cpp` | `apply_insert_plan()` | 移除 `seg.seg_type != OPCTRL_SEGTYPE_VECTOR` 检查，增加 NPU segment 的插入逻辑 |
| `op_ctrl_model.cpp` | `get_exec_order()` | NPU segment 需要展开内部 ops（不再是单一 node） |
| `op_ctrl_model.cpp` | `rebuild_op_id_index()` | 支持索引 NPU segment 内的 ops |
| `op_ctrl_model.cpp` | `serialize()` | NPU segment 需要序列化内部 ops |
| `op_ctrl_model.cpp` | `dump()` | 打印 NPU segment 内部 ops |
| `op_ctrl_test.cpp` | 新增测试 | 验证 NPU segment 插入 TSU |

### 2.3 如果 TSU 变为非单一算子（如拆分为 LOAD_TSU / STORE_TSU 两种类型）

**需要修改的位置：**

| 文件 | 位置 | 修改内容 |
|------|------|----------|
| `data_types.h` | `enum vdsp_op_type` | 将 `VDSP_OP_TSU` 替换为 `VDSP_OP_TSU_LOAD` 和 `VDSP_OP_TSU_STORE`（或保留 `VDSP_OP_TSU` 并新增） |
| `data_types.h` | `vdsp_op_type_str()` | 添加新字符串 |
| `op_ctrl_model.h` | `struct opctrl_tsu_param` | `direction` 字段可能不再需要（由 op_type 隐含） |
| `op_ctrl_model.cpp` | `apply_insert_plan()` | 根据 direction 设置不同的 op_type |
| `op_ctrl_model.cpp` | `dump()` TSU 展开部分 | 根据 op_type 展示不同信息 |

### 2.4 如果依赖链构建策略变化

当前策略：VDSP segment 内严格顺序链（op[i] depends on op[i-1]）。

如果需要支持并行分支（多个 op 依赖同一个前驱）：

**需要修改的位置：**

| 文件 | 位置 | 修改内容 |
|------|------|----------|
| `op_ctrl_model.h` | `opctrl_tsu_insert_req` | 可能需要增加 `depend_id` 字段让调用方指定 |
| `op_ctrl_model.h` | `opctrl_vdsp_op_internal` | `depend_id` 可能需要支持多个前驱（改为 vector） |
| `op_ctrl_model.h` | `opctrl_op_node_view` | 同上 |
| `op_ctrl_model.cpp` | `rebuild_depend_chain()` | 改为非顺序链构建逻辑 |
| `op_ctrl_model.cpp` | `apply_insert_plan()` | 插入后不再无条件重建整条链，而是按需更新 |
| `op_ctrl_model.cpp` | `serialize()` | `depend_id` 可能需要改为数组序列化 |
| `data_types.h` | `struct vdsp_op_info_entry` | `depend_id` 字段可能需要扩展 |

---

## 3. 变更影响速查表

| 变更类型 | data_types.h | op_ctrl_model.h | op_ctrl_model.cpp | 测试文件 |
|----------|:------------:|:---------------:|:-----------------:|:--------:|
| vdsp_op_info_entry 增减字段 | ✅ | ✅ | ✅ | ✅ |
| VDSP segment 布局变化 | ✅ | ✅ | ✅ | ✅ |
| 新增 VDSP op 类型 | ✅ | - | - | 可选 |
| opctrl_tsu_param 增减字段 | - | ✅ | ✅ | ✅ |
| TSU 支持插入 NPU | - | ✅ | ✅ | ✅ |
| TSU 拆分为 LOAD/STORE | ✅ | ✅ | ✅ | ✅ |
| 依赖链策略变化 | ✅ | ✅ | ✅ | ✅ |

图例：✅ = 必须修改，- = 无需修改，可选 = 建议补充测试但非必须
