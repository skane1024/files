/*
 * op_ctrl_test.cpp - Unit tests for opctrl_model and opctrl_builder
 */

#include "op_ctrl_model.h"
#include <cassert>
#include <iostream>

/* ========================================================================
 *  Helper: build VDSP raw binary segment (without seg_type header)
 * ======================================================================== */

static std::vector<uint8_t> build_vdsp_raw_binary(const std::vector<struct vdsp_op_info_entry>& entries)
{
    std::vector<uint8_t> buf;
    uint32_t op_count = static_cast<uint32_t>(entries.size());
    buf.resize(sizeof(uint32_t) + entries.size() * sizeof(struct vdsp_op_info_entry));
    std::memcpy(buf.data(), &op_count, sizeof(uint32_t));
    std::memcpy(buf.data() + sizeof(uint32_t), entries.data(),
                entries.size() * sizeof(struct vdsp_op_info_entry));
    return buf;
}

/* ========================================================================
 *  Test 1: build NPU + VDSP mixed model from scratch
 * ======================================================================== */

static void test_build_from_scratch(void)
{
    opctrl_builder builder;

    struct unisoc_npu_opctrl npu_ctrl{};
    npu_ctrl.segment_type = OPCTRL_SEGTYPE_TENSOR;
    npu_ctrl.multi_cmd.num_cores = 2;
    npu_ctrl.multi_cmd.cmdbuf[0] = 1;
    npu_ctrl.multi_cmd.cmdbuf_size[0] = 4096;
    npu_ctrl.multi_cmd.cmdbuf_offset[0] = 0;
    npu_ctrl.multi_cmd.bufs[0] = 2;
    npu_ctrl.multi_cmd.bufsizes[0] = 8192;
    npu_ctrl.multi_cmd.bufoffsets[0] = 0;
    npu_ctrl.multi_cmd.cmdbuf[1] = 1;
    npu_ctrl.multi_cmd.cmdbuf_size[1] = 4096;
    npu_ctrl.multi_cmd.cmdbuf_offset[1] = 4096;
    npu_ctrl.multi_cmd.bufs[1] = 2;
    npu_ctrl.multi_cmd.bufsizes[1] = 8192;
    npu_ctrl.multi_cmd.bufoffsets[1] = 8192;
    builder.add_npu_segment(&npu_ctrl);

    std::vector<struct vdsp_op_info_entry> vdsp_entries = {
        {0, VDSP_OP_RMSNORM, 0, 0, OPCTRL_SYNC_BLOCK},
        {1, VDSP_OP_MATMUL,  0, 0, OPCTRL_SYNC_BLOCK},
        {2, VDSP_OP_CPY,     0, 0, OPCTRL_SYNC_BLOCK}
    };
    auto vdsp_raw = build_vdsp_raw_binary(vdsp_entries);
    builder.add_vdsp_segment(vdsp_raw.data(), vdsp_raw.size());

    auto model = builder.build();

    auto view = model->get_exec_order();
    assert(view->get_op_count() == 4);
    assert(view->at(0).segment_type == OPCTRL_SEGTYPE_TENSOR);
    assert(view->at(1).global_op_id == 0);
    assert(view->at(2).global_op_id == 1);
    assert(view->at(3).global_op_id == 2);

    std::cout << "[PASS] test_build_from_scratch\n";
}

/* ========================================================================
 *  Test 2: insert TSU op and verify execution order / depend chain
 * ======================================================================== */

static void test_insert_tsu_op(void)
{
    opctrl_builder builder;

    std::vector<struct vdsp_op_info_entry> vdsp_entries = {
        {0, VDSP_OP_RMSNORM, 0, 0, OPCTRL_SYNC_BLOCK},
        {1, VDSP_OP_MATMUL,  0, 0, OPCTRL_SYNC_BLOCK}
    };
    auto vdsp_raw = build_vdsp_raw_binary(vdsp_entries);
    builder.add_vdsp_segment(vdsp_raw.data(), vdsp_raw.size());

    auto model = builder.build();

    struct opctrl_insert_plan plan;
    struct opctrl_tsu_param param{0x1000, 0x2000, 4096, 0, true};
    plan.requests.push_back({1, OPCTRL_INSERT_BEFORE, param});
    bool ok = model->apply_insert_plan(plan);
    assert(ok);

    auto view = model->get_exec_order();
    assert(view->get_op_count() == 3);

    const auto& n0 = view->at(0);
    const auto& n1 = view->at(1);
    const auto& n2 = view->at(2);

    assert(n0.global_op_id == 0);
    assert(n1.local_op_type == VDSP_OP_TSU);
    assert(n1.depend_id == 0);
    assert(n2.global_op_id == 1);
    assert(n2.depend_id == n1.global_op_id);

    std::cout << "[PASS] test_insert_tsu_op\n";
}

/* ========================================================================
 *  Test 3: insert with invalid anchor should fail
 * ======================================================================== */

static void test_insert_invalid_anchor(void)
{
    opctrl_builder builder;

    std::vector<struct vdsp_op_info_entry> vdsp_entries = {
        {0, VDSP_OP_RMSNORM, 0, 0, OPCTRL_SYNC_BLOCK}
    };
    auto vdsp_raw = build_vdsp_raw_binary(vdsp_entries);
    builder.add_vdsp_segment(vdsp_raw.data(), vdsp_raw.size());

    auto model = builder.build();

    struct opctrl_insert_plan plan;
    struct opctrl_tsu_param param{0, 0, 0, 0, false};
    plan.requests.push_back({9999, OPCTRL_INSERT_AFTER, param});
    bool ok = model->apply_insert_plan(plan);
    assert(!ok);

    auto view = model->get_exec_order();
    assert(view->get_op_count() == 1);

    std::cout << "[PASS] test_insert_invalid_anchor\n";
}

/* ========================================================================
 *  Test 4: insert on NPU segment should fail
 * ======================================================================== */

static void test_insert_on_npu_segment_should_fail(void)
{
    opctrl_builder builder;

    struct unisoc_npu_opctrl npu_ctrl{};
    npu_ctrl.segment_type = OPCTRL_SEGTYPE_TENSOR;
    npu_ctrl.multi_cmd.num_cores = 1;
    npu_ctrl.multi_cmd.cmdbuf[0] = 1;
    npu_ctrl.multi_cmd.cmdbuf_size[0] = 100;
    npu_ctrl.multi_cmd.bufs[0] = 1;
    npu_ctrl.multi_cmd.bufsizes[0] = 100;
    builder.add_npu_segment(&npu_ctrl);

    auto model = builder.build();

    struct opctrl_insert_plan plan;
    struct opctrl_tsu_param param{0, 0, 0, 0, false};
    plan.requests.push_back({0xFFFFFFFF, OPCTRL_INSERT_BEFORE, param});
    bool ok = model->apply_insert_plan(plan);
    assert(!ok);

    std::cout << "[PASS] test_insert_on_npu_segment_should_fail\n";
}

/* ========================================================================
 *  Test 5: serialise → deserialise round-trip
 * ======================================================================== */

static void test_serialize_round_trip(void)
{
    opctrl_builder builder;

    struct unisoc_npu_opctrl npu_ctrl{};
    npu_ctrl.segment_type = OPCTRL_SEGTYPE_TENSOR;
    npu_ctrl.multi_cmd.num_cores = 1;
    npu_ctrl.multi_cmd.cmdbuf[0] = 1;
    npu_ctrl.multi_cmd.cmdbuf_size[0] = 2048;
    npu_ctrl.multi_cmd.cmdbuf_offset[0] = 0;
    npu_ctrl.multi_cmd.bufs[0] = 3;
    npu_ctrl.multi_cmd.bufsizes[0] = 4096;
    npu_ctrl.multi_cmd.bufoffsets[0] = 0;
    builder.add_npu_segment(&npu_ctrl);

    std::vector<struct vdsp_op_info_entry> vdsp_entries = {
        {0, VDSP_OP_RMSNORM, 0, 0, OPCTRL_SYNC_BLOCK},
        {1, VDSP_OP_SOFTMAX_FIX, 0, 0, OPCTRL_SYNC_BLOCK}
    };
    auto vdsp_raw = build_vdsp_raw_binary(vdsp_entries);
    builder.add_vdsp_segment(vdsp_raw.data(), vdsp_raw.size());

    auto model = builder.build();

    struct opctrl_insert_plan plan;
    struct opctrl_tsu_param param{0x100, 0x200, 512, 1, false};
    plan.requests.push_back({1, OPCTRL_INSERT_AFTER, param});
    assert(model->apply_insert_plan(plan));

    std::vector<uint8_t> bin = model->serialize();

    /* verify header */
    struct opctrl_header hdr;
    std::memcpy(&hdr, bin.data(), sizeof(struct opctrl_header));
    assert(hdr.magic == OPCTRL_MAGIC);
    assert(hdr.total_subgraph_count == 2);
    assert(hdr.npu_subgraph_count == 1);
    assert(hdr.vdsp_subgraph_count == 1);
    assert(hdr.total_size == bin.size());

    /* reload and compare */
    auto reloaded = opctrl_model::load_from_binary(bin.data(), bin.size());
    auto v_before = model->get_exec_order();
    auto v_after  = reloaded->get_exec_order();
    assert(v_before->get_op_count() == v_after->get_op_count());
    for (size_t i = 0; i < v_before->get_op_count(); ++i) {
        assert(v_before->at(i).global_op_id == v_after->at(i).global_op_id);
        assert(v_before->at(i).segment_type  == v_after->at(i).segment_type);
    }

    std::cout << "[PASS] test_serialize_round_trip\n";
}

/* ========================================================================
 *  Test 6: kernel-side sequential parse
 * ======================================================================== */

static void test_kernel_side_sequential_parse(void)
{
    opctrl_builder builder;

    struct unisoc_npu_opctrl npu_ctrl{};
    npu_ctrl.segment_type = OPCTRL_SEGTYPE_TENSOR;
    npu_ctrl.multi_cmd.num_cores = 2;
    npu_ctrl.multi_cmd.cmdbuf[0] = 1;
    npu_ctrl.multi_cmd.cmdbuf_size[0] = 100;
    npu_ctrl.multi_cmd.cmdbuf_offset[0] = 0;
    npu_ctrl.multi_cmd.bufs[0] = 1;
    npu_ctrl.multi_cmd.bufsizes[0] = 200;
    npu_ctrl.multi_cmd.bufoffsets[0] = 0;
    npu_ctrl.multi_cmd.cmdbuf[1] = 1;
    npu_ctrl.multi_cmd.cmdbuf_size[1] = 100;
    npu_ctrl.multi_cmd.cmdbuf_offset[1] = 100;
    npu_ctrl.multi_cmd.bufs[1] = 1;
    npu_ctrl.multi_cmd.bufsizes[1] = 200;
    npu_ctrl.multi_cmd.bufoffsets[1] = 200;
    builder.add_npu_segment(&npu_ctrl);

    std::vector<struct vdsp_op_info_entry> vdsp_entries = {
        {0, VDSP_OP_MATMUL, 0, 0, OPCTRL_SYNC_BLOCK},
        {1, VDSP_OP_CPY,    0, 0, OPCTRL_SYNC_BLOCK}
    };
    auto vdsp_raw = build_vdsp_raw_binary(vdsp_entries);
    builder.add_vdsp_segment(vdsp_raw.data(), vdsp_raw.size());

    auto model = builder.build();
    std::vector<uint8_t> bin = model->serialize();

    const uint8_t *base = bin.data();
    struct opctrl_header hdr;
    std::memcpy(&hdr, base, sizeof(struct opctrl_header));

    size_t offset = sizeof(struct opctrl_header);
    uint32_t visited_npu = 0, visited_vdsp = 0;

    for (uint32_t i = 0; i < hdr.total_subgraph_count; ++i) {
        uint32_t seg_type;
        std::memcpy(&seg_type, base + offset, sizeof(uint32_t));

        if (seg_type == OPCTRL_SEGTYPE_TENSOR) {
            const struct unisoc_npu_opctrl *npu_entry =
                reinterpret_cast<const struct unisoc_npu_opctrl*>(base + offset);
            assert(npu_entry->multi_cmd.num_cores == 2);
            visited_npu++;
            offset += sizeof(struct unisoc_npu_opctrl);
        } else {
            size_t body_offset = offset + sizeof(uint32_t);
            uint32_t op_count;
            std::memcpy(&op_count, base + body_offset, sizeof(uint32_t));
            assert(op_count == 2);
            visited_vdsp++;
            offset = body_offset + sizeof(uint32_t) + op_count * sizeof(struct vdsp_op_info_entry);
        }
    }

    assert(visited_npu == 1 && visited_vdsp == 1);
    assert(offset <= bin.size());

    std::cout << "[PASS] test_kernel_side_sequential_parse\n";
}

/* ========================================================================
 *  Test 7: add_vdsp_segment correctly parses raw binary
 * ======================================================================== */

static void test_add_vdsp_segment_from_raw_binary(void)
{
    std::vector<struct vdsp_op_info_entry> entries = {
        {10, VDSP_OP_RMSNORM, 0, 0, OPCTRL_SYNC_BLOCK},
        {20, VDSP_OP_ROPE,    0, 10, OPCTRL_SYNC_ASYNC},
        {30, VDSP_OP_CPY,     0, 20, OPCTRL_SYNC_BLOCK}
    };
    auto raw = build_vdsp_raw_binary(entries);

    opctrl_builder builder;
    builder.add_vdsp_segment(raw.data(), raw.size());

    auto model = builder.build();
    auto view = model->get_exec_order();

    assert(view->get_op_count() == 3);
    assert(view->at(0).global_op_id == 10);
    assert(view->at(0).local_op_type == VDSP_OP_RMSNORM);
    assert(view->at(1).global_op_id == 20);
    assert(view->at(1).local_op_type == VDSP_OP_ROPE);
    assert(view->at(2).global_op_id == 30);
    assert(view->at(2).local_op_type == VDSP_OP_CPY);

    std::cout << "[PASS] test_add_vdsp_segment_from_raw_binary\n";
}

/* ========================================================================
 *  Main
 * ======================================================================== */

int main(void)
{
    test_build_from_scratch();
    test_insert_tsu_op();
    test_insert_invalid_anchor();
    test_insert_on_npu_segment_should_fail();
    test_serialize_round_trip();
    test_kernel_side_sequential_parse();
    test_add_vdsp_segment_from_raw_binary();
    std::cout << "All tests passed.\n";
    return 0;
}
