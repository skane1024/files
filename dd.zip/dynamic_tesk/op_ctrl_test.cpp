#include "runtime_op_ctrl_model.h"
#include "op_ctrl_builder.h"
#include <cassert>
#include <iostream>

// ---------------- 工具：把TsuOpParam打包成字节数组 ----------------
static std::vector<uint8_t> PackTsuParam(const TsuOpParam& p) {
    std::vector<uint8_t> buf(sizeof(TsuOpParam));
    std::memcpy(buf.data(), &p, sizeof(TsuOpParam));
    return buf;
}

// ---------------- 测试1：从零构建一个 NPU+VDSP 混合模型 ----------------
void Test_BuildFromScratch() {
    OpCtrlBuilder builder;

    // 第一个segment：NPU子图，2核
    uint32_t npu_seg = builder.AddNpuSegment();
    builder.AddNpuCore(npu_seg, NpuCoreInfo{1, 4096, 0, 2, 8192, 0});
    builder.AddNpuCore(npu_seg, NpuCoreInfo{1, 4096, 4096, 2, 8192, 8192});

    // 第二个segment：VDSP子图，3个算子
    uint32_t vdsp_seg = builder.AddVdspSegment();
    uint32_t op1 = builder.AddVdspOp(vdsp_seg, OP_TYPE_RMSNORM, {});
    uint32_t op2 = builder.AddVdspOp(vdsp_seg, OP_TYPE_MATMUL, {});
    uint32_t op3 = builder.AddVdspOp(vdsp_seg, OP_TYPE_CPY, {});

    auto model = builder.Build();

    auto view = model->GetOpExecutionOrder();
    // NPU segment作为1个整体节点 + 3个VDSP算子 = 4个节点
    assert(view->GetOpCount() == 4);
    assert(view->At(0).segment_type == SEG_TYPE_NPU);
    assert(view->At(1).global_op_id == op1);
    assert(view->At(2).global_op_id == op2);
    assert(view->At(3).global_op_id == op3);
    assert(view->At(2).depend_id == op1);
    assert(view->At(3).depend_id == op2);

    std::cout << "[PASS] Test_BuildFromScratch\n";
}

// ---------------- 测试2：插入TSU算子后，查询顺序与依赖链是否正确 ----------------
void Test_InsertTsuOp() {
    OpCtrlBuilder builder;
    uint32_t vdsp_seg = builder.AddVdspSegment();
    uint32_t op1 = builder.AddVdspOp(vdsp_seg, OP_TYPE_RMSNORM, {});
    uint32_t op2 = builder.AddVdspOp(vdsp_seg, OP_TYPE_MATMUL, {});

    auto model = builder.Build();

    // 在op2前插入一个异步TSU加载算子
    OpInsertPlan plan;
    TsuOpParam param{0x1000, 0x2000, 4096, /*direction=LOAD*/0, /*run_parallel*/true};
    plan.requests.push_back(TsuInsertRequest{op2, InsertPosition::BEFORE, param});
    bool ok = model->ApplyInsertPlan(plan);
    assert(ok);

    auto view = model->GetOpExecutionOrder();
    assert(view->GetOpCount() == 3); // op1, TSU, op2

    const OpNodeView& n0 = view->At(0);
    const OpNodeView& n1 = view->At(1);
    const OpNodeView& n2 = view->At(2);

    assert(n0.global_op_id == op1);
    assert(n1.local_op_type == OP_TYPE_TSU);
    assert(n1.depend_id == op1);      // 新插入节点依赖前驱op1
    assert(n2.global_op_id == op2);
    assert(n2.depend_id == n1.global_op_id); // op2现在依赖新插入的TSU节点

    std::cout << "[PASS] Test_InsertTsuOp\n";
}

// ---------------- 测试3：插入不存在的锚点应失败，不破坏原结构 ----------------
void Test_InsertInvalidAnchor() {
    OpCtrlBuilder builder;
    uint32_t vdsp_seg = builder.AddVdspSegment();
    builder.AddVdspOp(vdsp_seg, OP_TYPE_RMSNORM, {});
    auto model = builder.Build();

    OpInsertPlan plan;
    TsuOpParam param{0, 0, 0, 0, false};
    plan.requests.push_back(TsuInsertRequest{9999 /*不存在*/, InsertPosition::AFTER, param});
    bool ok = model->ApplyInsertPlan(plan);
    assert(!ok);

    auto view = model->GetOpExecutionOrder();
    assert(view->GetOpCount() == 1); // 未被破坏

    std::cout << "[PASS] Test_InsertInvalidAnchor\n";
}

// ---------------- 测试4：插入不允许作用于NPU segment ----------------
void Test_InsertOnNpuSegmentShouldFail() {
    OpCtrlBuilder builder;
    uint32_t npu_seg = builder.AddNpuSegment();
    builder.AddNpuCore(npu_seg, NpuCoreInfo{1, 100, 0, 1, 100, 0});
    auto model = builder.Build();

    // NPU segment对外呈现的哨兵global_op_id是0xFFFFFFFF，不在op_id_index_里，
    // 因此ApplyInsertPlan会因为找不到锚点而直接失败，验证这一保护逻辑
    OpInsertPlan plan;
    TsuOpParam param{0, 0, 0, 0, false};
    plan.requests.push_back(TsuInsertRequest{0xFFFFFFFF, InsertPosition::BEFORE, param});
    bool ok = model->ApplyInsertPlan(plan);
    assert(!ok);

    std::cout << "[PASS] Test_InsertOnNpuSegmentShouldFail\n";
}

// ---------------- 测试5：序列化 -> 反序列化 往返一致性 ----------------
void Test_SerializeRoundTrip() {
    OpCtrlBuilder builder;
    uint32_t npu_seg = builder.AddNpuSegment();
    builder.AddNpuCore(npu_seg, NpuCoreInfo{1, 2048, 0, 3, 4096, 0});

    uint32_t vdsp_seg = builder.AddVdspSegment();
    uint32_t op1 = builder.AddVdspOp(vdsp_seg, OP_TYPE_RMSNORM, {});
    uint32_t op2 = builder.AddVdspOp(vdsp_seg, OP_TYPE_SOFTMAX_PLACEHOLDER_FIX, {});
    (void)op1;

    auto model = builder.Build();

    OpInsertPlan plan;
    TsuOpParam param{0x100, 0x200, 512, 1, false};
    plan.requests.push_back(TsuInsertRequest{op2, InsertPosition::AFTER, param});
    assert(model->ApplyInsertPlan(plan));

    std::vector<uint8_t> bin = model->SerializeToOpCtrl();

    // 校验header
    OpCtrlHeader header;
    std::memcpy(&header, bin.data(), sizeof(OpCtrlHeader));
    assert(header.magic == OP_CTRL_MAGIC);
    assert(header.total_subgraph_count == 2);
    assert(header.npu_subgraph_count == 1);
    assert(header.vdsp_subgraph_count == 1);
    assert(header.total_size == bin.size());

    // 反序列化回内部结构，比较算子个数和顺序是否一致
    auto reloaded = RuntimeOpCtrlModel::LoadFromOpCtrl(bin.data(), bin.size());
    auto view_before = model->GetOpExecutionOrder();
    auto view_after  = reloaded->GetOpExecutionOrder();
    assert(view_before->GetOpCount() == view_after->GetOpCount());
    for (size_t i = 0; i < view_before->GetOpCount(); ++i) {
        assert(view_before->At(i).global_op_id == view_after->At(i).global_op_id);
        assert(view_before->At(i).segment_type == view_after->At(i).segment_type);
    }

    std::cout << "[PASS] Test_SerializeRoundTrip\n";
}

// ---------------- 测试6：kernel侧顺序扫描能正确按op_count/core_count前进 ----------------
void Test_KernelSideSequentialParse() {
    OpCtrlBuilder builder;
    uint32_t npu_seg = builder.AddNpuSegment();
    builder.AddNpuCore(npu_seg, NpuCoreInfo{1, 100, 0, 1, 200, 0});
    builder.AddNpuCore(npu_seg, NpuCoreInfo{1, 100, 100, 1, 200, 200});

    uint32_t vdsp_seg = builder.AddVdspSegment();
    builder.AddVdspOp(vdsp_seg, OP_TYPE_MATMUL, {});
    builder.AddVdspOp(vdsp_seg, OP_TYPE_CPY, {});

    auto model = builder.Build();
    std::vector<uint8_t> bin = model->SerializeToOpCtrl();

    const uint8_t* base = bin.data();
    OpCtrlHeader header;
    std::memcpy(&header, base, sizeof(OpCtrlHeader));

    size_t offset = sizeof(OpCtrlHeader);
    uint32_t visited_npu = 0, visited_vdsp = 0;

    for (uint32_t i = 0; i < header.total_subgraph_count; ++i) {
        uint32_t seg_type;
        std::memcpy(&seg_type, base + offset, sizeof(uint32_t));
        size_t body_offset = offset + sizeof(uint32_t);

        if (seg_type == SEG_TYPE_NPU) {
            uint32_t core_count;
            std::memcpy(&core_count, base + body_offset, sizeof(uint32_t));
            assert(core_count == 2);
            visited_npu++;
            offset = body_offset + sizeof(uint32_t) + core_count * sizeof(NpuCoreInfoEntry);
        } else {
            uint32_t op_count;
            std::memcpy(&op_count, base + body_offset, sizeof(uint32_t));
            assert(op_count == 2);
            visited_vdsp++;
            offset = body_offset + sizeof(uint32_t) + op_count * sizeof(VdspOpInfoEntry);
        }
    }

    assert(visited_npu == 1 && visited_vdsp == 1);
    assert(offset == bin.size() - 0 /* 未附加param_area时应正好到末尾，若有param_area则offset<=bin.size() */
           || offset <= bin.size());

    std::cout << "[PASS] Test_KernelSideSequentialParse\n";
}

int main() {
    Test_BuildFromScratch();
    Test_InsertTsuOp();
    Test_InsertInvalidAnchor();
    Test_InsertOnNpuSegmentShouldFail();
    Test_SerializeRoundTrip();
    Test_KernelSideSequentialParse();
    std::cout << "All tests passed.\n";
    return 0;
}
