// runtime_op_ctrl_model.cpp
#include "runtime_op_ctrl_model.h"
#include <algorithm>

// ---------------- 反序列化：从op_ctrl二进制加载出内部可变结构 ----------------
std::unique_ptr<RuntimeOpCtrlModel> RuntimeOpCtrlModel::LoadFromOpCtrl(const uint8_t* data, size_t size) {
    auto model = std::make_unique<RuntimeOpCtrlModel>();

    if (size < sizeof(OpCtrlHeader)) throw std::runtime_error("op_ctrl too small");
    OpCtrlHeader header;
    std::memcpy(&header, data, sizeof(OpCtrlHeader));
    if (header.magic != OP_CTRL_MAGIC) throw std::runtime_error("op_ctrl magic mismatch");

    size_t offset = sizeof(OpCtrlHeader);
    model->segments_.reserve(header.total_subgraph_count);

    for (uint32_t i = 0; i < header.total_subgraph_count; ++i) {
        if (offset + sizeof(uint32_t) > size) throw std::runtime_error("op_ctrl truncated at seg_type");
        uint32_t seg_type;
        std::memcpy(&seg_type, data + offset, sizeof(uint32_t));
        size_t body_offset = offset + sizeof(uint32_t);

        InternalSegment seg;
        seg.seg_type = seg_type;

        if (seg_type == SEG_TYPE_NPU) {
            uint32_t core_count;
            std::memcpy(&core_count, data + body_offset, sizeof(uint32_t));
            const NpuCoreInfoEntry* entries =
                reinterpret_cast<const NpuCoreInfoEntry*>(data + body_offset + sizeof(uint32_t));
            seg.npu_core_info.resize(core_count);
            for (uint32_t c = 0; c < core_count; ++c) {
                seg.npu_core_info[c] = NpuCoreInfo{
                    entries[c].cmd_buffer_id, entries[c].cmd_size, entries[c].cmd_offset,
                    entries[c].weight_buffer_id, entries[c].weight_size, entries[c].weight_offset
                };
            }
            offset = body_offset + sizeof(uint32_t) + core_count * sizeof(NpuCoreInfoEntry);

        } else { // SEG_TYPE_VDSP
            uint32_t op_count;
            std::memcpy(&op_count, data + body_offset, sizeof(uint32_t));
            const VdspOpInfoEntry* entries =
                reinterpret_cast<const VdspOpInfoEntry*>(data + body_offset + sizeof(uint32_t));
            seg.vdsp_ops.resize(op_count);
            for (uint32_t o = 0; o < op_count; ++o) {
                InternalVdspOp op;
                op.global_op_id = entries[o].global_op_id;
                op.op_type = entries[o].op_type;
                op.depend_id = entries[o].depend_id;
                op.sync_type = entries[o].sync_type;
                // op_param的实际字节内容来自单独的参数buffer，这里仅保留offset占位，
                // 真实工程中应结合参数buffer一并传入解析，此处从简保留空payload。
                seg.vdsp_ops[o] = std::move(op);
                model->next_global_op_id_ = std::max(model->next_global_op_id_, entries[o].global_op_id + 1);
            }
            offset = body_offset + sizeof(uint32_t) + op_count * sizeof(VdspOpInfoEntry);
        }

        model->segments_.push_back(std::move(seg));
    }

    model->RebuildFullIndex();
    return model;
}

// ---------------- 对外只读查询 ----------------
std::shared_ptr<const IOpSequenceView> RuntimeOpCtrlModel::GetOpExecutionOrder() const {
    std::vector<OpNodeView> nodes;
    for (uint32_t seg_idx = 0; seg_idx < segments_.size(); ++seg_idx) {
        const auto& seg = segments_[seg_idx];
        if (seg.seg_type == SEG_TYPE_NPU) {
            // NPU segment整体作为一个调度单元呈现给用户，不展开每个核
            OpNodeView node{};
            node.global_op_id  = 0xFFFFFFFF; // NPU子图本身不参与TSU插入锚点，用哨兵值
            node.segment_index = seg_idx;
            node.segment_type  = SEG_TYPE_NPU;
            node.local_op_type = 0;
            node.depend_id     = 0;
            nodes.push_back(node);
        } else {
            for (const auto& op : seg.vdsp_ops) {
                OpNodeView node{};
                node.global_op_id  = op.global_op_id;
                node.segment_index = seg_idx;
                node.segment_type  = SEG_TYPE_VDSP;
                node.local_op_type = op.op_type;
                node.depend_id     = op.depend_id;
                nodes.push_back(node);
            }
        }
    }
    return std::make_shared<OpSequenceView>(std::move(nodes));
}

// ---------------- 插入TSU算子 ----------------
uint32_t RuntimeOpCtrlModel::AllocNewGlobalOpId() {
    return next_global_op_id_++;
}

bool RuntimeOpCtrlModel::ApplyInsertPlan(const OpInsertPlan& plan) {
    std::vector<uint32_t> affected_segments;

    for (const auto& req : plan.requests) {
        auto it = op_id_index_.find(req.anchor_global_op_id);
        if (it == op_id_index_.end()) return false; // 锚点不存在

        uint32_t seg_idx = it->second.first;
        uint32_t local_idx = it->second.second;
        InternalSegment& seg = segments_[seg_idx];
        if (seg.seg_type != SEG_TYPE_VDSP) return false; // TSU只允许插入VDSP segment

        uint32_t insert_pos = local_idx + (req.position == InsertPosition::AFTER ? 1 : 0);

        InternalVdspOp new_op;
        new_op.global_op_id = AllocNewGlobalOpId();
        new_op.op_type = OP_TYPE_TSU;
        new_op.op_param.resize(sizeof(TsuOpParam));
        std::memcpy(new_op.op_param.data(), &req.param, sizeof(TsuOpParam));
        new_op.sync_type = req.param.run_parallel ? SYNC_TYPE_ASYNC : SYNC_TYPE_BLOCK;
        new_op.depend_id = 0; // 由RebuildDependChain统一重新赋值

        seg.vdsp_ops.insert(seg.vdsp_ops.begin() + insert_pos, std::move(new_op));
        affected_segments.push_back(seg_idx);
    }

    // 去重后仅重建受影响的segment
    std::sort(affected_segments.begin(), affected_segments.end());
    affected_segments.erase(std::unique(affected_segments.begin(), affected_segments.end()),
                             affected_segments.end());

    for (uint32_t seg_idx : affected_segments) {
        RebuildDependChain(segments_[seg_idx]);
        RebuildOpIdIndexForSegment(seg_idx);
    }
    return true;
}

// 依赖链重排：段内按顺序，令每个算子depend_id指向其前驱的global_op_id
void RuntimeOpCtrlModel::RebuildDependChain(InternalSegment& seg) {
    uint32_t prev_id = 0;
    bool has_prev = false;
    for (auto& op : seg.vdsp_ops) {
        op.depend_id = has_prev ? prev_id : 0;
        prev_id = op.global_op_id;
        has_prev = true;
    }
}

void RuntimeOpCtrlModel::RebuildOpIdIndexForSegment(uint32_t seg_idx) {
    const auto& seg = segments_[seg_idx];
    if (seg.seg_type != SEG_TYPE_VDSP) return;
    for (uint32_t local_idx = 0; local_idx < seg.vdsp_ops.size(); ++local_idx) {
        op_id_index_[seg.vdsp_ops[local_idx].global_op_id] = {seg_idx, local_idx};
    }
}

void RuntimeOpCtrlModel::RebuildFullIndex() {
    op_id_index_.clear();
    for (uint32_t seg_idx = 0; seg_idx < segments_.size(); ++seg_idx) {
        RebuildOpIdIndexForSegment(seg_idx);
    }
}

// ---------------- 序列化：内部结构 -> 最终op_ctrl二进制 ----------------
std::vector<uint8_t> RuntimeOpCtrlModel::SerializeToOpCtrl() const {
    std::vector<uint8_t> buffer;

    uint32_t npu_count = 0, vdsp_count = 0;
    for (const auto& seg : segments_) {
        if (seg.seg_type == SEG_TYPE_NPU) npu_count++;
        else vdsp_count++;
    }

    OpCtrlHeader header{};
    header.magic = OP_CTRL_MAGIC;
    header.version = OP_CTRL_VERSION;
    header.total_subgraph_count = static_cast<uint32_t>(segments_.size());
    header.npu_subgraph_count = npu_count;
    header.vdsp_subgraph_count = vdsp_count;
    header.total_size = 0; // 最后回填

    buffer.resize(sizeof(OpCtrlHeader));
    std::memcpy(buffer.data(), &header, sizeof(OpCtrlHeader));

    // 独立的算子参数区，op_param_offset相对该区起始地址；实际工程中可与op_ctrl分开管理，
    // 这里为了完整性一并附在op_ctrl尾部，通过header扩展一个param_area_offset字段即可，
    // 为保持本次讨论的结构不变，此处仅示意参数写入逻辑。
    std::vector<uint8_t> param_area;

    auto append_u32 = [&buffer](uint32_t v) {
        size_t old = buffer.size();
        buffer.resize(old + sizeof(uint32_t));
        std::memcpy(buffer.data() + old, &v, sizeof(uint32_t));
    };

    for (const auto& seg : segments_) {
        append_u32(seg.seg_type);

        if (seg.seg_type == SEG_TYPE_NPU) {
            append_u32(static_cast<uint32_t>(seg.npu_core_info.size()));
            for (const auto& core : seg.npu_core_info) {
                NpuCoreInfoEntry entry{
                    core.cmd_buffer_id, core.cmd_size, core.cmd_offset,
                    core.weight_buffer_id, core.weight_size, core.weight_offset
                };
                size_t old = buffer.size();
                buffer.resize(old + sizeof(NpuCoreInfoEntry));
                std::memcpy(buffer.data() + old, &entry, sizeof(NpuCoreInfoEntry));
            }
        } else {
            append_u32(static_cast<uint32_t>(seg.vdsp_ops.size()));
            for (const auto& op : seg.vdsp_ops) {
                uint32_t param_offset = static_cast<uint32_t>(param_area.size());
                param_area.insert(param_area.end(), op.op_param.begin(), op.op_param.end());

                VdspOpInfoEntry entry{
                    op.global_op_id, op.op_type, param_offset, op.depend_id, op.sync_type
                };
                size_t old = buffer.size();
                buffer.resize(old + sizeof(VdspOpInfoEntry));
                std::memcpy(buffer.data() + old, &entry, sizeof(VdspOpInfoEntry));
            }
        }
    }

    // 参数区拼接在末尾（工程中建议header加一个param_area_offset字段显式标出边界）
    buffer.insert(buffer.end(), param_area.begin(), param_area.end());

    uint32_t total_size = static_cast<uint32_t>(buffer.size());
    std::memcpy(buffer.data() + offsetof(OpCtrlHeader, total_size), &total_size, sizeof(uint32_t));

    return buffer;
}
