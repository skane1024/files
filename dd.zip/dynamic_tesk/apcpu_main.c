/*
 * apcpu_main.c - APCPU task dispatcher for AISYS
 *
 * Dual-platform source:
 *   RISC-V (__riscv defined): baremetal firmware, reads from fixed memory
 *     addresses, dispatches to VDSP via IPC polling.
 *   x86 (__riscv undefined): debug build, reads input from binary files,
 *     dumps parsed aisys_task to stdout for verification.
 *
 * Shared logic (fill_tensor_segment, fill_vector_segment, copy_nsid, etc.)
 * is compiled identically on both platforms — only the I/O layer differs.
 *
 * x86 build:
 *   cd x86 && mkdir -p build && cd build
 *   cmake .. && make
 *   ./apcpu_task_x86
 *
 * Input files (placed in the working directory):
 *   model_submit_msg.bin  - raw binary of unisoc_model_submit_message
 *   cv_model_buf_desc.bin - raw binary of cv_model_buf_desc
 */

#include "apcpu.h"

/* ========================================================================
 *  Platform-specific includes
 * ======================================================================== */
#ifndef __riscv
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#endif

/* ========================================================================
 *  Static allocation for the aisys_task structure.
 * ======================================================================== */

#ifdef __riscv
static uint8_t __attribute__((aligned(64)))
    aisys_task_buffer[4096];
#else
static uint8_t __attribute__((aligned(64)))
    aisys_task_buffer[4096];
#endif

/* ========================================================================
 *  cv_model_buf_desc based buffer query implementation (test stub)
 *
 *  In production, replace this with the real buffer management interface.
 * ======================================================================== */

static const struct cv_model_buf_desc *g_buf_desc = NULL;

static uint32_t stub_get_addr(uint32_t buf_id)
{
    uint32_t i;
    if (!g_buf_desc) return 0;
    for (i = 0; i < g_buf_desc->buf_num; i++) {
        if (g_buf_desc->buf_desc[i].buf_id == buf_id)
            return g_buf_desc->buf_desc[i].buf_addr;
    }
    return 0;
}

static uint32_t stub_get_map_flags(uint32_t buf_id)
{
    uint32_t i;
    if (!g_buf_desc) return 0;
    for (i = 0; i < g_buf_desc->buf_num; i++) {
        if (g_buf_desc->buf_desc[i].buf_id == buf_id)
            return g_buf_desc->buf_desc[i].map_flags;
    }
    return 0;
}

static const struct buf_query_ops g_stub_buf_ops = {
    .get_addr      = stub_get_addr,
    .get_map_flags = stub_get_map_flags,
};

/* ========================================================================
 *  Helper: copy nsid from model message into segment task
 *  Both have the same layout: [AISYS_NSID_STR_LEN][MAX_SUPPORT_NSID]
 * ======================================================================== */

static void copy_nsid(struct aisys_segment_task *seg_task,
                      const struct unisoc_model_submit_message *model_msg)
{
    uint32_t i;
    for (i = 0; i < MAX_SUPPORT_NSID; i++) {
        uint32_t j;
        for (j = 0; j < AISYS_NSID_STR_LEN; j++) {
            seg_task->nsid[j][i] = model_msg->nsid_name[j][i];
        }
    }
}

/* ========================================================================
 *  Helper: fill a TENSOR segment_task from vha_user_cnn_submit_multi_cmd
 *
 *  Uses buf_query_ops for buffer address/map_flags lookup.
 *  cmdbuf[i] + cmdbuf_offset[i] → cmdstream[i]
 *  cmdbuf_size[i]               → cmdstream_size[i]
 *  bufs[i] + bufoffsets[i]      → alt_addr[regidx[i]]
 * ======================================================================== */

static void fill_tensor_segment(
    struct aisys_segment_task *seg_task,
    const struct vha_user_cnn_submit_multi_cmd *multi_cmd,
    const struct buf_query_ops *bops,
    const struct unisoc_model_submit_message *model_msg,
    uint64_t seg_op_ctrl_addr,
    uint64_t op_param_base)
{
    uint32_t i;

    seg_task->op_ctrl_addr  = seg_op_ctrl_addr;
    seg_task->op_param_addr = op_param_base;
    seg_task->npu_core_num  = multi_cmd->num_cores;
    seg_task->vdsp_num      = 0;
    seg_task->seg_type      = OPCTRL_SEGTYPE_TENSOR;

    for (i = 0; i < AISYS_ALT_ADDR_NUM; i++) {
        seg_task->alt_addr[i] = 0;
        seg_task->req_type[i] = 0;
    }

    for (i = 0; i < VHA_CORE_MAX_ALT_ADDRS; i++) {
        uint8_t  reg_idx = multi_cmd->regidx[i];
        uint32_t buf_id  = multi_cmd->bufs[i];
        uint32_t offset  = multi_cmd->bufoffsets[i];

        if (buf_id == 0 || reg_idx >= AISYS_ALT_ADDR_NUM)
            continue;

        uint32_t buf_addr = bops->get_addr(buf_id);
        if (buf_addr != 0) {
            seg_task->alt_addr[reg_idx] = (uint64_t)buf_addr + offset;
            seg_task->req_type[reg_idx] =
                cv_map_flags_to_req_type(bops->get_map_flags(buf_id));
        }
    }

    for (i = 0; i < VHA_MAX_CORES && i < AISYS_CLUSTER_NPU_NUM; i++) {
        uint32_t cs_buf_id = multi_cmd->cmdbuf[i];
        if (cs_buf_id != 0) {
            uint32_t cs_addr = bops->get_addr(cs_buf_id);
            seg_task->cmdstream[i]      = (uint64_t)cs_addr + multi_cmd->cmdbuf_offset[i];
            seg_task->cmdstream_size[i] = multi_cmd->cmdbuf_size[i];
        } else {
            seg_task->cmdstream[i]      = 0;
            seg_task->cmdstream_size[i] = 0;
        }
    }

    copy_nsid(seg_task, model_msg);
}

/* ========================================================================
 *  Helper: fill a VECTOR segment_task from unisoc_vdsp_opctrl
 * ======================================================================== */

static void fill_vector_segment(
    struct aisys_segment_task *seg_task,
    const struct unisoc_vdsp_opctrl *vdsp_op,
    const struct unisoc_model_submit_message *model_msg,
    uint64_t seg_op_ctrl_addr,
    uint64_t op_param_base)
{
    uint32_t i;

    seg_task->op_ctrl_addr  = seg_op_ctrl_addr;
    seg_task->op_param_addr = op_param_base + vdsp_op->op_param_offset;
    seg_task->npu_core_num  = vdsp_op->npu_num;
    seg_task->vdsp_num      = vdsp_op->vdsp_num;
    seg_task->seg_type      = OPCTRL_SEGTYPE_VECTOR;

    for (i = 0; i < AISYS_ALT_ADDR_NUM; i++) {
        seg_task->alt_addr[i] = 0;
        seg_task->req_type[i] = 0;
    }

    for (i = 0; i < AISYS_CLUSTER_NPU_NUM; i++) {
        seg_task->cmdstream[i]      = 0;
        seg_task->cmdstream_size[i] = 0;
    }

    copy_nsid(seg_task, model_msg);
}

/* ========================================================================
 *  Core parsing logic: shared between RISC-V and x86
 *
 *  Given a model_msg, buf_ops, and op_ctrl/op_param buffer data,
 *  parse into aisys_task and return the task pointer.
 * ======================================================================== */

struct aisys_task *
parse_model_to_aisys_task(
    const struct unisoc_model_submit_message *model_msg,
    const struct buf_query_ops *bops,
    const uint8_t *op_ctrl_buf_data)    /* raw op_ctrl buffer bytes */
{
    uint32_t rank_idx, block_idx, seg_idx;
    struct aisys_task *task = (struct aisys_task *)aisys_task_buffer;

    /* Fill task header */
    task->cmd_id        = model_msg->msg.cmd_id;
    task->cluster_num   = model_msg->num_rank;
    task->npu_num       = 0;
    task->vdsp_num      = 0;
    task->gsc_event_num = 0;

    struct aisys_block_task *current_block = task->block_task;

    const struct unisoc_model_rank_submit_message *rank_array = get_rank_array(model_msg);
    const uint32_t *block_of_rank = get_block_of_rank(model_msg);

    uint32_t seg_of_block_offset = 0;

    for (rank_idx = 0; rank_idx < model_msg->num_rank; rank_idx++) {
        const struct unisoc_model_rank_submit_message *rank_msg = &rank_array[rank_idx];
        uint32_t blocks_in_rank = block_of_rank[rank_idx];

        for (block_idx = 0; block_idx < blocks_in_rank; block_idx++) {
            const struct sprd_npu_model_block_submit_message *blk =
                &rank_msg->block[block_idx];

            uint32_t segments_in_block =
                get_seg_of_block(model_msg)[seg_of_block_offset + block_idx];

            /* Resolve op_ctrl/op_param buffer addresses */
            uint32_t op_ctrl_buf_id  = (uint32_t)(blk->op_ctrl_id & 0xFFFFFFFF);
            uint32_t op_param_buf_id = (uint32_t)(blk->op_param_id & 0xFFFFFFFF);
            uint32_t op_ctrl_offset  = (uint32_t)(blk->op_ctrl_offset & 0xFFFFFFFF);
            uint32_t op_param_offset = (uint32_t)(blk->op_param_offset & 0xFFFFFFFF);

            uint64_t op_ctrl_base = (uint64_t)bops->get_addr(op_ctrl_buf_id);
            uint64_t op_param_base = (uint64_t)bops->get_addr(op_param_buf_id) + op_param_offset;

            uint64_t seg_op_ctrl_base = op_ctrl_base + op_ctrl_offset;

            /* Fill block header */
            current_block->block_id    = blk->block_id;
            current_block->cluster_id  = blk->rank_id;
            current_block->segment_num = segments_in_block;

            /* Parse segments from op_ctrl buffer */
            struct aisys_segment_task *seg_ptr = current_block->segment_task;
            const uint8_t *op_ctrl_ptr = op_ctrl_buf_data + op_ctrl_offset;

            for (seg_idx = 0; seg_idx < segments_in_block; seg_idx++) {
                uint32_t seg_type = *(const uint32_t *)op_ctrl_ptr;

                if (seg_type == OPCTRL_SEGTYPE_TENSOR) {
                    const struct unisoc_npu_opctrl *npu_op =
                        (const struct unisoc_npu_opctrl *)op_ctrl_ptr;
                    const struct vha_user_cnn_submit_multi_cmd *multi_cmd;
                    multi_cmd = (const struct vha_user_cnn_submit_multi_cmd *)
                        (const void *)(op_ctrl_ptr + 4);

                    fill_tensor_segment(seg_ptr, multi_cmd,
                        bops, model_msg,
                        seg_op_ctrl_base + (uint64_t)(op_ctrl_ptr - (op_ctrl_buf_data + op_ctrl_offset)),
                        op_param_base);

                    task->npu_num += npu_op->multi_cmd.num_cores;
                    op_ctrl_ptr += sizeof(struct unisoc_npu_opctrl);

                } else if (seg_type == OPCTRL_SEGTYPE_VECTOR) {
                    const struct unisoc_vdsp_opctrl *vdsp_op =
                        (const struct unisoc_vdsp_opctrl *)op_ctrl_ptr;

                    fill_vector_segment(seg_ptr, vdsp_op, model_msg,
                        seg_op_ctrl_base + (uint64_t)(op_ctrl_ptr - (op_ctrl_buf_data + op_ctrl_offset)),
                        op_param_base);

                    task->npu_num  += vdsp_op->npu_num;
                    task->vdsp_num += vdsp_op->vdsp_num;
                    op_ctrl_ptr += sizeof(struct unisoc_vdsp_opctrl);

                } else {
                    panic();
                }

                seg_ptr++;
            }

            /* Advance block_task pointer */
            current_block = (struct aisys_block_task *)
                ((uint8_t *)current_block + sizeof(struct aisys_block_task)
                 + segments_in_block * sizeof(struct aisys_segment_task));
        }

        seg_of_block_offset += blocks_in_rank;
    }

    return task;
}

/* ========================================================================
 *  Platform-specific main entry
 * ======================================================================== */

#ifdef __riscv
/* ------------------------------------------------------------------ */
/*  RISC-V baremetal: hardcoded memory addresses, IPC polling dispatch */
/* ------------------------------------------------------------------ */

void apcpu_main(void)
{
    /* 1. Read model submit message from fixed address */
    const struct unisoc_model_submit_message *model_msg =
        (const struct unisoc_model_submit_message *)UNISOC_MODEL_SUBMIT_MSG_ADDR;

    /* 2. Read buffer descriptor table from fixed address */
    g_buf_desc = (const struct cv_model_buf_desc *)CV_MODEL_BUF_DESC_ADDR;
    const struct buf_query_ops *bops = &g_stub_buf_ops;

    /* 3. The op_ctrl / op_param buffers are also at fixed addresses.
     *    For simplicity, we treat the op_ctrl buffer as starting at
     *    the same address as the model submit message's op_ctrl_id
     *    resolves to via the buf_desc table.  We use the buf query
     *    ops to resolve addresses on the fly inside parse_model_to_aisys_task.
     *
     *    Since on RISC-V we don't have a separate copy of the op_ctrl
     *    buffer data, we set op_ctrl_buf_data = NULL and rely on the
     *    fact that bops->get_addr() returns the physical address, which
     *    is directly accessible.
     */

    struct aisys_task *task = parse_model_to_aisys_task(
        model_msg, bops,
        NULL);          /* op_ctrl_buf_data: not used on RISC-V (direct mem access) */

    /* 4. Write aisys_task address to APCPU->VDSP IPC buffer */
    mem_write64(IPC_APCPU_TO_VDSP_ADDR, (uint64_t)(unsigned long)task);

    /* 5. Poll VDSP->APCPU IPC buffer for completion */
    while (mem_read32(IPC_VDSP_TO_APCPU_ADDR) != AISYS_TASK_DONE_MAGIC) {
        __asm__ volatile("" ::: "memory");
    }

    /* 6. Task complete - clear completion flag */
    mem_write32(IPC_VDSP_TO_APCPU_ADDR, 0);
}

void main(void) __attribute__((weak, alias("apcpu_main")));

#else  /* !__riscv — x86 debug build */
/* ------------------------------------------------------------------ */
/*  x86 debug: read input files, parse, dump aisys_task to stdout     */
/* ------------------------------------------------------------------ */

/* Forward declaration */
static void dump_aisys_task(const struct aisys_task *task);

int main(int argc, char **argv)
{
    const char *model_file = "model_submit_msg.bin";
    const char *bufdesc_file = "cv_model_buf_desc.bin";
    uint8_t model_msg_buf[4096];
    uint8_t buf_desc_buf[4096];
    uint8_t op_ctrl_buf[65536];
    size_t model_size, bufdesc_size, op_ctrl_size;
    FILE *f;

    /* ---- Read model_submit_msg.bin ---- */
    f = fopen(model_file, "rb");
    if (!f) {
        fprintf(stderr, "ERROR: cannot open '%s'\n", model_file);
        return 1;
    }
    model_size = fread(model_msg_buf, 1, sizeof(model_msg_buf), f);
    fclose(f);
    if (model_size < sizeof(struct unisoc_model_submit_message)) {
        fprintf(stderr, "ERROR: '%s' too small (%zu bytes)\n", model_file, model_size);
        return 1;
    }
    printf("[x86] Read %zu bytes from %s\n", model_size, model_file);

    /* ---- Read cv_model_buf_desc.bin ---- */
    f = fopen(bufdesc_file, "rb");
    if (!f) {
        fprintf(stderr, "ERROR: cannot open '%s'\n", bufdesc_file);
        return 1;
    }
    bufdesc_size = fread(buf_desc_buf, 1, sizeof(buf_desc_buf), f);
    fclose(f);
    if (bufdesc_size < sizeof(struct cv_model_buf_desc)) {
        fprintf(stderr, "ERROR: '%s' too small (%zu bytes)\n", bufdesc_file, bufdesc_size);
        return 1;
    }
    printf("[x86] Read %zu bytes from %s\n", bufdesc_size, bufdesc_file);

    /* ---- Set up buffer query ops ---- */
    g_buf_desc = (const struct cv_model_buf_desc *)buf_desc_buf;
    const struct buf_query_ops *bops = &g_stub_buf_ops;

    /* ---- Read op_ctrl buffer data (optional) ----
     * The op_ctrl buffer is referenced by ID in the model message.
     * We look up its ID from the buf_desc, read the corresponding file,
     * and pass the data to the parser.
     */
    printf("[x86] Buffer descriptor table:\n");
    uint32_t i;
    for (i = 0; i < g_buf_desc->buf_num; i++) {
        printf("  buf[%u]: id=%u addr=0x%08x flags=0x%08x\n",
               i,
               g_buf_desc->buf_desc[i].buf_id,
               g_buf_desc->buf_desc[i].buf_addr,
               g_buf_desc->buf_desc[i].map_flags);
    }

    /* For op_ctrl data, we need to read the buffer that contains the
     * op_ctrl segments.  The buf_desc tells us the buffer ID → address
     * mapping.  We'll try to load "op_ctrl_buf.bin" if it exists.
     */
    memset(op_ctrl_buf, 0, sizeof(op_ctrl_buf));
    f = fopen("op_ctrl_buf.bin", "rb");
    if (f) {
        op_ctrl_size = fread(op_ctrl_buf, 1, sizeof(op_ctrl_buf), f);
        fclose(f);
        printf("[x86] Read %zu bytes from op_ctrl_buf.bin\n", op_ctrl_size);
    } else {
        printf("[x86] No op_ctrl_buf.bin found — op_ctrl data will be all-zero\n");
        op_ctrl_size = 0;
    }

    /* ---- Parse ---- */
    struct aisys_task *task = parse_model_to_aisys_task(
        (const struct unisoc_model_submit_message *)model_msg_buf,
        bops,
        op_ctrl_buf);       /* op_ctrl raw data */

    /* ---- Dump result ---- */
    printf("\n");
    dump_aisys_task(task);

    return 0;
}

/* ========================================================================
 *  Dump aisys_task to stdout in human-readable form
 * ======================================================================== */

static void print_nsid(const struct aisys_segment_task *seg, uint32_t nsid_idx)
{
    uint32_t j;
    printf("\"");
    for (j = 0; j < AISYS_NSID_STR_LEN; j++) {
        char c = (char)seg->nsid[j][nsid_idx];
        if (c >= 32 && c < 127)
            putchar(c);
        else if (c == 0)
            break;
        else
            printf("\\x%02x", (unsigned char)c);
    }
    printf("\"");
}

static const char *seg_type_str(uint32_t t)
{
    switch (t) {
    case OPCTRL_SEGTYPE_TENSOR: return "TENSOR";
    case OPCTRL_SEGTYPE_VECTOR: return "VECTOR";
    default:                    return "UNKNOWN";
    }
}

static void dump_aisys_task(const struct aisys_task *task)
{
    uint32_t i, j, k;
    const struct aisys_block_task *blk = task->block_task;

    printf("========================================\n");
    printf("  aisys_task @ %p\n", (void *)task);
    printf("========================================\n");
    printf("  cmd_id        = %u\n", task->cmd_id);
    printf("  cluster_num   = %u\n", task->cluster_num);
    printf("  npu_num       = %u\n", task->npu_num);
    printf("  vdsp_num      = %u\n", task->vdsp_num);
    printf("  gsc_event_num = %u\n", task->gsc_event_num);
    printf("\n");

    for (i = 0; i < task->cluster_num; i++) {
        printf("  ---- Block[%u] ----\n", i);
        printf("    block_id    = %u\n", blk[i].block_id);
        printf("    cluster_id  = %u\n", blk[i].cluster_id);
        printf("    segment_num = %u\n", blk[i].segment_num);

        for (j = 0; j < blk[i].segment_num; j++) {
            const struct aisys_segment_task *seg = &blk[i].segment_task[j];

            printf("\n    === Segment[%u] ===\n", j);
            printf("      type          = %s (%u)\n", seg_type_str(seg->seg_type), seg->seg_type);
            printf("      op_ctrl_addr  = 0x%016llx\n", (unsigned long long)seg->op_ctrl_addr);
            printf("      op_param_addr = 0x%016llx\n", (unsigned long long)seg->op_param_addr);
            printf("      npu_core_num  = %u\n", seg->npu_core_num);
            printf("      vdsp_num      = %u\n", seg->vdsp_num);

            printf("      nsid:");
            for (k = 0; k < MAX_SUPPORT_NSID; k++) {
                printf(" [%u]=", k);
                print_nsid(seg, k);
            }
            printf("\n");

            printf("      alt_addr/req_type:\n");
            for (k = 0; k < AISYS_ALT_ADDR_NUM; k++) {
                if (seg->alt_addr[k] != 0 || seg->req_type[k] != 0) {
                    printf("        [%2u] addr=0x%016llx req_type=%u\n",
                           k, (unsigned long long)seg->alt_addr[k], seg->req_type[k]);
                }
            }

            printf("      cmdstream/size:\n");
            for (k = 0; k < AISYS_CLUSTER_NPU_NUM; k++) {
                printf("        [%u] addr=0x%016llx size=%u\n",
                       k, (unsigned long long)seg->cmdstream[k], seg->cmdstream_size[k]);
            }
        }

        /* Advance to next block */
        blk = (const struct aisys_block_task *)
            ((const uint8_t *)&blk[i] + sizeof(struct aisys_block_task)
             + blk[i].segment_num * sizeof(struct aisys_segment_task));
    }

    printf("\n========================================\n");
    printf("  End of aisys_task dump\n");
    printf("========================================\n");
}

#endif /* __riscv / !__riscv */