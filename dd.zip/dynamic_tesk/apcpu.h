/*
 * apcpu.h - APCPU baremetal structures and definitions for AISYS task dispatch
 *
 * This header defines the data structures used by APCPU (RISC-V, baremetal)
 * to read task information from shared memory, parse it into aisys_task
 * format, and communicate with VDSP via polling IPC buffers.
 *
 * Memory map:
 *   0x19b00000 - unisoc_model_submit_message (input task info)
 *   0x19b01000 - cv_model_buf_desc (buffer descriptors)
 *   0x19b02000 - IPC buffer: APCPU -> VDSP (aisys_task address)
 *   0x19b03000 - IPC buffer: VDSP -> APCPU (completion status)
 */

#ifndef _APCPU_H
#define _APCPU_H

/* ========================================================================
 *  Compiler/Platform Abstraction
 * ======================================================================== */
typedef unsigned char      uint8_t;
typedef unsigned short     uint16_t;
typedef unsigned int       uint32_t;
typedef unsigned long long uint64_t;

#define NULL  ((void *)0)

/* ========================================================================
 *  Constants
 * ======================================================================== */

/* Memory-mapped register / buffer addresses */
#define UNISOC_MODEL_SUBMIT_MSG_ADDR    ((volatile void *)0x19b00000)
#define CV_MODEL_BUF_DESC_ADDR          ((volatile void *)0x19b01000)
#define IPC_APCPU_TO_VDSP_ADDR          ((volatile uint64_t *)0x19b02000)
#define IPC_VDSP_TO_APCPU_ADDR          ((volatile uint32_t *)0x19b03000)

/* AISYS task structure dimensions */
#define AISYS_ALT_ADDR_NUM      18      /* Number of alt address registers */
#define AISYS_CLUSTER_NPU_NUM   8       /* Max NPU cores per cluster */
#define AISYS_NSID_STR_LEN      16      /* NSID string length */

/* Model submission message dimensions */
#define MAX_SUPPORT_NSID        8       /* Max NSID entries */
#define MAX_SUPPORT_BLOCK       32      /* Max blocks across all ranks */
#define MAX_SUPPORT_SEG         64      /* Max segments across all blocks */
#define MAX_SUPPORT_EVENT       8       /* Max GSC event groups */

/* VHA dimensions (from vha.h, overridden as needed) */
#define VHA_CORE_MAX_ALT_ADDRS  18      /* Max alt addr entries per cmd */
#define VHA_MAX_CORES           8       /* Max cores */
#define VHA_OCM_TYPE_MAX        2       /* OCM types */

/* Completion status value written by VDSP */
#define AISYS_TASK_DONE_MAGIC   0x00000001

/* OpCtrl segment types */
#define OPCTRL_SEGTYPE_TENSOR   0       /* NPU tensor operation segment */
#define OPCTRL_SEGTYPE_VECTOR   1       /* VDSP vector operation segment */

/* ========================================================================
 *  Buffer Descriptor (from cv shared memory, at 0x19b01000)
 * ======================================================================== */

struct cv_buf_desc {
    uint32_t buf_id;                    /* Buffer identifier */
    uint32_t buf_addr;                  /* Buffer base address (physical) */
    uint32_t map_flags;                 /* Mapping flags:
                                         *   bit 3 (0x08) -> req_type = 0
                                         *   bit 2 (0x04) -> req_type = 1 */
};

struct cv_model_buf_desc {
    uint32_t buf_num;                   /* Number of buffer descriptors */
    struct cv_buf_desc buf_desc[0];     /* Variable-length array of descriptors */
};

/* ========================================================================
 *  VHA User Command (from user-space / kernel interface)
 * ======================================================================== */

struct vha_user_cmd {
    uint32_t cmd_id;                    /* Command ID */
    uint16_t cmd_type;                  /* Command type (enum vha_cmd_type) */
    uint16_t flags;                     /* Flags (VHA_CMDFLAG_xxx) */
    uint32_t group_id;                  /* Group ID */
    uint16_t grp_cmd_idx;               /* Index within group */
    uint16_t grp_cmd_num;               /* Total commands in group */
    uint8_t  priority;                  /* Priority */
    uint8_t  padding;                   /* Padding */
    uint8_t  num_bufs;                  /* Total number of buffers */
    uint8_t  num_inbufs;                /* Number of input buffers */
    uint32_t data[0];                   /* Variable-length data */
} __attribute__((aligned(8)));

/* ========================================================================
 *  CNN Submit Multi Command (one per segment, stored in op_ctrl buffer)
 *  Added cmdbuf_offset & cmdbuf_size for cmdstream sub-range.
 * ======================================================================== */

struct vha_user_cnn_submit_multi_cmd {
    uint32_t cmdbuf[VHA_MAX_CORES];             /* cmdstream buffer IDs */
    uint32_t cmdbuf_offset[VHA_MAX_CORES];                     /* offset within cmdstream buffer */
    uint32_t cmdbuf_size[VHA_MAX_CORES];                       /* size of cmdstream data */
    uint32_t bufs[VHA_CORE_MAX_ALT_ADDRS];      /* buffer IDs for alt regs */
    uint32_t bufoffsets[VHA_CORE_MAX_ALT_ADDRS];/* offsets into buffers */
    uint32_t bufsizes[VHA_CORE_MAX_ALT_ADDRS];  /* sizes of buffers */
    uint8_t  regidx[VHA_CORE_MAX_ALT_ADDRS];    /* register index for each buf */
    uint8_t  num_cores;                         /* NPU core count */
    uint32_t onchipram_bufs[VHA_OCM_TYPE_MAX];  /* OCM buffer IDs */
    uint32_t crcs[VHA_MAX_CORES];               /* CRC (unused) */
    uint64_t exec_time;                         /* (unused) */
    uint32_t shared_circ_buf_offs;              /* (unused) */
    uint32_t estimates_cycles;                  /* (unused) */
    uint64_t expected_ip_capab;                 /* (unused) */
    uint64_t hw_brns;                           /* (unused) */
} __attribute__((aligned(8)));

/* ========================================================================
 *  OpCtrl Segment: TENSOR (NPU) type
 *  Laid out sequentially in the op_ctrl buffer.
 * ======================================================================== */

struct unisoc_npu_opctrl {
    uint32_t segment_type;                          /* OPCTRL_SEGTYPE_TENSOR */
    struct vha_user_cnn_submit_multi_cmd multi_cmd;
} __attribute__((packed));

/* ========================================================================
 *  OpCtrl Segment: VECTOR (VDSP) type
 *  Laid out sequentially in the op_ctrl buffer.
 * ======================================================================== */

struct unisoc_vdsp_opctrl {
    uint32_t segment_type;                          /* OPCTRL_SEGTYPE_VECTOR */
    uint64_t op_param_offset;                       /*叠加到block的op_param_offset */
    uint32_t op_id;                                 /* 算子ID */
    uint32_t depend_op_id;                          /* 依赖的算子ID */
    uint32_t op_sync_type;                          /* 同步类型 */
} __attribute__((packed));

/* ========================================================================
 *  Block Submit Message (one per block)
 *  NOTE: vha_user_cnn_submit_multi_cmd is now inside the op_ctrl buffer,
 *        NOT in this structure.
 * ======================================================================== */

struct sprd_npu_model_block_submit_message {
    uint32_t rank_id;                           /* Rank ID */
    uint32_t num_block;                         /* Total blocks in rank */
    uint32_t block_id;                          /* This block's ID */
    uint32_t num_segment;                       /* Segments in this block */
    uint64_t op_ctrl_id;                        /* op_ctrl buffer ID */
    uint64_t op_ctrl_offset;                    /* offset within op_ctrl buf */
    uint64_t op_param_id;                       /* op_param buffer ID */
    uint64_t op_param_offset;                   /* offset within op_param buf */
} __attribute__((aligned(8)));

/* ========================================================================
 *  Rank Submit Message (one per rank)
 * ======================================================================== */

struct unisoc_model_rank_submit_message {
    uint32_t num_rank;                          /* Total ranks in model */
    uint32_t rank_id;                           /* This rank's ID */
    uint32_t num_block;                         /* Blocks in this rank */
    struct sprd_npu_model_block_submit_message block[0];
} __attribute__((aligned(8)));

/* ========================================================================
 *  Top-Level Model Submit Message (at 0x19b00000)
 * ======================================================================== */

struct unisoc_model_submit_message {
    struct vha_user_cmd msg;                    /* Common command header */
    uint32_t num_nsid;                          /* Number of NSID entries */
    uint64_t nsid_addr[MAX_SUPPORT_NSID];       /* NSID addresses */
    uint32_t opdesc_buf;                        /* Buffer ID for op descriptor */
    uint32_t num_rank;                          /* Number of ranks */
    uint32_t block_of_rank[MAX_SUPPORT_BLOCK];  /* Blocks per rank */
    uint32_t seg_of_block[MAX_SUPPORT_SEG];     /* Segments per block */
    uint32_t event_num;                         /* GSC event group count */
    uint32_t event_bufs_type[MAX_SUPPORT_EVENT];/* Event buffer types */
    uint32_t event_bufs_id[MAX_SUPPORT_EVENT];  /* Event buffer IDs */
    struct unisoc_model_rank_submit_message rank[0];
} __attribute__((aligned(8)));

/* ========================================================================
 *  AISYS Task Structures (target format for VDSP)
 * ======================================================================== */

struct aisys_segment_task {
    uint64_t op_ctrl_addr;                      /* op_ctrl buffer address + offset */
    uint64_t op_param_addr;                     /* op_param buffer address + offset */
    uint32_t npu_core_num;                      /* Number of NPU cores */
    uint64_t alt_addr[AISYS_ALT_ADDR_NUM];      /* Alt register addresses (by regidx) */
    uint32_t req_type[AISYS_ALT_ADDR_NUM];      /* Request types (by regidx) */
    uint8_t  nsid[MAX_SUPPORT_NSID][AISYS_NSID_STR_LEN]; /* NSID strings */
    uint64_t cmdstream[AISYS_CLUSTER_NPU_NUM];  /* cmdstream buffer addresses */
};

struct aisys_block_task {
    uint32_t block_id;                          /* Block ID */
    uint32_t cluster_id;                        /* Cluster ID */
    uint32_t segment_num;                       /* Number of segments */
    struct aisys_segment_task segment_task[0];   /* Variable-length segment array */
};

struct aisys_task {
    uint32_t cmd_id;                            /* Command ID */
    uint32_t cluster_num;                       /* Number of clusters (= rank count) */
    uint32_t npu_num;                           /* Number of NPU cores */
    uint32_t vdsp_num;                          /* Number of VDSP cores */
    uint32_t gsc_event_num;                     /* GSC event count */
    struct aisys_block_task block_task[0];       /* Variable-length block array */
};

/* ========================================================================
 *  Helper: get req_type from cv_buf_desc.map_flags
 * ======================================================================== */

static inline uint32_t cv_map_flags_to_req_type(uint32_t map_flags)
{
    /* bit 3 (0x08) -> req_type = 0
     * bit 2 (0x04) -> req_type = 1
     * Default to 0 if neither bit is set. */
    if (map_flags & (1u << 3))
        return 0;
    if (map_flags & (1u << 2))
        return 1;
    return 0;
}

/* ========================================================================
 *  Helper: read/write volatile memory
 * ======================================================================== */

static inline uint32_t reg_read32(volatile void *addr)
{
    return *(volatile uint32_t *)addr;
}

static inline void reg_write32(volatile void *addr, uint32_t val)
{
    *(volatile uint32_t *)addr = val;
}

static inline void reg_write64(volatile void *addr, uint64_t val)
{
    *(volatile uint64_t *)addr = val;
}

#endif /* _APCPU_H */