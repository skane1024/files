# OpCtrl 接口重构计划

## Context

重构 op_ctrl 构建接口，支持两种构建方式：
1. 直接加载 op_ctrl 文件
2. 从空构建，逐个添加 NPU/VDSP segment（传入指针）

NPU segment 格式变更为 `unisoc_npu_opctrl`（内含 `vha_user_cnn_submit_multi_cmd`），保留 TSU 动态插入功能。

## 常量

```
VHA_MAX_CORES = 8
VHA_CORE_MAX_ALT_ADDRS = 16
VHA_OCM_TYPE_MAX = 4
```

## 二进制格式

```
[OpCtrlHeader]
[unisoc_npu_opctrl]                                   // NPU: 自带 segment_type=0
[seg_type=1=VDSP][op_count][VdspOpInfoEntry[]]        // VDSP: 格式不变
[param_area]                                           // VDSP 参数区
```

解析逻辑：读首个 uint32_t → 0=TENSOR/NPU 按 `unisoc_npu_opctrl` 读；1=VDSP 按旧格式读。

## 关键设计决策

- **NPU segment**：存储 `vha_user_cnn_submit_multi_cmd`，整体作为一个调度单元，不支持 TSU 插入
- **VDSP segment**：内部仍解析为 `vector<InternalVdspOp>` 以支持 TSU 插入；Builder 接口传入 raw binary（不含 seg_type，格式为 `[op_count][VdspOpInfoEntry[]]`），内部解析
- **保留 TSU 插入**：`ApplyInsertPlan`、`RebuildDependChain` 等功能不变

## 实现步骤

### 1. 更新 data_types.h

- 添加 VHA 常量（`VHA_MAX_CORES=8`, `VHA_CORE_MAX_ALT_ADDRS=16`, `VHA_OCM_TYPE_MAX=4`）
- 添加 `vha_user_cnn_submit_multi_cmd` 结构体（`__attribute__((aligned(8)))`）
- 添加 `unisoc_npu_opctrl` 结构体（`__attribute__((packed))`）
- 删除旧 `NpuCoreInfoEntry`
- 保留 `VdspOpInfoEntry`
- 添加 `OPCTRL_SEGTYPE_TENSOR = 0`

### 2. 合并头文件 → op_ctrl_model.h

合并 `runtime_op_ctrl_model.h` + `op_ctrl_builder.h`：

- **删除** `NpuCoreInfo` 结构体
- **InternalSegment** 修改：
  - NPU 字段：`vha_user_cnn_submit_multi_cmd npu_multi_cmd`（替代 `vector<NpuCoreInfo>`）
  - VDSP 字段：`vector<InternalVdspOp> vdsp_ops`（保留，支持 TSU 插入）
- **保留** `InternalVdspOp`、TSU 相关类型（`TsuOpParam`、`TsuInsertRequest`、`OpInsertPlan`、`InsertPosition`）
- **OpCtrlBuilder** 接口修改：
  - `uint32_t AddNpuSegment(const unisoc_npu_opctrl* npu_ctrl)` — 传入指针，内部拷贝 `multi_cmd`
  - `uint32_t AddVdspSegment(const void* data, size_t size)` — 传入 VDSP raw binary（不含 seg_type），内部解析为 `InternalVdspOp[]`
  - 删除 `AddNpuCore`、`AddVdspOp`
- **RuntimeOpCtrlModel** 接口不变，内部实现更新：
  - `LoadFromOpCtrl` / `SerializeToOpCtrl` 适配新 NPU 格式
  - `GetOpExecutionOrder` / `ApplyInsertPlan` 等不变

### 3. 合并源文件 → op_ctrl_model.cpp

合并 `runtime_op_ctrl_model.cpp` 实现：

- `LoadFromOpCtrl` 反序列化更新：
  - 读首个 uint32_t 判断类型
  - OPCTRL_SEGTYPE_TENSOR：读 `sizeof(vha_user_cnn_submit_multi_cmd)` 字节到 `npu_multi_cmd`；总偏移量 = `sizeof(unisoc_npu_opctrl)`
  - SEG_TYPE_VDSP：同旧逻辑，解析 op_count + entries
- `SerializeToOpCtrl` 序列化更新：
  - NPU segment：写入 `unisoc_npu_opctrl` 结构体（含 segment_type + multi_cmd）
  - VDSP segment：同旧逻辑，写入 seg_type + op_count + entries
- TSU 插入相关代码不变

### 4. 更新测试 → op_ctrl_test.cpp

- `Test_BuildFromScratch`：构造 `unisoc_npu_opctrl` 传入；构造 VDSP raw binary 传入
- `Test_SerializeRoundTrip`：更新验证逻辑
- `Test_KernelSideSequentialParse`：NPU 部分按 `unisoc_npu_opctrl` 大小前进
- 保留 TSU 插入测试（`Test_InsertTsuOp`、`Test_InsertInvalidAnchor`、`Test_InsertOnNpuSegmentShouldFail`）
- 新增测试：验证 `AddVdspSegment(const void*, size_t)` 正确解析 raw binary

### 5. 删除旧文件

- `runtime_op_ctrl_model.h`
- `runtime_op_ctrl_model.cpp`
- `op_ctrl_builder.h`

## 文件变更

| 文件 | 操作 |
|------|------|
| `data_types.h` | 修改 |
| `op_ctrl_model.h` | 新建（合并两个 .h） |
| `op_ctrl_model.cpp` | 新建（合并 runtime_op_ctrl_model.cpp） |
| `op_ctrl_test.cpp` | 修改 |
| `runtime_op_ctrl_model.h` | 删除 |
| `runtime_op_ctrl_model.cpp` | 删除 |
| `op_ctrl_builder.h` | 删除 |

## 验证

```bash
g++ -std=c++17 -o op_ctrl_test op_ctrl_test.cpp op_ctrl_model.cpp && ./op_ctrl_test
```
