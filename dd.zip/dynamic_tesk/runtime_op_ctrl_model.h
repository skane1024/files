#pragma once
#include "data_types.h"

// ------------------ NPU核信息（NPU segment不支持插入，直接复用） ------------------
struct NpuCoreInfo {
    uint32_t cmd_buffer_id;
    uint32_t cmd_size;
    uint32_t cmd_offset;
    uint32_t weight_buffer_id;
    uint32_t weight_size;
    uint32_t weight_offset;
};

// ------------------ VDSP算子内部表示 ------------------
struct InternalVdspOp {
    uint32_t global_op_id;
    uint32_t op_type;
    std::vector<uint8_t> op_param;   // 序列化后写入独立参数区
    uint32_t depend_id;              // 依赖的前驱global_op_id，0表示无依赖
    uint32_t sync_type;
};

// ------------------ segment内部表示 ------------------
struct InternalSegment {
    uint32_t seg_type;
    std::vector<NpuCoreInfo>   npu_core_info;  // seg_type==NPU时有效
    std::vector<InternalVdspOp> vdsp_ops;      // seg_type==VDSP时有效
};

// ------------------ 对外只读查询视图 ------------------
struct OpNodeView {
    uint32_t global_op_id;
    uint32_t segment_index;
    uint32_t segment_type;
    uint32_t local_op_type;   // NPU segment填0（表示整核任务），VDSP填实际op_type
    uint32_t depend_id;
};

class IOpSequenceView {
public:
    virtual size_t GetOpCount() const = 0;
    virtual const OpNodeView& At(size_t idx) const = 0;
    virtual ~IOpSequenceView() = default;
};

class OpSequenceView : public IOpSequenceView {
public:
    explicit OpSequenceView(std::vector<OpNodeView> nodes) : nodes_(std::move(nodes)) {}
    size_t GetOpCount() const override { return nodes_.size(); }
    const OpNodeView& At(size_t idx) const override {
        if (idx >= nodes_.size()) throw std::out_of_range("OpSequenceView index out of range");
        return nodes_[idx];
    }
private:
    std::vector<OpNodeView> nodes_;
};

// ------------------ 用户插入请求 ------------------
enum class InsertPosition { BEFORE, AFTER };

struct TsuOpParam {
    uint32_t src_addr;
    uint32_t dst_addr;
    uint32_t data_size;
    uint32_t direction;     // 0 = LOAD(搬入SRAM) 1 = STORE(搬出)
    bool     run_parallel;  // true -> sync_type = ASYNC
};

struct TsuInsertRequest {
    uint32_t anchor_global_op_id;
    InsertPosition position;
    TsuOpParam param;
};

struct OpInsertPlan {
    std::vector<TsuInsertRequest> requests;
};

// ------------------ Runtime可变模型主体 ------------------
class RuntimeOpCtrlModel {
public:
    // 从已编译好的op_ctrl二进制构建内部可变模型（模型加载时调用一次）
    static std::unique_ptr<RuntimeOpCtrlModel> LoadFromOpCtrl(const uint8_t* data, size_t size);

    static std::unique_ptr<RuntimeOpCtrlModel> CreateFromSegments(
        std::vector<InternalSegment> segments, uint32_t next_global_op_id) {
        auto model = std::make_unique<RuntimeOpCtrlModel>();
        model->segments_ = std::move(segments);
        model->next_global_op_id_ = next_global_op_id;
        model->RebuildFullIndex();
        return model;
    }

    // 对外只读接口：获取当前算子执行顺序
    std::shared_ptr<const IOpSequenceView> GetOpExecutionOrder() const;

    // 对外接口：批量插入TSU同步算子
    bool ApplyInsertPlan(const OpInsertPlan& plan);

    // 序列化为最终发给kernel的op_ctrl二进制
    std::vector<uint8_t> SerializeToOpCtrl() const;

private:
    void RebuildDependChain(InternalSegment& seg);
    void RebuildOpIdIndexForSegment(uint32_t seg_idx);
    void RebuildFullIndex();
    uint32_t AllocNewGlobalOpId();

    std::vector<InternalSegment> segments_;
    // global_op_id -> (segment_index, local_index)，插入定位用O(1)哈希
    std::unordered_map<uint32_t, std::pair<uint32_t, uint32_t>> op_id_index_;
    uint32_t next_global_op_id_ = 0;
};
