"""FA_1104_GQA_1 用例: 把 QK/QKV 子算子 CMD 合并进 FA_mbs.bin 并修改 op_param。

主流程见 fa_common.py 模块 docstring (1 提取 CMD -> 2 对齐拼接 -> 3 替换 CMD
-> 4 reg_map -> 5 写 op_param -> 6 保存)。
"""
from mbs_parser import MBSParser
from mbs_modify import (modify_output_buffer_size, add_or_expand_temp_buffer,
                       add_buffer_to_reg_map, get_buffer_type_name)
from fa_common import (parse, concat_bytes_with_align, print_concat_table,
                       get_cmd_buffer_id, replace_cmd, write_cmd_info_to_op_param)


def read_cmd_commands(mbs_list):
    """解析各源 MBS 文件, 按顺序提取 cnn_command_stream。

    Returns:
        (cmds, origins): 每个 CMD 数据 + 来源文件名。
    """
    cmds, origins = [], []
    for path in mbs_list:
        with open(path, 'rb') as f:
            data = f.read()
        _, results = MBSParser(data).parse(show_field_info=False)
        for ri, result in enumerate(results):
            cmd = result['segments']['cnn_command_stream']
            if len(cmd) > 0:
                cmds.append(bytes(cmd))
                origins.append(f"{path.rsplit('/', 1)[-1]}#mbs{ri}")
            else:
                print(f"[WARN] 源文件 {path} 的 mbs{ri} 无 CMD 数据, 跳过")
    return cmds, origins


def tune_op_param(param):
    """FA_1104_GQA_1 特有的算子参数修改 (公共部分由 write_cmd_info_to_op_param 完成)。"""
    param.qkv_ddr_store_offset = 4 * 512 * 128 * 6
    addr = param.S_FLASH_ATTENTION_PARAM_ADDRESS
    addr.enable_npu_matmul_encode = 1
    addr.enable_npu_matmul_decode = 0
    addr.contex_seq = 0
    addr.k_fm_tiling_shape.fm_h = 2  # 这个让编译器改
    addr.v_fm_tiling_shape.fm_h = 2


def main():
    # 1. 获取模型的CMD (主FA + QK/QKV 各子算子)
    SRC_MBS_LIST = ["parse_case/FA_1104_GQA_1/FA_mbs.bin",
                    "parse_case/FA_1104_GQA_1/QK_Matmul.mbs.bin",
                    "parse_case/FA_1104_GQA_1/QK_0.mbs.bin",
                    "parse_case/FA_1104_GQA_1/QK_1.mbs.bin",
                    "parse_case/FA_1104_GQA_1/QKV_Matmul.mbs.bin",
                    "parse_case/FA_1104_GQA_1/QKV_0.mbs.bin",
                    "parse_case/FA_1104_GQA_1/QKV_1.mbs.bin"]
    cmds, origins = read_cmd_commands(SRC_MBS_LIST)

    # 2. CMD 按 256 字节对齐拼接
    merged_cmd, cmd_info_list = concat_bytes_with_align(cmds)
    print_concat_table(origins, cmd_info_list, merged_cmd)

    # 3. 读取目标模型, 把合并后的 CMD 整体替换进去
    #    (同时更新 cnn_command_stream_size 与 COMMAND_STREAM buffer size)
    TARGET_MBS = 'parse_case/FA_1104_GQA_1/FA_mbs.bin'
    OUT_MBS = 'parse_case/FA_1104_GQA_1/FA_mbs_merge_cmd.bin'
    with open(TARGET_MBS, 'rb') as f:
        target_mbs = bytearray(f.read())
    target_mbs = replace_cmd(target_mbs, merged_cmd)

    # 输出 buffer 扩大, 用于保存算子中间计算结果 (debug 时才需要)
    OUTPUT_BUFFER_SIZE = 16 * 512 * 128 * 10
    target_mbs = modify_output_buffer_size(target_mbs, OUTPUT_BUFFER_SIZE)

    # 添加 temp buffer (没有 TEMPORARY 则新增, 有则扩大)
    TEMP_BUFFER_SIZE = 8 * 1081344
    target_mbs, temp_buffer_id = add_or_expand_temp_buffer(target_mbs, TEMP_BUFFER_SIZE)

    # 4. 把 CMD 和 temp buffer 加入 reg_map
    cmd_buffer_id = get_cmd_buffer_id(target_mbs)
    target_mbs = add_buffer_to_reg_map(target_mbs, [cmd_buffer_id, temp_buffer_id])

    # 5. 写 op_param (传 buffer id, 内部换算为 reg_map index; 用例差异走 tune_op_param)
    target_mbs = write_cmd_info_to_op_param(
        target_mbs, cmd_info_list, cmd_buffer_id, temp_buffer_id, tune=tune_op_param)

    # 6. 保存最终结果, 并重新解析验证
    with open(OUT_MBS, "wb") as f:
        f.write(target_mbs)
    r2 = parse(target_mbs)
    print("num_buffers:", r2['buffer']['num_buffers'])
    for i in range(r2['buffer']['num_buffers']):
        print(f"  buffer_{i} type={get_buffer_type_name(r2['buffer']['buffer_type'][i])} "
              f"size={r2['buffer']['buffer_size'][i]:#X}")
    print("network_io.outputs[0].size:", r2['network_io']['outputs'][0]['size'])
    print("segments.outputs[0].buffer_size:", r2['segments']['outputs'][0]['buffer_size'])
    print("segments.cnn_num_mapped_regions:", r2['segments']['cnn_num_mapped_regions'])
    print("segments.cnn_mapped_region_buffer_id:", r2['segments']['cnn_mapped_region_buffer_id'])


if __name__ == "__main__":
    main()
