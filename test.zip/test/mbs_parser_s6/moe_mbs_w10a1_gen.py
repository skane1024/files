import os
import struct
import sys
import ctypes

from mbs_parser import MBSParser
from mbs_types import BufferType, get_buffer_type_name
from mbs_modify import modify_output_buffer_size, add_or_expand_temp_buffer, add_buffer_to_reg_map, get_buffer_type_name

from op_types import S_MOE_FFN_OP_PARAM


# ==================== 配置区 ====================
ALIGNMENT = 256  # CDM 合并时的对齐字节数

# 两个 NPU 算子的 MBS（提取其中的 CDM 与 coef 权重）
NPU_MBS_LIST = [
    "parse_case/moe/moe_1103_w10_gen/cnngraph.mbs.bin" ,
]
# 目标 VDSP 算子模型 MBS
TARGET_MBS = "parse_case/moe/moe_1103_w10_gen/mbs.bin"
OUT_MBS = "parse_case/moe/moe_1103_w10_gen/moe_merge_first.bin"

# 新增 coef buffer 的类型（COEFFICIENTS = 5）
COEF_BUFFER_TYPE = BufferType.COEFFICIENTS.value




def load_quant_params(txt_path):
    params = {}
    with open(txt_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or ":" not in line:
                continue
            key, value = line.split(":", 1)
            key = key.strip()
            value = value.strip()
            # 数字就转成 float / int，其他保留字符串
            try:
                params[key] = int(value) if value.lstrip("+-").isdigit() else float(value)
            except ValueError:
                params[key] = value
    return params

def parse(data):
    """重新解析 MBS 二进制数据，返回第一个结果 dict (offset 基于当前 data 内容)。"""
    _, results = MBSParser(data).parse(show_field_info=False)
    return results[0]


def concat_bytes_with_align(chunks, alignment=ALIGNMENT):
    """
    将多个 bytes 块按顺序拼接为一个 bytes，每个块补齐到 alignment 字节对齐。

    Args:
        chunks (list[bytes]): 输入字节块列表（按顺序）。
        alignment (int): 对齐字节数，默认 256。

    Returns:
        (bytes, list[dict]): 合并后的完整字节流，以及每个块的
        {index, actual_size, padded_size, offset} 信息列表。
    """
    merged = bytearray()
    info_list = []
    current_offset = 0

    for idx, chunk in enumerate(chunks):
        actual_size = len(chunk)
        padded_size = (actual_size + alignment - 1) // alignment * alignment
        info_list.append({
            'index': idx,
            'actual_size': actual_size,
            'padded_size': padded_size,
            'offset': current_offset,
        })
        merged += chunk
        padding = padded_size - actual_size
        if padding > 0:
            merged += b'\x00' * padding
        current_offset += padded_size

    return bytes(merged), info_list


def read_npu_chunks(mbs_list):
    """
    解析每个 NPU 算子 MBS，提取其中的 CDM（cnn_command_stream）与
    coef 权重（coefficients_data）。

    Args:
        mbs_list: NPU 算子 MBS 文件路径列表。

    Returns:
        (cdm_chunks, coef_chunks, origins):
            cdm_chunks (list[bytes])  : 每个 NPU 模型的 cmd 流
            coef_chunks (list[bytes]) : 每个 NPU 模型的 coef 权重
            origins     (list[str])   : 来源标识
    """
    cdm_chunks, coef_chunks, origins = [], [], []
    for path in mbs_list:
        try:
            with open(path, 'rb') as f:
                data = f.read()
            _, results = MBSParser(data).parse(show_field_info=False)
        except Exception as e:
            print(f"[ERROR] 解析 NPU 源文件失败: {path}\n        {e}",
                  file=sys.stderr)
            sys.exit(1)

        for ri, result in enumerate(results):
            seg = result['segments']
            coeff = result['coeff']
            cdm = bytes(seg['cnn_command_stream'])
            coef = bytes(coeff['coefficients_data'])
            origin = f"{os.path.basename(path)}#mbs{ri}"
            if len(cdm) == 0 and len(coef) == 0:
                print(f"[WARN] 源文件 {path} 的 mbs{ri} 无 CDM/coef 数据, 跳过")
                continue
            cdm_chunks.append(cdm)
            coef_chunks.append(coef)
            origins.append(origin)
            print(f"[extract] {origin:<45} CDM={len(cdm):>8}B  coef={len(coef):>10}B")
    return cdm_chunks, coef_chunks, origins


def apply_cmd_merge(data, chunk_build_list):
    """
    将 [目标自身 CDM] + [追加的 NPU CDM] 拼接后写回模型：
      1. 替换 segments 的 cnn_command_stream 数据区
      2. 更新 cnn_command_stream_size（words）
      3. 更新 COMMAND_STREAM 类型的 buffer_size

    Args:
        data: bytes 或 bytearray 形式的 MBS 数据
        chunk_build_list: 拼接用 chunk 列表（目标自身 CDM + 各 NPU CDM）

    Returns:
        (bytes, info_list): 修改后的 MBS 数据，以及每个 chunk 的
        {index, actual_size, padded_size, offset} 信息。
    """
    data = bytearray(data)
    r = parse(data)
    seg_fields = r['segment_fields']
    buffer = r['buffer']
    buffer_fields = r['buffer_fields']

    merged, info_list = concat_bytes_with_align(chunk_build_list, ALIGNMENT)

    cmd_field = seg_fields['cnn_command_stream']
    old_len = cmd_field['size']

    # 1. 替换 cnn_command_stream 数据区
    data[cmd_field['offset']:cmd_field['offset'] + old_len] = merged

    # 2. 更新 cnn_command_stream_size（words）
    size_field = seg_fields['cnn_command_stream_size']
    struct.pack_into('<I', data, size_field['offset'], len(merged) // 4)

    # 3. 更新 COMMAND_STREAM 类型的 buffer_size
    found = False
    for i in range(buffer['num_buffers']):
        if buffer['buffer_type'][i] == BufferType.COMMAND_STREAM.value:
            bs = buffer_fields[f'buffer_size_{i}']
            struct.pack_into('<I', data, bs['offset'], len(merged))
            found = True
    if not found:
        print("[WARN] 目标 MBS 中未找到 COMMAND_STREAM 类型 buffer, "
              "跳过 buffer_size 修改")

    return bytes(data), info_list


def add_coefficients_buffer(data, size):
    """
    在 buffer 表中新增一个 COEFFICIENTS buffer；若已存在则直接扩大其大小。

    Args:
        data: bytes 或 bytearray 形式的 MBS 数据
        size: coef buffer 的大小（字节）

    Returns:
        (bytes, buffer_id): 修改后的 MBS 数据，以及 coef buffer 的 buffer id
                           （= buffer 下标 + 1）。
    """
    data = bytearray(data)
    r = parse(data)
    buffer = r['buffer']
    buffer_fields = r['buffer_fields']
    num_buffers = buffer['num_buffers']

    # 已存在 COEFFICIENTS buffer 则直接扩大
    coeff_idx = [i for i in range(num_buffers)
                 if buffer['buffer_type'][i] == COEF_BUFFER_TYPE]
    if coeff_idx:
        idx = coeff_idx[0]
        bs = buffer_fields[f'buffer_size_{idx}']
        old = bs['value']
        struct.pack_into('<I', data, bs['offset'], size)
        print(f"[add_coefficients_buffer] 已有 COEFFICIENTS buffer[{idx}], "
              f"size: {old:#X} -> {size:#X} @ offset={bs['offset']}")
        return bytes(data), idx + 1

    # 不存在则新增，buffer id 自动分配为当前 buffer 个数 + 1
    new_buffer_id = num_buffers + 1
    payload = struct.pack('<II', COEF_BUFFER_TYPE, size)

    # buffer 表结构: [num_buffers][type_0][size_0]...[type_n-1][size_n-1]
    # 新 buffer 追加在现有 buffer 表末尾（此处紧邻 segment 区段开始）
    insert_off = buffer_fields['num_buffers']['offset'] + 4 + num_buffers * 2 * 4
    old_len = len(data)
    data[insert_off:insert_off] = payload
    # 同步递增 buffer 个数计数
    cnt_field = buffer_fields['num_buffers']
    struct.pack_into('<I', data, cnt_field['offset'], num_buffers + 1)
    new_len = len(data)
    print(f"[add_coefficients_buffer] 新增 COEFFICIENTS buffer_id={new_buffer_id}, "
          f"size={size:#X} @ offset={insert_off} "
          f"(buffer 个数 {num_buffers} -> {num_buffers + 1}, "
          f"文件长度 {old_len} -> {new_len})")
    return bytes(data), new_buffer_id


def set_coefficients_data(data, coef_bytes):
    """
    将合并后的 coef 权重写入模型的 (NPU) coefficients 区段：
      1. 更新 coefficients_size（words）
      2. 在 coefficients_data 处写入 coef 字节流

    Args:
        data: bytes 或 bytearray 形式的 MBS 数据
        coef_bytes: 合并后的 coef 权重字节流

    Returns:
        bytes: 修改后的 MBS 数据
    """
    data = bytearray(data)
    r = parse(data)
    coeff_fields = r['coeff_fields']

    size_field = coeff_fields['coefficients_size']
    data_field = coeff_fields['coefficients_data']
    old_words = size_field['value']
    old_data_len = data_field['size']
    new_words = len(coef_bytes) // 4

    # 1. 更新 coefficients_size（words）
    struct.pack_into('<I', data, size_field['offset'], new_words)

    # 2. 在 coefficients_data 位置写入 coef 字节流
    #    （原数据可能为 0 长度，此时相当于插入）
    data[data_field['offset']:data_field['offset'] + old_data_len] = coef_bytes

    print(f"[set_coefficients_data] coefficients_size: {old_words} -> {new_words} "
          f"(words, {new_words * 4} bytes) @ offset={data_field['offset']}")
    return bytes(data)


def get_op_param_data_offset(result):
    """
    计算当前 result 中 op_param_data 的绝对偏移。

    MBS 布局（含 VDSP 版本）:
      ... segments ...
      vdsp_coeff:  [coefficients_size(4)][coefficients_data]
      vdsp_op_param: [vdsp_op_count(4)][vdsp_op_list(n*4)][op_param_size(4)][op_param_data]
    """
    vc = result['vdsp_coeff_fields']['coefficients_data']
    op_param_start = vc['offset'] + vc['size']
    op = result['vdsp_op_params']
    op_data_offset = op_param_start + 4 + op['vdsp_op_count'] * 4 + 4
    return op_data_offset


def modify_op_param(data, npu1_cmd_offset, npu1_cmd_size,
                    npu1_coef_offset, npu1_coef_size, expert_count,temp_buffer_id, coef_buffer_id):
    """
    扩展 MOE FFN 的 VDSP op_param，携带第一个 NPU 算子的 CDM/coef 引用信息：
      2. 保留全部原有字段，追加填写
         npu_cmd_offset / npu_cmd_size / npu_coef_offset / npu_coef_size / expert_count
      3. 新结构体 168 字节，超原 152 字节 -> 在 extension 区段前插入 16 字节补齐
      4. 更新 op_param_size（38 -> 42 words）
      5. 更新 VDSP_OP_PARAMS 类型 buffer 的 buffer_size（152 -> 168）

    Args:
        data: bytes 或 bytearray 形式的 MBS 数据
        npu1_cmd_offset / npu1_cmd_size : 第一个 NPU 算子的 CDM 在合并命令流中的偏移/大小
        npu1_coef_offset / npu1_coef_size: 第一个 NPU 算子的 coef 权重在系数区段中的偏移/大小
        expert_count                    : 专家个数（两个 NPU 算子）

    Returns:
        bytes: 修改后的 MBS 数据
    """
    data = bytearray(data)
    r = parse(data)

    op = r['vdsp_op_params']
    op_data_offset = get_op_param_data_offset(r)
    size = op['op_param_size'] * 4          # 原 op_param 字节数（152）
    raw = bytes(data[op_data_offset:op_data_offset + size])

    # 1. 解码原 op_param_data 到扩展结构体
    param = S_MOE_FFN_OP_PARAM()
    ctypes.memmove(ctypes.addressof(param), raw, ctypes.sizeof(param))

    
    # param.temp_ddr_id = temp_buffer_id
    # param.npu_coef_ddr_id = coef_buffer_id
    # param.fm_in1_ddr_load_id = 1
    # param.fm_in2_ddr_load_id = 2
    # param.fm_out_ddr_store_id = 3
    param.temp_ddr_id = 6
    param.npu_coef_ddr_id = 5
    
    # param.fm_ddr_store_offset = 0
    # param.temp_ddr_offset = 0
    
    quant_prams = load_quant_params("/home/yongkang.shu/NPU_IN_VDSP/moeffn-main/model/expert_w10a1/moe_golden_decoder/quant_params.txt")
    param.moe_ffn_param_address.in1_scale = quant_prams["in_scale"]
    param.moe_ffn_param_address.in1_zeropoint = quant_prams["in_zeropoint"]
    
    param.moe_ffn_param_address.out_scale = quant_prams["out_scale"]
    param.moe_ffn_param_address.out_zeropoint = quant_prams["out_zeropoint"]
    
    param.moe_ffn_param_address.npu_max_tokens = 1
     
    # 2. 追加填写新字段
    for j in range(0,116):
        param.npu_cmd_offset[j] = npu1_cmd_offset
        param.npu_cmd_size[j] = npu1_cmd_size
        param.npu_coef_offset[j] = npu1_coef_offset
        param.npu_coef_size[j] = npu1_coef_size
        param.out_scale[j] = param.out_scale[0]
        param.out_zeropoint[j] = param.out_zeropoint[0] 

    param.expert_count = 96


    # # 3. 新结构体字节序列
    new_bytes = bytes(param)
    new_size = len(new_bytes)
    data[op_data_offset:op_data_offset + new_size] = new_bytes
    return bytes(data)


def main():


    #获取NPU 模型的CDM和coef
    cdm_chunks, coef_chunks, origins = read_npu_chunks(NPU_MBS_LIST)
    coef_merged = b''.join(coef_chunks) # 合并 coef 
    #TODO权重可能需要对齐？？
    print(f"合并后 coef 总长: {len(coef_merged)} 字节 ({len(coef_merged) // 4} words)")

    # 2. 读取目标 VDSP 模型，合并CMD 有对齐的需求
    with open(TARGET_MBS, 'rb') as f:
        data = f.read()
    tr = parse(data)
    target_cdm = bytes(tr['segments']['cnn_command_stream'])
    chunk_build_list = [target_cdm] + cdm_chunks
    data, info_list = apply_cmd_merge(data, chunk_build_list)
    print(f"{'来源':<50} {'actual_size':>12} {'padded_size':>12} {'offset':>12}")
    print('-' * 90)
    labels = ['target_moe.mbs.bin#mbs0'] + origins
    for info, label in zip(info_list, labels):
        print(f"{label:<50} {info['actual_size']:>12} {info['padded_size']:>12} {info['offset']:>12}")
    print('-' * 90)
    merged_total = sum(i['padded_size'] for i in info_list)
    print(f"{'total':<50} {'':>12} {'':>12} {merged_total:>12}")
    print(f"合并后 CDM 总长: {merged_total} 字节 ({merged_total // 4} words)")
    
    OUTPUT_BUFFER_SIZE = 3072* 72 *32
    # 修改输出 buffer 大小为 4MB（原 512KB）  用于保存算子中间的一些计算结果
    data = modify_output_buffer_size(data, OUTPUT_BUFFER_SIZE)
    
    # 3. 新增coef buffer
    data, coef_buffer_id = add_coefficients_buffer(data, len(coef_merged))
    
    # 添加temp buffer（如果没有 TEMPORARY，会新增一个temp buffer, 如果有就增加size）
    TEMP_BUFFER_SIZE = 3072 * 72 * 10
    data, temp_buffer_id = add_or_expand_temp_buffer(data, TEMP_BUFFER_SIZE)

    # 4. 将 coef buffer 加入 segment 的 reg_map
    data = add_buffer_to_reg_map(data, [4, coef_buffer_id, temp_buffer_id])

    # 5. 将 coef 权重数据写入模型 coefficients 区段
    data = set_coefficients_data(data, coef_merged)

    # 6. 扩展 VDSP op_param，填写第一个 NPU 算子的 CDM/coef 引用信息
    #    （CDM 合并后各 chunk 256 对齐；coef 直接拼接无对齐，首个 NPU 从 0 开始）
    npu1_cmd_info = info_list[1]           # 第一个 NPU 算子的 CDM
    npu1_coef_size = len(coef_chunks[0])   # 第一个 NPU 算子的 coef 大小
    expert_count = 96                       # 两个 NPU 算子（专家）
    data = modify_op_param(
        data,
        npu1_cmd_info['offset'], npu1_cmd_info['actual_size'],
        0, npu1_coef_size, expert_count, temp_buffer_id, coef_buffer_id
    )
    
    # 7. 保存最终结果
    with open(OUT_MBS, "wb") as f:
        f.write(data)

    # ===== 修改后重新解析验证 =====
    r2 = parse(data)
    print("num_buffers:", r2['buffer']['num_buffers'])
    for i in range(r2['buffer']['num_buffers']):
        print(f"  buffer_{i} type={get_buffer_type_name(r2['buffer']['buffer_type'][i])} "
              f"size={r2['buffer']['buffer_size'][i]:#X} "
              f"({r2['buffer']['buffer_size'][i]} bytes)")
    print("cnn_command_stream_size:", r2['segments']['cnn_command_stream_size'], "words")
    print("coeff coefficients_size:", r2['coeff']['coefficients_size'], "words")
    print("vdsp_coeff coefficients_size:", r2['vdsp_coeff']['coefficients_size'], "words")
    print("segments.cnn_num_mapped_regions:", r2['segments']['cnn_num_mapped_regions'])
    print("segments.cnn_mapped_region_buffer_id:", r2['segments']['cnn_mapped_region_buffer_id'])

    # 校验 CDM 内容 = 目标自身 CDM + NPU1 CDM + NPU2 CDM
    merged_cdm = bytes(r2['segments']['cnn_command_stream'])
    # expect = target_cdm + cdm_chunks[0] + cdm_chunks[1]
    expect = target_cdm + cdm_chunks[0]
    tail = merged_cdm[len(expect):]  # 对齐填充部分应全为 0
    print("\nCDM 校验:")
    print("  合并后 CDM 长度:", len(merged_cdm))
    print("  前段(目标+NPU原始)是否完全一致:",merged_cdm[:len(expect)] == expect)
    print("  对齐填充部分是否全 0:", tail == b'\x00' * len(tail),
          f"({len(tail)} bytes padding)")

    # 校验 coef 权重内容 = NPU1 coef + NPU2 coef
    merged_coef = bytes(r2['coeff']['coefficients_data'])
    print("\ncoef 校验:")
    print("  coefficients 数据长度:", len(merged_coef))
    print("  与 NPU 提取的 coef 拼接一致:",merged_coef == b''.join(coef_chunks))

    # 校验 op_param 仍为 MOE_FFN，且扩展字段已正确填写
    r3 = parse(data)
    vdsp = r3['vdsp_op_params']
    print("\nVDSP op_param:")
    print("  vdsp_op_count:", vdsp['vdsp_op_count'])
    print("  vdsp_op_list:", vdsp['vdsp_op_list'])
    print("  op_param_size:", vdsp['op_param_size'], "words "f"({vdsp['op_param_size'] * 4} bytes)")

    # 从最终文件解码扩展结构体，验证新字段
    op_data_offset = get_op_param_data_offset(r3)
    raw3 = bytes(data[op_data_offset:op_data_offset + vdsp['op_param_size'] * 4])
    p3 = S_MOE_FFN_OP_PARAM()
    ctypes.memmove(ctypes.addressof(p3), raw3, ctypes.sizeof(p3))
    print("\n=== 最终 op_param 扩展字段验证 ===")
    print("npu_cmd_offset:", p3.npu_cmd_offset, " npu_cmd_size:", p3.npu_cmd_size)
    print("npu_coef_offset:", p3.npu_coef_offset, " npu_coef_size:", p3.npu_coef_size)
    print("expert_count:", p3.expert_count)
    print("  预期: cmd_offset=256 cmd_size=3584 "
          f"coef_offset=0 coef_size={npu1_coef_size} expert_count=2")


if __name__ == "__main__":
    main()