import os
import time
import logging
import argparse
import struct
from enum import Enum
from enum import IntEnum


# MAGIC值
# 文件头
MAGIC_EXPECTED = 0x42beef42
#exten_block
EXTENSION_MAGIC_EXPECTED = 0xAB12D34

VHA_MBS_VERSION_S_STRIDE_AND_ORDER_ADDED                      = 0x0000000c     #12
VHA_MBS_VERSION_STRIDES_ARRAY_ADDED                           = 0x0000000d     #13
VHA_MBS_VERSION_BRN_LIST_ADDED                                = 0x0000000e     #14
VHA_MBS_VERSION_CUSTOM_LAYERS_ADDED                           = 0x0000000f     #15
VHA_MBS_VERSION_SEGMENT_FLAG_AND_BUFFER_ALIGNMENT_ADDED       = 0x00000010     #16
VHA_MBS_VERSION_CMD_STREAM_PARTITIONS_ADDED                   = 0x00000011     #17
VHA_MBS_VERSION_SOFTWARE_PARAMS_BUFFER_ADDED                  = 0x00000012     #18
VHA_MBS_VERSION_VPU_CMD_STREAM_PARTITIONS_ADDED               = 0x00000013     #19
VHA_MBS_VERSION_VDSP_CMD_STREAM_PARTITIONS_ADDED              = 0x00000014     #20
VHA_MBS_VERSION_VPU_AND_VDSP_CMD_STREAM_PARTITIONS_ADDED      = 0x00000015     #21
VHA_MBS_VERSION_DYNAMIC_SHARE_WEIGHT                          = 0x00000016     #22



#buffer的类型
class BufferType(Enum):
    UNDEFINED = 0
    NETWORK_INPUT = 1
    NETWORK_OUTPUT = 2
    INTERMEDIATE = 3
    COMMAND_STREAM = 4
    COEFFICIENTS = 5
    TEMPORARY = 6
    SOFTWARE = 7
    LOCAL = 8
    SHARED = 9
    INTERNAL_STATE = 10
    SOFTWARE_PARAMS = 11
    VPU_OP_PARAMS = 12
    VDSP_COEFFICIENTS = 13
    VDSP_OP_PARAMS = 14
    COEFFICIENTS_SHARED = 15


def get_buffer_type_name(buffer_type):
    for member in BufferType:
        if member.value == buffer_type:
            return member.name
    return 'UNKNOWN'


class SegmentType(Enum):
    CNN = 0
    Scalar = 1
    HOST = 2
    CNN_MULTI = 3


class SegmentFlag(Enum):
    NONE = 0
    STANDARD = 1
    GET_STATE = 2
    SET_STATE = 4
    SET_STATE1 = 5


class MemoryFormat:
    def __init__(self, value):
        self.value = value
        self.ZERO_POINT = (value >> 24) & 0xFF
        self.IS_Q8A = (value >> 23) & 0x1
        self.IS_FLOAT = (value >> 22) & 0x1
        self.IS_SIGNED = (value >> 16) & 0x1
        self.EXPONENT = (value >> 8) & 0xF
        self.PLANE_PACK = (value >> 4) & 0xF
        self.BITDEPTH = value & 0xF


class DynamicFormat:
    def __init__(self, value):
        self.value = value
        # 低4位: mbs的个数 (bits 0-3)
        self.MBS_COUNT = value & 0xF
        # bit 4: 是否包含VDSP
        self.HAS_VDSP = (value >> 4) & 0x1
        # bit 5: 是否包含AIV
        self.HAS_AIV = (value >> 5) & 0x1

class BufferFlags:
    def __init__(self, value):
        self.value = value
        self.BURST = (value >> 8) & 0xF
        self.ALIGNMENT = (value >> 4) & 0xF
        self.ORDER = value & 0xF



class OpType(IntEnum):
    OP_TYPE_RMSNORM              = 0
    OP_TYPE_SOFTMAX              = 1
    OP_TYPE_MATMUL               = 2
    OP_TYPE_ELEMENTWISE_ALGEBRA  = 3
    OP_TYPE_ROPE                 = 4
    OP_TYPE_CPY                  = 5
    OP_TYPE_LAYER_NORM           = 6
    OP_TYPE_STD_SOFTMAX          = 7
    OP_TYPE_STD_GROUP_NORM       = 8
    OP_TYPE_STD_INSTANCE_NORM    = 9
    OP_TYPE_FLASH_ATTENTION      = 10
    OP_TYPE_GATHER_ELEMENTS      = 11
    OP_TYPE_MAX                  = 12
# print(OpType.OP_TYPE_MATMUL)  # 输出: <OpType.OP_TYPE_MATMUL: 2>
# print(OpType(3).name)  # 输出: OP_TYPE_ELEMENTWISE_ALGEBRA
# for op in OpType:
#     print(op.name, ":", op.value)