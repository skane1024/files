"""FA 用例公共逻辑: fa_mbs.py 与 fa_mbs_n03.py 共用的处理流程。

统一主流程 (两个脚本的 main 都按此顺序调用):
    1. 提取各子算子 CMD          —— 用例各自实现 (多 MBS 文件 / fusion_cmd.bin)
    2. concat_bytes_with_align   —— CMD 按 ALIGNMENT 对齐拼接
    3. replace_cmd               —— 合并后的 CMD 整体替换进目标 MBS
    4. add_buffer_to_reg_map     —— CMD/temp buffer 加入 segment reg_map (mbs_modify)
    5. write_cmd_info_to_op_param—— 各 CMD 的 offset/size 等写入 vdsp op_param
    6. 保存输出
"""
import os
import sys
import struct
import ctypes

from mbs_parser import MBSParser
from mbs_types import BufferType
from mbs_modify import add_buffer_to_reg_map  # noqa: F401  (供用例直接 re-export)

FA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'FA')
if FA_DIR not in sys.path:
    sys.path.insert(0, FA_DIR)
from op_types import S_FLASH_ATTENTION_OP_PARAM


ALIGNMENT = 256  # CMD 对齐字节数

# FA 场景下 op_param 8 个 cmd slot 的排列:
#   chunk[0] 是主 FA CMD (不映射到 op_param slot)
#   chunk[1..3] (QK 组)   -> slot 0,1,2
#   chunk[4..6] (QKV 组)  -> slot 4,5,6
#   slot 3/7 保留 0
OP_PARAM_SLOT_FROM_CHUNK = {1: 0, 2: 1, 3: 2, 4: 4, 5: 5, 6: 6}


def parse(data):
    """解析 MBS 二进制数据, 返回第一个结果 dict。"""
    _, results = MBSParser(data).parse(show_field_info=False)
    return results[0]


def concat_bytes_with_align(cmds, alignment=ALIGNMENT):
    """把多个 bytes 块按顺序拼接, 每块补齐到 alignment 对齐。

    Returns:
        (bytes, list[dict]): 合并后的完整字节流, 以及每个块的
        {index, actual_size, padded_size, offset} 信息列表。
    """
    merged_cmd = bytearray()
    cmd_info_list = []
    current_offset = 0
    for idx, cmd in enumerate(cmds):
        actual_size = len(cmd)
        padded_size = (actual_size + alignment - 1) // alignment * alignment
        cmd_info_list.append({
            'index': idx,
            'actual_size': actual_size,
            'padded_size': padded_size,
            'offset': current_offset,
        })
        merged_cmd += cmd + b'\x00' * (padded_size - actual_size)
        current_offset += padded_size
    return bytes(merged_cmd), cmd_info_list


def print_concat_table(origins, cmd_info_list, merged_cmd):
    """打印 CMD 拼接表 (源 / actual_size / padded_size / offset)。"""
    width = max(len(o) for o in origins) + 4
    print(f"\n{'源':<{width}} {'actual_size':>12} {'padded_size':>12} {'offset':>12}")
    print('-' * (width + 42))
    for origin, info in zip(origins, cmd_info_list):
        print(f"{origin:<{width}} {info['actual_size']:>12} "
              f"{info['padded_size']:>12} {info['offset']:>12}")
    print('-' * (width + 42))
    print(f"{'total':<{width}} {'':>12} {'':>12} {len(merged_cmd):>12}")
    print(f"合并后 CMD 总长: {len(merged_cmd)} 字节 ({len(merged_cmd) // 4} words)")


def get_cmd_buffer_id(data):
    """获取 COMMAND_STREAM buffer 的 buffer id (buffer 表下标 + 1, id 从 1 起)。"""
    buf = parse(data)['buffer']
    for i in range(buf['num_buffers']):
        if buf['buffer_type'][i] == BufferType.COMMAND_STREAM.value:
            return i + 1
    raise ValueError("未找到 COMMAND_STREAM 类型的 buffer")


def collect_target_edits(target_mbs, merged_bytes):
    """解析目标 MBS, 收集把 CMD 数据区整体替换为 merged_bytes 所需的编辑。

    Returns:
        list[(offset, old_len, new_bytes)] 按 offset 降序排列 (先改大 offset,
        小 offset 的绝对定位不受数据位移影响)。
    """
    _, results = MBSParser(target_mbs).parse(show_field_info=False)

    edits = []
    merged_words = len(merged_bytes) // 4
    for result in results:
        seg_fields = result['segment_fields']
        buf, buf_fields = result['buffer'], result['buffer_fields']

        # CMD 数据区整体替换
        edits.append((seg_fields['cnn_command_stream']['offset'],
                      seg_fields['cnn_command_stream']['size'], merged_bytes))
        # cnn_command_stream_size 字段 -> 新总字数
        edits.append((seg_fields['cnn_command_stream_size']['offset'],
                      4, struct.pack('<I', merged_words)))
        # COMMAND_STREAM buffer 的 buffer_size -> 新字节数
        for i in range(buf['num_buffers']):
            if buf['buffer_type'][i] == BufferType.COMMAND_STREAM.value:
                bs = buf_fields[f'buffer_size_{i}']
                edits.append((bs['offset'], 4, struct.pack('<I', len(merged_bytes))))

    edits.sort(key=lambda e: e[0], reverse=True)
    return edits, len(results)


def replace_cmd(mbs, merged_cmd):
    """把合并后的 CMD 替换进 MBS (同时更新 cmd size 与 COMMAND_STREAM buffer size)。"""
    mbs = bytearray(mbs)
    edits, _ = collect_target_edits(mbs, merged_cmd)
    for offset, old_len, new_bytes in edits:
        mbs[offset:offset + old_len] = new_bytes
    return mbs


def get_op_param_data_offset(result):
    """计算 result 中 vdsp op_param_data 的绝对偏移。

    MBS 布局 (含 VDSP 版本):
      ... segments ...
      vdsp_coeff:    [coefficients_size(4)][coefficients_data]
      vdsp_op_param: [vdsp_op_count(4)][vdsp_op_list(n*4)][op_param_size(4)][op_param_data]
    """
    vc = result['vdsp_coeff_fields']['coefficients_data']
    op_param_start = vc['offset'] + vc['size']
    op = result['vdsp_op_params']
    return op_param_start + 4 + op['vdsp_op_count'] * 4 + 4


def _reg_index(reg_ids, buffer_id):
    """buffer id 在 reg_map 中的 1 基 index (op_param 里写的是 index 不是 id)。"""
    if isinstance(reg_ids, int):
        reg_ids = (reg_ids,)
    return list(reg_ids).index(buffer_id) + 1


def write_cmd_info_to_op_param(mbs_data, cmd_info_list, cmd_buffer_id,
                               temp_buffer_id=None, tune=None):
    """把合并 CMD 的信息写入 vdsp op_param (结构体直接映射 mbs 内存, 原地修改)。

    公共部分:
      1. cmd_offset/cmd_size: 各子算子 chunk 在合并 CMD 中的 offset/actual_size
      2. cmd_count: 有效 slot 数
      3. npu_cmd_id: cmd_buffer_id 在 reg_map 中的 index (需先 add_buffer_to_reg_map)
      4. qk/qkv_ddr_store_id: temp_buffer_id 在 reg_map 中的 index (temp_buffer_id 不为 None 时)
    tune(param): 用例特有的其他算子参数修改。
    返回修改后的 mbs bytes。
    """
    target_mbs = bytearray(mbs_data)
    r = parse(target_mbs)
    op_data_offset = get_op_param_data_offset(r)
    param = S_FLASH_ATTENTION_OP_PARAM.from_buffer(target_mbs, op_data_offset)

    reg_ids = r['segments']['cnn_mapped_region_buffer_id']

    slots = []
    for idx, info in enumerate(cmd_info_list):
        slot = OP_PARAM_SLOT_FROM_CHUNK.get(idx)
        if slot is None:
            continue  # chunk[0] = 主 FA CMD, 不映射 slot
        slots.append((slot, info))
    for slot, info in slots:
        param.cmd_offset[slot] = info['offset']
        param.cmd_size[slot] = info['actual_size']
    param.cmd_count = len(slots)

    param.npu_cmd_id = _reg_index(reg_ids, cmd_buffer_id)
    if temp_buffer_id is not None:
        store_reg_id = _reg_index(reg_ids, temp_buffer_id)
        param.qk_ddr_store_id = store_reg_id
        param.qkv_ddr_store_id = store_reg_id

    if tune is not None:
        tune(param)

    print("\n=== 合并 CMD offset/size 写入 vdsp op_param ===")
    print(f"npu_cmd_id = {param.npu_cmd_id}  cmd_count = {param.cmd_count}")
    for slot, _info in slots:
        print(f"  cmd_offset[{slot}] = {param.cmd_offset[slot]}  "
              f"cmd_size[{slot}] = {param.cmd_size[slot]}")
    return bytes(target_mbs)
