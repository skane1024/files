"""
算子参数解析（二进制读取 + 文本导出）
====================================
解析函数放在这个文件里。

每个算子的结构体定义和打印函数在 op_types.py，
公共结构体在 VDSP_types.py。

集中式注册表 OP_REGISTRY：op type -> (结构体类, 打印函数)，
新增算子只需在 op_types.py 定义好结构体与 *_print，并在
OP_REGISTRY 中登记一项即可，解析逻辑无需改动。
"""
import os
import json
import ctypes
import shutil
from enum import Enum
from pathlib import Path
from op_types import *


# 集中式注册表：OpType -> (结构体类, 打印函数)
# 新增算子时在此登记，并保证 op_types.py 中已定义对应的结构体与 *_print 函数
OP_REGISTRY = {
    OpType.OP_TYPE_RMSNORM:            (S_RMS_NORM_OP_PARAM,         rmsnorm_print),
    OpType.OP_TYPE_SOFTMAX:            (VDSP_SOFTMAX_PARAM_T,        softmax_print),
    OpType.OP_TYPE_STD_SOFTMAX:        (VDSP_STD_SOFTMAX_PARAM_T,    softmax_print),
    OpType.OP_TYPE_MATMUL:             (S_MATMUL_OP_PARAM,           matmul_print),
    OpType.OP_TYPE_ELEMENTWISE_ALGEBRA:(VDSP_ADD_PARAM_T,            add_print),
    OpType.OP_TYPE_ROPE:               (S_ROPE_OP_PARAM,             rope_print),
    OpType.OP_TYPE_COPY:               (S_COPY_OP_PARAM,             copy_print),
    OpType.OP_TYPE_LAYER_NORM:         (S_LAYER_NORM_PARAM_ADDRESS,  layer_norm_print),
    OpType.OP_TYPE_FLASH_ATTENTION:    (S_FLASH_ATTENTION_OP_PARAM,  flash_attention_print),
    OpType.OP_TYPE_MOE_FFN:            (S_MOE_FFN_OP_PARAM,          moe_ffn_print),
}


def _op_size(op):
    """返回单个算子的二进制大小；未知算子返回 0 并告警。"""
    entry = OP_REGISTRY.get(OpType(op))
    if entry is None:
        print("unknow op type !!!!", op)
        return 0
    return ctypes.sizeof(entry[0]())


def _parse_one_op(file, op):
    """从 file 中按 op 类型读取一个结构体，返回其 *_print 文本。"""
    entry = OP_REGISTRY.get(OpType(op))
    if entry is None:
        print("unknow op type !!!!")
        return ""
    struct_cls, print_fn = entry
    data = file.read(ctypes.sizeof(struct_cls()))
    data_struct = struct_cls.from_buffer_copy(data)
    return print_fn(data_struct)


def parse_op_parms(optype_list_path, op_param_bin_path, save_path):
    # 从文件中读取算子类型列表
    with open(optype_list_path, 'r') as f:
        line = f.read().strip()
        optype_list = list(map(int, line.split()))

    # 计算所有算子的总大小，用于校验 bin 文件
    total_size = sum(_op_size(op) for op in optype_list)

    dir_path = Path(os.path.join(save_path, "op_param"))
    if dir_path.exists():
        shutil.rmtree(dir_path)
    dir_path.mkdir(exist_ok=True)

    with open(op_param_bin_path, "rb") as file:
        file_size = os.path.getsize(op_param_bin_path)
        if file_size != total_size:
            print("op_param size doesn't match!!!!", file_size, "   ", total_size)
            exit(-1)
        for i, op in enumerate(optype_list):
            message = _parse_one_op(file, op)
            with open(os.path.join(os.path.join(save_path, "op_param"), str(i) + "_" + OpType(op).name + ".txt"), "w") as f:
                f.write(message)


# ============================================================
# 兼容层：保持原有 `from vdsp_op_param_parser import *` 可用
# ============================================================
from VDSP_types import *  # noqa: E402,F401,F403
