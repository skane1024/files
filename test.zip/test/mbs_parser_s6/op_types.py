"""
各算子的结构体定义与打印函数
=============================
每个算子的结构体（ctypes.Structure）和它的 *_print 函数放在一起。

公共结构体（FmShape、ReQuantParam、OpType 等）定义在 VDSP_types.py。
解析/读取逻辑在 op_param_parser.py。
"""
import ctypes
from VDSP_types import *


def moe_ffn_print(data_struct):
    moe_ffn_param_address = data_struct.moe_ffn_param_address
    in1_fm_shape = moe_ffn_param_address.in1_fm_shape
    in2_fm_shape = moe_ffn_param_address.in2_fm_shape
    out_fm_shape = moe_ffn_param_address.out_fm_shape
    out_fm_shape_valid = moe_ffn_param_address.out_fm_shape_valid
    in1_fm_format_type = moe_ffn_param_address.in1_fm_format_type
    in2_fm_format_type = moe_ffn_param_address.in2_fm_format_type
    out_fm_format_type = moe_ffn_param_address.out_fm_format_type

    in1_dtype = moe_ffn_param_address.in1_dtype
    in2_dtype = moe_ffn_param_address.in2_dtype
    out_dtype = moe_ffn_param_address.out_dtype

    in1_scale = moe_ffn_param_address.in1_scale
    in1_zeropoint = moe_ffn_param_address.in1_zeropoint
    in2_scale = moe_ffn_param_address.in2_scale
    in2_zeropoint = moe_ffn_param_address.in2_zeropoint
    out_scale = moe_ffn_param_address.out_scale
    out_zeropoint = moe_ffn_param_address.out_zeropoint

    message = ""
    message = message + "opParams.fm_in1_ddr_load_id : %d" % data_struct.fm_in1_ddr_load_id + "\n"
    message = message + "opParams.fm_in2_ddr_load_id : %d" % data_struct.fm_in2_ddr_load_id + "\n"
    message = message + "opParams.fm_out_ddr_store_id : %d" % data_struct.fm_out_ddr_store_id + "\n"
    message = message + "opParams.temp_ddr_id : %d" % data_struct.temp_ddr_id + "\n"
    
    message = message + "opParams.npu_cmd_ddr_id : %d" % data_struct.npu_cmd_ddr_id + "\n"
    message = message + "opParams.npu_coef_ddr_id : %d" % data_struct.npu_coef_ddr_id + "\n"
    message = message + "opParams.fm_in1_ddr_load_offset : %d" % data_struct.fm_in1_ddr_load_offset + "\n"
    message = message + "opParams.fm_in2_ddr_load_offset : %d" % data_struct.fm_in2_ddr_load_offset + "\n"
    message = message + "opParams.fm_ddr_store_offset : %d" % data_struct.fm_ddr_store_offset + "\n"
    message = message + "opParams.temp_ddr_offset : %d" % data_struct.temp_ddr_offset + "\n"
       
    for e in range(10):
        message = message + "opParams.npu_cmd_offset : %d" % data_struct.npu_cmd_offset[e] + "\n"
        message = message + "opParams.npu_cmd_size : %d" % data_struct.npu_cmd_size[e] + "\n"
        message = message + "opParams.npu_coef_offset : %d" % data_struct.npu_coef_offset[e] + "\n"
        message = message + "opParams.npu_coef_size : %d" % data_struct.npu_coef_size[e] + "\n"
        message = message + "opParams.out_scale : %f" % data_struct.out_scale[e] + "\n"
        message = message + "opParams.out_zeropoint : %d" % data_struct.out_zeropoint[e] + "\n"
        
    message = message + "opParams.expert_count : %d" % data_struct.expert_count + "\n"

    message = message + "addrlessParams.in1_fm_shape : %d , %d , %d , %d" % (in1_fm_shape.fm_n, in1_fm_shape.fm_h, in1_fm_shape.fm_w, in1_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.in2_fm_shape : %d , %d , %d , %d" % (in2_fm_shape.fm_n, in2_fm_shape.fm_h, in2_fm_shape.fm_w, in2_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.out_fm_shape : %d , %d , %d , %d" % (out_fm_shape.fm_n, out_fm_shape.fm_h, out_fm_shape.fm_w, out_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.out_fm_shape_valid : %d , %d , %d , %d" % (out_fm_shape_valid.fm_n, out_fm_shape_valid.fm_h, out_fm_shape_valid.fm_w, out_fm_shape_valid.fm_c) + "\n"
    message = message + "addrlessParams.in1_fm_format_type : %d" % in1_fm_format_type + "\n"
    message = message + "addrlessParams.in2_fm_format_type : %d" % in2_fm_format_type + "\n"
    message = message + "addrlessParams.out_fm_format_type : %d" % out_fm_format_type + "\n"
    message = message + "addrlessParams.in1_dtype : %d" % in1_dtype + "\n"
    message = message + "addrlessParams.in2_dtype : %d" % in2_dtype + "\n"
    message = message + "addrlessParams.out_dtype : %d" % out_dtype + "\n"
    message = message + "addrlessParams.in1_scale : %f" % in1_scale + "\n"
    message = message + "addrlessParams.in1_zeropoint : %d" % in1_zeropoint + "\n"
    message = message + "addrlessParams.in2_scale : %f" % in2_scale + "\n"
    message = message + "addrlessParams.in2_zeropoint : %d" % in2_zeropoint + "\n"
    message = message + "addrlessParams.out_scale : %f" % out_scale + "\n"
    message = message + "addrlessParams.out_zeropoint : %d" % out_zeropoint + "\n"

    return message


def copy_print(data_struct):
    cpy_param_address = data_struct.cpy_param_address
    in_fm_shape = cpy_param_address.in_fm_shape
    out_fm_shape = cpy_param_address.out_fm_shape
    out_fm_shape_valid = cpy_param_address.out_fm_shape_valid
    order = cpy_param_address.order
    message = ""
    message = message + "opParams.fm_ddr_load_id : %d" % data_struct.fm_ddr_load_id + "\n"
    message = message + "opParams.fm_ddr_store_id : %d" % data_struct.fm_ddr_store_id + "\n"
    message = message + "opParams.fm_ddr_load_offset : %d" % data_struct.fm_ddr_load_offset + "\n"
    message = message + "opParams.fm_ddr_store_offset : %d" % data_struct.fm_ddr_store_offset + "\n"
    message = message + "addrlessParams.in_fm_shape : %d , %d , %d , %d" % (in_fm_shape.fm_n, in_fm_shape.fm_h, in_fm_shape.fm_w, in_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.out_fm_shape : %d , %d , %d , %d" % (out_fm_shape.fm_n, out_fm_shape.fm_h, out_fm_shape.fm_w, out_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.out_fm_shape_valid : %d , %d , %d , %d" % (out_fm_shape_valid.fm_n, out_fm_shape_valid.fm_h, out_fm_shape_valid.fm_w, out_fm_shape_valid.fm_c) + "\n"
    message = message + "addrlessParams.order : %d , %d , %d , %d" % (order.order1, order.order2, order.order3, order.order4) + "\n"
    message = message + "addrlessParams.in_fm_format_type : %d" % data_struct.cpy_param_address.in_fm_format_type + "\n"
    message = message + "addrlessParams.out_fm_format_type : %d" % data_struct.cpy_param_address.out_fm_format_type + "\n"
    message = message + "addrlessParams.cpytype : %d" % data_struct.cpy_param_address.cpytype + "\n"
    message = message + "addrlessParams.quant_bit : %d" % data_struct.cpy_param_address.quant_bit + "\n"
    return message


def add_print(data_struct):
    add_address = data_struct.address
    input0_shape = data_struct.input0_shape
    input1_shape = data_struct.input1_shape
    output_shape = data_struct.output_shape
    message = ""
    message = message + "addresParams.input0_ddr_load_id : %d" % add_address.input0_ddr_load_id + "\n"
    message = message + "addresParams.input1_ddr_load_id : %d" % add_address.input1_ddr_load_id + "\n"
    message = message + "addresParams.ouput_ddr_store_id : %d" % add_address.output_ddr_store_id + "\n"
    message = message + "addresParams.input0_ddr_offset : %d" % add_address.input0_ddr_offset + "\n"
    message = message + "addresParams.input1_ddr_offset : %d" % add_address.input1_ddr_offset + "\n"
    message = message + "addresParams.output_ddr_offset : %d" % add_address.output_ddr_offset + "\n"
    message = message + "opParams.input0_shape : %d , %d , %d , %d" % (input0_shape.fm_n, input0_shape.fm_h, input0_shape.fm_w, input0_shape.fm_c) + "\n"
    message = message + "opParams.input1_shape : %d , %d , %d , %d" % (input1_shape.fm_n, input1_shape.fm_h, input1_shape.fm_w, input1_shape.fm_c) + "\n"
    message = message + "opParams.output_shape : %d , %d , %d , %d" % (output_shape.fm_n, output_shape.fm_h, output_shape.fm_w, output_shape.fm_c) + "\n"
    message = message + "opParams.layout : %d" % data_struct.layout + "\n"
    message = message + "opParams.dtype : %d" % data_struct.dtype + "\n"
    message = message + "opParams.input0Scale : %d" % data_struct.input0Scale + "\n"
    message = message + "opParams.input1Scale : %d" % data_struct.input1Scale + "\n"
    message = message + "opParams.output_scale : %d" % data_struct.output_scale + "\n"
    message = message + "opParams.output_shift : %d" % data_struct.output_shift + "\n"
    message = message + "opParams.acc_shift : %d" % data_struct.acc_shift + "\n"
    message = message + "opParams.fixUP : %d" % data_struct.fixUP + "\n"
    message = message + "opParams.minVal : %d" % data_struct.minVal + "\n"
    message = message + "opParams.maxVal : %d" % data_struct.maxVal + "\n"
    return message


def softmax_print(data_struct):
    add_address = data_struct.address
    tensor_shape = data_struct.tensor_shape
    message = ""
    message = message + "addrParams.input_ddr_load_id : %d" % add_address.input_ddr_load_id + "\n"
    message = message + "addrParams.ouput_ddr_store_id : %d" % add_address.output_ddr_store_id + "\n"
    message = message + "addrParams.input_ddr_offset : %d" % add_address.input_ddr_offset + "\n"
    message = message + "addrParams.output_ddr_offset : %d" % add_address.output_ddr_offset + "\n"
    message = message + "opParams.tensor_shape : %d , %d , %d , %d" % (tensor_shape.fm_n, tensor_shape.fm_h, tensor_shape.fm_w, tensor_shape.fm_c) + "\n"
    message = message + "opParams.layout : %d" % data_struct.layout + "\n"
    message = message + "opParams.dtype : %d" % data_struct.dtype + "\n"
    if data_struct == VDSP_SOFTMAX_PARAM_T:
        message = message + "opParams.valid_hidden_size : %d" % data_struct.valid_hidden_size + "\n"
    message = message + "opParams.scale : %f" % data_struct.scale + "\n"
    message = message + "opParams.factor : %f" % data_struct.factor + "\n"
    return message


def matmul_print(data_struct):
    matmul_address = data_struct.matmul_param_addrless
    requantparam0 = matmul_address.requantparam0
    requantparam1 = matmul_address.requant_param1
    requantparam = matmul_address.requantparam
    zpparam = matmul_address.zpparam

    in_fm0_shape = matmul_address.in_fm0_shape
    in_fm1_shape = matmul_address.in_fm1_shape
    out_fm_shape = matmul_address.out_fm_shape
    out_fm_shape_valid = matmul_address.out_fm_shape_valid
    # pre_trans_in_fm0_shape = matmul_address.pre_trans_in_fm0_shape
    # pre_trans_in_fm1_shape = matmul_address.pre_trans_in_fm1_shape

    message = ""
    message = message + "opParams.fm0_ddr_load_id : %d" % data_struct.fm0_ddr_load_id + "\n"
    message = message + "opParams.fm1_ddr_load_id : %d" % data_struct.fm1_ddr_load_id + "\n"
    message = message + "opParams.fm_ddr_store_id : %d" % data_struct.fm_ddr_store_id + "\n"

    message = message + "opParams.fm0_ddr_load_offset : %d" % data_struct.fm0_ddr_load_offset + "\n"
    message = message + "opParams.fm1_ddr_load_offset : %d" % data_struct.fm1_ddr_load_offset + "\n"
    message = message + "opParams.fm_ddr_store_offset : %d" % data_struct.fm_ddr_store_offset + "\n"

    message = message + "addrlessParams.in_fm0_shape : %d , %d , %d , %d" % (in_fm0_shape.fm_n, in_fm0_shape.fm_h, in_fm0_shape.fm_w, in_fm0_shape.fm_c) + "\n"
    message = message + "addrlessParams.in_fm1_shape : %d , %d , %d , %d" % (in_fm1_shape.fm_n, in_fm1_shape.fm_h, in_fm1_shape.fm_w, in_fm1_shape.fm_c) + "\n"
    message = message + "addrlessParams.out_fm_shape : %d , %d , %d , %d" % (out_fm_shape.fm_n, out_fm_shape.fm_h, out_fm_shape.fm_w, out_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.out_fm_shape_valid : %d , %d , %d , %d" % (out_fm_shape_valid.fm_n, out_fm_shape_valid.fm_h, out_fm_shape_valid.fm_w, out_fm_shape_valid.fm_c) + "\n"
    # message = message + "addrlessParams.pre_trans_in_fm0_shape : %d , %d , %d , %d" % (pre_trans_in_fm0_shape.fm_n, pre_trans_in_fm0_shape.fm_h, pre_trans_in_fm0_shape.fm_w, pre_trans_in_fm0_shape.fm_c) + "\n"
    # message = message + "addrlessParams.pre_trans_in_fm1_shape : %d , %d , %d , %d" % (pre_trans_in_fm1_shape.fm_n, pre_trans_in_fm1_shape.fm_h, pre_trans_in_fm1_shape.fm_w, pre_trans_in_fm1_shape.fm_c) + "\n"

    message = message + "addrlessParams.fm0_permute : %d" % matmul_address.fm0_permute + "\n"
    message = message + "addrlessParams.fm1_permute : %d" % matmul_address.fm1_permute + "\n"
    message = message + "addrlessParams.matmulmode : %d" % matmul_address.matmulmode + "\n"
    message = message + "addrlessParams.in_fm0_format_type : %d" % matmul_address.in_fm0_format_type + "\n"
    message = message + "addrlessParams.in_fm1_format_type : %d" % matmul_address.in_fm1_format_type + "\n"
    message = message + "addrlessParams.out_fm_format_type : %d" % matmul_address.out_format_type + "\n"
    message = message + "addrlessParams.matmulmode : %d" % matmul_address.matmulmode + "\n"
    message = message + "addrlessParams.in_fm0_format_type : %d" % matmul_address.in_fm0_format_type + "\n"
    message = message + "addrlessParams.in_fm1_format_type : %d" % matmul_address.in_fm1_format_type + "\n"

    message = message + "addrlessParams.quant_bit : %d" % matmul_address.quant_bit + "\n"
    message = message + "addrlessParams.fm_quant_type : %d" % matmul_address.fm_quant_type + "\n"
    message = message + "addrlessParams.fm_quant_mode : %d" % matmul_address.fm_quant_mode + "\n"
    message = message + "addrlessParams.fm_quant_sym : %d" % matmul_address.fm_quant_sym + "\n"

    message = message + "addrlessParams.requantparam0.multiplier : %d" % requantparam0.multipliter + "\n"
    message = message + "addrlessParams.requantparam0.shift : %d" % requantparam0.shift + "\n"
    message = message + "addrlessParams.requantparam0.exponent : %d" % requantparam0.exponent + "\n"
    message = message + "addrlessParams.requantparam1.multiplier : %d" % requantparam1.multipliter + "\n"
    message = message + "addrlessParams.requantparam1.shift : %d" % requantparam1.shift + "\n"
    message = message + "addrlessParams.requantparam1.exponent : %d" % requantparam1.exponent + "\n"

    message = message + "addrlessParams.requantparam.multiplier : %d" % requantparam.multipliter + "\n"
    message = message + "addrlessParams.requantparam.shift : %d" % requantparam.shift + "\n"
    message = message + "addrlessParams.requantparam.exponent : %d" % requantparam.exponent + "\n"

    message = message + "addrlessParams.zpparam.zeropoint_in[0] : %d" % zpparam.zeropoint_in[0] + "\n"
    message = message + "addrlessParams.zpparam.zeropoint_in[1] : %d" % zpparam.zeropoint_in[1] + "\n"
    message = message + "addrlessParams.zpparam.zeropoint_out[0] : %d" % zpparam.zeropoint_out[0] + "\n"
    message = message + "addrlessParams.zpparam.zeropoint_out[1] : %d" % zpparam.zeropoint_out[1] + "\n"
    message = message + "addrlessParams.zpparam.wt_zeropoint[0] : %d" % zpparam.wt_zeropoint[0] + "\n"
    message = message + "addrlessParams.zpparam.wt_zeropoint[1] : %d" % zpparam.wt_zeropoint[1] + "\n"
    message = message + "addrlessParams.post_cont_enable : %d" % matmul_address.post_cont_enable + "\n"
    message = message + "addrlessParams.pre_matmul_scale : %f" % matmul_address.pre_matmul_scale + "\n"
    message = message + "addrlessParams.post_matmul_scale : %f" % matmul_address.post_matmul_scale + "\n"
    return message


def rmsnorm_print(data_struct):
    rms_norm_param_addrless = data_struct.rms_norm_param_addrless
    requantparam = rms_norm_param_addrless.requantparam
    zpparam = rms_norm_param_addrless.zpparam

    in_fm_shape = rms_norm_param_addrless.in_fm_shape
    out_fm_shape = rms_norm_param_addrless.out_fm_shape
    out_fm_shape_valid = rms_norm_param_addrless.out_fm_shape_valid
    message = ""
    message = message + "opParams.fm_ddr_load_id : %d" % data_struct.fm_ddr_load_id + "\n"
    message = message + "opParams.wt_ddr_load_id : %d" % data_struct.wt_ddr_load_id + "\n"
    message = message + "opParams.fm_ddr_store_id : %d" % data_struct.fm_ddr_store_id + "\n"

    message = message + "opParams.fm_ddr_load_offset : %d" % data_struct.fm_ddr_load_offset + "\n"
    message = message + "opParams.wt_ddr_load_offset : %d" % data_struct.wt_ddr_load_offset + "\n"
    message = message + "opParams.fm_ddr_store_offset : %d" % data_struct.fm_ddr_store_offset + "\n"

    message = message + "addrlessParams.in_fm_shape : %d , %d , %d , %d" % (in_fm_shape.fm_n, in_fm_shape.fm_h, in_fm_shape.fm_w, in_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.out_fm_shape : %d , %d , %d , %d" % (out_fm_shape.fm_n, out_fm_shape.fm_h, out_fm_shape.fm_w, out_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.out_fm_shape_valid : %d , %d , %d , %d" % (out_fm_shape_valid.fm_n, out_fm_shape_valid.fm_h, out_fm_shape_valid.fm_w, out_fm_shape_valid.fm_c) + "\n"

    message = message + "addrlessParams.in_fm_format_type : %d" % rms_norm_param_addrless.in_fm_format_type + "\n"
    message = message + "addrlessParams.out_fm_format_type : %d" % rms_norm_param_addrless.out_format_type + "\n"

    message = message + "addrlessParams.quant_bit : %d" % rms_norm_param_addrless.quant_bit + "\n"
    message = message + "addrlessParams.fm_quant_type : %d" % rms_norm_param_addrless.fm_quant_type + "\n"
    message = message + "addrlessParams.fm_quant_mode : %d" % rms_norm_param_addrless.fm_quant_mode + "\n"
    message = message + "addrlessParams.fm_quant_sym : %d" % rms_norm_param_addrless.fm_quant_sym + "\n"

    message = message + "addrlessParams.eps : %f" % rms_norm_param_addrless.eps + "\n"

    message = message + "addrlessParams.requantparam.multiplier : %d" % requantparam.multipliter + "\n"
    message = message + "addrlessParams.requantparam.shift : %d" % requantparam.shift + "\n"
    message = message + "addrlessParams.requantparam.exponent : %d" % requantparam.exponent + "\n"

    message = message + "addrlessParams.zpparam.zeropoint_in[0] : %d" % zpparam.zeropoint_in[0] + "\n"
    message = message + "addrlessParams.zpparam.zeropoint_in[1] : %d" % zpparam.zeropoint_in[1] + "\n"
    message = message + "addrlessParams.zpparam.zeropoint_out[0] : %d" % zpparam.zeropoint_out[0] + "\n"
    message = message + "addrlessParams.zpparam.zeropoint_out[1] : %d" % zpparam.zeropoint_out[1] + "\n"
    message = message + "addrlessParams.zpparam.wt_zeropoint[0] : %d" % zpparam.wt_zeropoint[0] + "\n"
    message = message + "addrlessParams.zpparam.wt_zeropoint[1] : %d" % zpparam.wt_zeropoint[1] + "\n"
    return message


def layer_norm_print(data_struct):
    in_fm_shape = data_struct.in_fm_shape
    out_fm_shape = data_struct.out_fm_shape
    out_fm_shape_valid = data_struct.out_fm_shape_valid
    message = ""
    message = message + "addrlessParams.in_fm_shape : %d , %d , %d , %d" % (in_fm_shape.fm_n, in_fm_shape.fm_h, in_fm_shape.fm_w, in_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.out_fm_shape : %d , %d , %d , %d" % (out_fm_shape.fm_n, out_fm_shape.fm_h, out_fm_shape.fm_w, out_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.out_fm_shape_valid : %d , %d , %d , %d" % (out_fm_shape_valid.fm_n, out_fm_shape_valid.fm_h, out_fm_shape_valid.fm_w, out_fm_shape_valid.fm_c) + "\n"

    message = message + "addrlessParams.in_format_type : %d" % data_struct.in_format_type + "\n"
    message = message + "addrlessParams.input_dtype : %d" % data_struct.input_dtype + "\n"
    message = message + "addrlessParams.axis : %d" % data_struct.axis + "\n"
    message = message + "addrlessParams.epsilon : %0.5f" % data_struct.epsilon + "\n"

    message = message + "opParams.input_ddr_load_id : %d" % data_struct.input_ddr_load_id + "\n"
    message = message + "opParams.scale_ddr_load_id : %d" % data_struct.scale_ddr_load_id + "\n"
    message = message + "opParams.bias_ddr_load_id : %d" % data_struct.bias_ddr_load_id + "\n"
    message = message + "opParams.output_ddr_store_id : %d" % data_struct.output_ddr_store_id + "\n"

    message = message + "opParams.input_ddr_load_offset : %d" % data_struct.input_ddr_load_offset + "\n"
    message = message + "opParams.scale_ddr_load_offset : %d" % data_struct.scale_ddr_load_offset + "\n"
    message = message + "opParams.bias_ddr_load_offset : %d" % data_struct.bias_ddr_load_offset + "\n"
    message = message + "opParams.output_ddr_store_offset : %d" % data_struct.output_ddr_store_offset + "\n"
    return message


def rope_print(data_struct):
    rope_param_addrless = data_struct.rope_param_addrless
    in_fm_shape = rope_param_addrless.in_fm_shape
    in_pos_shape = rope_param_addrless.in_pos_shape
    in_scale_shape = rope_param_addrless.in_scale_shape
    out_fm_shape = rope_param_addrless.out_fm_shape
    out_fm_shape_valid = rope_param_addrless.out_fm_shape_valid
    fm_requantparam = rope_param_addrless.fm_requantparam
    out_requantparam = rope_param_addrless.out_requantparam
    zero_point_param = rope_param_addrless.zero_point_param
    message = ""
    message = message + "opParams.fm_ddr_load_id : %d" % data_struct.fm_ddr_load_id + "\n"
    message = message + "opParams.in_pos_cos_load_id : %d" % data_struct.in_pos_cos_load_id + "\n"
    message = message + "opParams.in_pos_sin_load_id : %d" % data_struct.in_pos_sin_load_id + "\n"
    message = message + "opParams.scalar_to_vec_id : %d" % data_struct.scalar_to_vec_id + "\n"
    message = message + "opParams.fm_ddr_store_id : %d" % data_struct.fm_ddr_store_id + "\n"
    message = message + "opParams.fm_ddr_load_offset : %d" % data_struct.fm_ddr_load_offset + "\n"
    message = message + "opParams.in_pos_cos_load_offset : %d" % data_struct.in_pos_cos_load_offset + "\n"
    message = message + "opParams.in_pos_sin_load_offset : %d" % data_struct.in_pos_sin_load_offset + "\n"
    message = message + "opParams.scalar_to_vec_offset : %d" % data_struct.scalar_to_vec_id_offset + "\n"
    message = message + "opParams.fm_ddr_store_offset : %d" % data_struct.fm_ddr_store_offset + "\n"
    message = message + "addrlessParams.in_fm_shape : %d , %d , %d , %d" % (in_fm_shape.fm_n, in_fm_shape.fm_h, in_fm_shape.fm_w, in_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.in_pos_shape : %d , %d , %d , %d" % (in_pos_shape.fm_n, in_pos_shape.fm_h, in_pos_shape.fm_w, in_pos_shape.fm_c) + "\n"
    message = message + "addrlessParams.in_scale_shape : %d , %d , %d , %d" % (in_scale_shape.fm_n, in_scale_shape.fm_h, in_scale_shape.fm_w, in_scale_shape.fm_c) + "\n"
    message = message + "addrlessParams.out_fm_shape_valid : %d , %d , %d , %d" % (out_fm_shape_valid.fm_n, out_fm_shape_valid.fm_h, out_fm_shape_valid.fm_w, out_fm_shape_valid.fm_c) + "\n"
    message = message + "addrlessParams.out_fm_shape : %d , %d , %d , %d" % (out_fm_shape.fm_n, out_fm_shape.fm_h, out_fm_shape.fm_w, out_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.in_fm_format_type : %d" % rope_param_addrless.in_fm_format_type + "\n"
    message = message + "addrlessParams.out_fm_format_type : %d" % rope_param_addrless.out_format_type + "\n"
    message = message + "addrlessParams.quant_bit : %d" % rope_param_addrless.quant_bit + "\n"
    message = message + "addrlessParams.fm_quant_type : %d" % rope_param_addrless.fm_quant_type + "\n"
    message = message + "addrlessParams.fm_quant_mode : %d" % rope_param_addrless.fm_quant_mode + "\n"
    message = message + "addrlessParams.ropetype : %d" % rope_param_addrless.ropetype + "\n"
    message = message + "addrlessParams.fm_quant_sym : %d" % rope_param_addrless.fm_quant_sym + "\n"
    message = message + "addrlessParams.fm_requantparam.multiplier : %d" % fm_requantparam.multipliter + "\n"
    message = message + "addrlessParams.fm_requantparam.shift : %d" % fm_requantparam.shift + "\n"
    message = message + "addrlessParams.fm_requantparam.exponent : %d" % fm_requantparam.exponent + "\n"
    message = message + "addrlessParams.out_requantparam.multiplier : %d" % out_requantparam.multipliter + "\n"
    message = message + "addrlessParams.out_requantparam.shift : %d" % out_requantparam.shift + "\n"
    message = message + "addrlessParams.out_requantparam.exponent : %d" % out_requantparam.exponent + "\n"
    message = message + "addrlessParams.zero_point_param.zeropoint_in[0] : %d" % zero_point_param.zeropoint_in[0] + "\n"
    message = message + "addrlessParams.zero_point_param.zeropoint_in[1] : %d" % zero_point_param.zeropoint_in[1] + "\n"
    message = message + "addrlessParams.zero_point_param.zeropoint_in[0] : %d" % zero_point_param.zeropoint_in[0] + "\n"
    message = message + "addrlessParams.zero_point_param.zeropoint_in[1] : %d" % zero_point_param.zeropoint_in[1] + "\n"
    message = message + "addrlessParams.zero_point_param.zeropoint_in[2] : %d" % zero_point_param.zeropoint_in[2] + "\n"
    message = message + "addrlessParams.zero_point_param.zeropoint_in[3] : %d" % zero_point_param.zeropoint_in[3] + "\n"
    message = message + "addrlessParams.zero_point_param.zeropoint_out[0] : %d" % zero_point_param.zeropoint_out[0] + "\n"
    message = message + "addrlessParams.zero_point_param.zeropoint_out[1] : %d" % zero_point_param.zeropoint_out[1] + "\n"
    message = message + "addrlessParams.zero_point_param.zeropoint_out[2] : %d" % zero_point_param.zeropoint_out[2] + "\n"
    message = message + "addrlessParams.zero_point_param.zeropoint_out[3] : %d" % zero_point_param.zeropoint_out[3] + "\n"
    message = message + "addrlessParams.zero_point_param.wt_zeropoint[0] : %d" % zero_point_param.wt_zeropoint[0] + "\n"
    message = message + "addrlessParams.zero_point_param.wt_zeropoint[1] : %d" % zero_point_param.wt_zeropoint[1] + "\n"
    message = message + "addrlessParams.rope_scale : %d" % rope_param_addrless.rope_scale + "\n"
    return message


def flash_attention_print(data_struct):
    fa_addr = data_struct.S_FLASH_ATTENTION_PARAM_ADDRESS

    q_fm_shape = fa_addr.q_fm_shape
    k_fm_shape = fa_addr.k_fm_shape
    v_fm_shape = fa_addr.v_fm_shape
    q_fm_tiling_shape = fa_addr.q_fm_tiling_shape
    k_fm_tiling_shape = fa_addr.k_fm_tiling_shape
    v_fm_tiling_shape = fa_addr.v_fm_tiling_shape
    out_fm_shape = fa_addr.out_fm_shape
    out_fm_shape_valid = fa_addr.out_fm_shape_valid

    q_requantparam = fa_addr.q_requantparam
    k_requantparam = fa_addr.k_requantparam
    v_requantparam = fa_addr.v_requantparam
    qk_out_requantparam = fa_addr.qk_out_requantparam
    qkv_out_requantparam = fa_addr.qkv_out_requantparam
    out_requantparam = fa_addr.out_requantparam
    zpparam = fa_addr.zpparam

    message = ""
    message = message + "addrlessParams.q_fm_shape : %d , %d , %d , %d" % (q_fm_shape.fm_n, q_fm_shape.fm_h, q_fm_shape.fm_w, q_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.k_fm_shape : %d , %d , %d , %d" % (k_fm_shape.fm_n, k_fm_shape.fm_h, k_fm_shape.fm_w, k_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.v_fm_shape : %d , %d , %d , %d" % (v_fm_shape.fm_n, v_fm_shape.fm_h, v_fm_shape.fm_w, v_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.q_fm_tiling_shape : %d , %d , %d , %d" % (q_fm_tiling_shape.fm_n, q_fm_tiling_shape.fm_h, q_fm_tiling_shape.fm_w, q_fm_tiling_shape.fm_c) + "\n"
    message = message + "addrlessParams.k_fm_tiling_shape : %d , %d , %d , %d" % (k_fm_tiling_shape.fm_n, k_fm_tiling_shape.fm_h, k_fm_tiling_shape.fm_w, k_fm_tiling_shape.fm_c) + "\n"
    message = message + "addrlessParams.v_fm_tiling_shape : %d , %d , %d , %d" % (v_fm_tiling_shape.fm_n, v_fm_tiling_shape.fm_h, v_fm_tiling_shape.fm_w, v_fm_tiling_shape.fm_c) + "\n"
    message = message + "addrlessParams.out_fm_shape : %d , %d , %d , %d" % (out_fm_shape.fm_n, out_fm_shape.fm_h, out_fm_shape.fm_w, out_fm_shape.fm_c) + "\n"
    message = message + "addrlessParams.out_fm_shape_valid : %d , %d , %d , %d" % (out_fm_shape_valid.fm_n, out_fm_shape_valid.fm_h, out_fm_shape_valid.fm_w, out_fm_shape_valid.fm_c) + "\n"

    message = message + "addrlessParams.q_permute : %d" % fa_addr.q_permute + "\n"
    message = message + "addrlessParams.k_permute : %d" % fa_addr.k_permute + "\n"
    message = message + "addrlessParams.v_permute : %d" % fa_addr.v_permute + "\n"

    message = message + "addrlessParams.q_format_type : %d" % fa_addr.q_format_type + "\n"
    message = message + "addrlessParams.k_format_type : %d" % fa_addr.k_format_type + "\n"
    message = message + "addrlessParams.v_format_type : %d" % fa_addr.v_format_type + "\n"
    message = message + "addrlessParams.out_format_type : %d" % fa_addr.out_format_type + "\n"

    message = message + "addrlessParams.custom_flash_attention_addr_type : %d" % fa_addr.custom_flash_attention_addr_type + "\n"
    message = message + "addrlessParams.softmax_mode_type : %d" % fa_addr.softmax_mode_type + "\n"
    message = message + "addrlessParams.quant_bit : %d" % fa_addr.quant_bit + "\n"
    message = message + "addrlessParams.fm_quant_type : %d" % fa_addr.fm_quant_type + "\n"
    message = message + "addrlessParams.fm_quant_mode : %d" % fa_addr.fm_quant_mode + "\n"
    message = message + "addrlessParams.fm_quant_sym : %d" % fa_addr.fm_quant_sym + "\n"

    message = message + "addrlessParams.q_in_scale : %f" % fa_addr.q_in_scale + "\n"
    message = message + "addrlessParams.k_in_scale : %f" % fa_addr.k_in_scale + "\n"
    message = message + "addrlessParams.v_in_scale : %f" % fa_addr.v_in_scale + "\n"
    message = message + "addrlessParams.qk_out_scale : %f" % fa_addr.qk_out_scale + "\n"
    message = message + "addrlessParams.exp_out_scale : %f" % fa_addr.exp_out_scale + "\n"
    message = message + "addrlessParams.qkv_out_scale : %f" % fa_addr.qkv_out_scale + "\n"
    message = message + "addrlessParams.fa_output_scale : %f" % fa_addr.fa_output_scale + "\n"

    message = message + "addrlessParams.q_requantparam.multiplier : %d" % q_requantparam.multipliter + "\n"
    message = message + "addrlessParams.q_requantparam.shift : %d" % q_requantparam.shift + "\n"
    message = message + "addrlessParams.q_requantparam.exponent : %d" % q_requantparam.exponent + "\n"
    message = message + "addrlessParams.k_requantparam.multiplier : %d" % k_requantparam.multipliter + "\n"
    message = message + "addrlessParams.k_requantparam.shift : %d" % k_requantparam.shift + "\n"
    message = message + "addrlessParams.k_requantparam.exponent : %d" % k_requantparam.exponent + "\n"
    message = message + "addrlessParams.v_requantparam.multiplier : %d" % v_requantparam.multipliter + "\n"
    message = message + "addrlessParams.v_requantparam.shift : %d" % v_requantparam.shift + "\n"
    message = message + "addrlessParams.v_requantparam.exponent : %d" % v_requantparam.exponent + "\n"
    message = message + "addrlessParams.qk_out_requantparam.multiplier : %d" % qk_out_requantparam.multipliter + "\n"
    message = message + "addrlessParams.qk_out_requantparam.shift : %d" % qk_out_requantparam.shift + "\n"
    message = message + "addrlessParams.qk_out_requantparam.exponent : %d" % qk_out_requantparam.exponent + "\n"
    message = message + "addrlessParams.qkv_out_requantparam.multiplier : %d" % qkv_out_requantparam.multipliter + "\n"
    message = message + "addrlessParams.qkv_out_requantparam.shift : %d" % qkv_out_requantparam.shift + "\n"
    message = message + "addrlessParams.qkv_out_requantparam.exponent : %d" % qkv_out_requantparam.exponent + "\n"

    message = message + "addrlessParams.out_requantparam.multiplier : %d" % out_requantparam.multipliter + "\n"
    message = message + "addrlessParams.out_requantparam.shift : %d" % out_requantparam.shift + "\n"
    message = message + "addrlessParams.out_requantparam.exponent : %d" % out_requantparam.exponent + "\n"

    for i in range(4):
        message = message + "addrlessParams.zpparam.zeropoint_in[%d] : %d" % (i, zpparam.zeropoint_in[i]) + "\n"
    for i in range(4):
        message = message + "addrlessParams.zpparam.zeropoint_out[%d] : %d" % (i, zpparam.zeropoint_out[i]) + "\n"
    for i in range(2):
        message = message + "addrlessParams.zpparam.wt_zeropoint[%d] : %d" % (i, zpparam.wt_zeropoint[i]) + "\n"

    message = message + "addrlessParams.softmax_valid_hidden_size : %d" % fa_addr.softmax_valid_hidden_size + "\n"
    message = message + "addrlessParams.contex_seq : %d" % fa_addr.contex_seq + "\n"
    message = message + "addrlessParams.tus_config : %d" % fa_addr.tus_config + "\n"
    message = message + "addrlessParams.enable_npu_matmul_encode : %d" % fa_addr.enable_npu_matmul_encode + "\n"
    message = message + "addrlessParams.enable_npu_matmul_decode : %d" % fa_addr.enable_npu_matmul_decode + "\n"
    message = message + "addrlessParams.softmax_scale : %f" % fa_addr.softmax_scale + "\n"

    message = message + "opParams.tsu_map_load_id : %d" % data_struct.tsu_map_load_id + "\n"
    message = message + "opParams.q_ddr_load_id : %d" % data_struct.q_ddr_load_id + "\n"
    message = message + "opParams.k_ddr_contex_load_id : %d" % data_struct.k_ddr_contex_load_id + "\n"
    message = message + "opParams.v_ddr_contex_load_id : %d" % data_struct.v_ddr_contex_load_id + "\n"
    message = message + "opParams.k_ddr_load_id : %d" % data_struct.k_ddr_load_id + "\n"
    message = message + "opParams.v_ddr_load_id : %d" % data_struct.v_ddr_load_id + "\n"
    message = message + "opParams.fm_ddr_store_id : %d" % data_struct.fm_ddr_store_id + "\n"
    message = message + "opParams.qk_ddr_store_id : %d" % data_struct.qk_ddr_store_id + "\n"
    message = message + "opParams.qkv_ddr_store_id : %d" % data_struct.qkv_ddr_store_id + "\n"

    message = message + "opParams.tsu_map_load_offset : %d" % data_struct.tsu_map_load_offset + "\n"
    message = message + "opParams.q_ddr_load_offset : %d" % data_struct.q_ddr_load_offset + "\n"
    message = message + "opParams.k_ddr_contex_load_offset : %d" % data_struct.k_ddr_contex_load_offset + "\n"
    message = message + "opParams.v_ddr_contex_load_offset : %d" % data_struct.v_ddr_contex_load_offset + "\n"
    message = message + "opParams.k_ddr_load_offset : %d" % data_struct.k_ddr_load_offset + "\n"
    message = message + "opParams.v_ddr_load_offset : %d" % data_struct.v_ddr_load_offset + "\n"
    message = message + "opParams.qk_ddr_store_offset : %d" % data_struct.qk_ddr_store_offset + "\n"
    message = message + "opParams.qkv_ddr_store_offset : %d" % data_struct.qkv_ddr_store_offset + "\n"
    message = message + "opParams.fm_ddr_store_offset : %d" % data_struct.fm_ddr_store_offset + "\n"

    message = message + "addrlessParams.npu_cmd_id : %d" % data_struct.npu_cmd_id + "\n"
    for i in range(8):
        message = message + "addrlessParams.cmd_offset[%d] : %d" % (i, data_struct.cmd_offset[i]) + "\n"
    for i in range(8):
        message = message + "addrlessParams.cmd_size[%d] : %d" % (i, data_struct.cmd_size[i]) + "\n"

    message = message + "addrlessParams.cmd_count : %d" % data_struct.cmd_count + "\n"
    return message


# ============================================================
# 结构体定义
# ============================================================

class S_CPY_PARAM_ADDRESS(ctypes.Structure):
    _fields_ = [
        ('in_fm_shape', FmShape),
        ('out_fm_shape', FmShape),
        ('out_fm_shape_valid', FmShape),
        ('in_fm_format_type', ctypes.c_int32),
        ('out_fm_format_type', ctypes.c_int32),
        ('cpytype', ctypes.c_int32),
        ('quant_bit', ctypes.c_int32),
        ('order', Transpose),
    ]

class S_COPY_OP_PARAM(ctypes.Structure):
    _fields_ = [
        ('cpy_param_address', S_CPY_PARAM_ADDRESS),
        ('fm_ddr_load_id', ctypes.c_uint32),
        ('fm_ddr_store_id', ctypes.c_uint32),
        ('fm_ddr_load_offset', ctypes.c_uint32),
        ('fm_ddr_store_offset', ctypes.c_uint32)
    ]


class ADDAddress(ctypes.Structure):
    _fields_ = [
        ('input0_ddr_load_id',  ctypes.c_uint32),
        ('input1_ddr_load_id',  ctypes.c_uint32),
        ('output_ddr_store_id',  ctypes.c_uint32),
        ('input0_ddr_offset',  ctypes.c_uint32),
        ('input1_ddr_offset',  ctypes.c_uint32),
        ('output_ddr_offset',  ctypes.c_uint32)
    ]

class VDSP_ADD_PARAM_T(ctypes.Structure):
    _fields_ = [
        ('input0_shape', FmShape),
        ('input1_shape', FmShape),
        ('output_shape', FmShape),
        ('layout', ctypes.c_int32),
        ('dtype', ctypes.c_int32),
        ('input0Scale', ctypes.c_uint16),
        ('input1Scale', ctypes.c_uint16),
        ('output_scale', ctypes.c_uint16),
        ('output_shift', ctypes.c_uint8),
        ('acc_shift', ctypes.c_uint8),
        ('fixUP', ctypes.c_int32),
        ('minVal', ctypes.c_int32),
        ('maxVal', ctypes.c_int32),
        ('address', ADDAddress)
    ]


class SoftmaxAddress(ctypes.Structure):
    _fields_ = [
        ('input_ddr_load_id',  ctypes.c_uint32),
        ('output_ddr_store_id',  ctypes.c_uint32),
        ('input_ddr_offset',  ctypes.c_uint32),
        ('output_ddr_offset',  ctypes.c_uint32)
    ]

class VDSP_SOFTMAX_PARAM_T(ctypes.Structure):
    _fields_ = [
        ('tensor_shape', FmShape),
        ('layout', ctypes.c_int32),
        ('dtype', ctypes.c_int32),
        ('valid_hidden_size', ctypes.c_uint32),
        ('scale', ctypes.c_float),
        ('factor', ctypes.c_float),
        ('address', SoftmaxAddress)
    ]

class VDSP_STD_SOFTMAX_PARAM_T(ctypes.Structure):
    _fields_ = [
        ('tensor_shape', FmShape),
        ('layout', ctypes.c_int32),
        ('dtype', ctypes.c_int32),
        ('scale', ctypes.c_float),
        ('factor', ctypes.c_float),
        ('address', SoftmaxAddress)
    ]


class S_MATMUL_PARAM_ADDRESS(ctypes.Structure):
    _fields_ = [
        ("in_fm0_shape", FmShape),
        ("in_fm1_shape", FmShape),
        ("out_fm_shape", FmShape),
        ("out_fm_shape_valid", FmShape),
        # ("pre_trans_in_fm0_shape", FmShape),
        # ("pre_trans_in_fm1_shape", FmShape),
        ("fm0_permute", ctypes.c_int32),
        ("fm1_permute",  ctypes.c_int32),
        ("in_fm0_format_type",  ctypes.c_int32),
        ("in_fm1_format_type",  ctypes.c_int32),
        ("out_format_type",  ctypes.c_int32),
        ("matmulmode",  ctypes.c_int32),
        ("quant_bit",  ctypes.c_int32),
        ("fm_quant_type",  ctypes.c_int32),
        ("fm_quant_mode",  ctypes.c_int32),
        ("fm_quant_sym",  ctypes.c_int32),
        ("requantparam0",  ReQuantParam),
        ("requant_param1",  ReQuantParam),
        ("requantparam",  ReQuantParam),
        ("zpparam",  ReQuantZpParam),
        ("post_cont_enable",  ctypes.c_int32),
        ("pre_matmul_scale",  ctypes.c_float),
        ("post_matmul_scale",  ctypes.c_float)
    ]

class S_MATMUL_OP_PARAM(ctypes.Structure):
    _fields_ = [
        ("matmul_param_addrless",  S_MATMUL_PARAM_ADDRESS),
        ("fm0_ddr_load_id", ctypes.c_uint32),
        ("fm1_ddr_load_id", ctypes.c_uint32),
        ("fm_ddr_store_id", ctypes.c_uint32),
        ("fm0_ddr_load_offset", ctypes.c_uint32),
        ("fm1_ddr_load_offset", ctypes.c_uint32),
        ("fm_ddr_store_offset", ctypes.c_uint32)
    ]


class S_FLASH_ATTENTION_PARAM_ADDRESS(ctypes.Structure):
    _fields_ = [
        ("q_fm_shape", FmShape),
        ("k_fm_shape", FmShape),
        ("v_fm_shape", FmShape),
        ("q_fm_tiling_shape", FmShape),
        ("k_fm_tiling_shape", FmShape),
        ("v_fm_tiling_shape", FmShape),
        ("out_fm_shape", FmShape),
        ("out_fm_shape_valid", FmShape),

        ("q_permute", ctypes.c_int32),
        ("k_permute",  ctypes.c_int32),
        ("v_permute",  ctypes.c_int32),

        ("q_format_type",  ctypes.c_int32),
        ("k_format_type",  ctypes.c_int32),
        ("v_format_type",  ctypes.c_int32),
        ("out_format_type",  ctypes.c_int32),

        ("custom_flash_attention_addr_type",  ctypes.c_int32),
        ("softmax_mode_type",  ctypes.c_int32),
        ("quant_bit",  ctypes.c_int32),
        ("fm_quant_type",  ctypes.c_int32),
        ("fm_quant_mode",  ctypes.c_int32),
        ("fm_quant_sym",  ctypes.c_int32),

        ("q_in_scale",  ctypes.c_float),
        ("k_in_scale",  ctypes.c_float),
        ("v_in_scale",  ctypes.c_float),
        ("qk_out_scale",  ctypes.c_float),
        ("exp_out_scale",  ctypes.c_float),
        ("qkv_out_scale",  ctypes.c_float),
        ("fa_output_scale",  ctypes.c_float),

        ("q_requantparam",  ReQuantParam),
        ("k_requantparam",  ReQuantParam),
        ("v_requantparam",  ReQuantParam),
        ("qk_out_requantparam",  ReQuantParam),
        ("qkv_out_requantparam",  ReQuantParam),
        ("out_requantparam",  ReQuantParam),

        ("zpparam",  ReQuantZpParam),
        ("softmax_valid_hidden_size",  ctypes.c_int32),
        ("contex_seq",  ctypes.c_int32),
        ("tus_config",  ctypes.c_int32),
        ("enable_npu_matmul_encode",   ctypes.c_uint32),
        ("enable_npu_matmul_decode",   ctypes.c_uint32),
        ("softmax_scale",  ctypes.c_float),

    ]
        

class S_FLASH_ATTENTION_OP_PARAM(ctypes.Structure):
        _pack_ = 1  #取消对齐
        _fields_ = [
        ("S_FLASH_ATTENTION_PARAM_ADDRESS", S_FLASH_ATTENTION_PARAM_ADDRESS),
        ("tsu_map_load_id",   ctypes.c_uint32),
        ("q_ddr_load_id",   ctypes.c_uint32),
        ("k_ddr_contex_load_id",   ctypes.c_uint32),
        ("v_ddr_contex_load_id",   ctypes.c_uint32),
        ("k_ddr_load_id",   ctypes.c_uint32),
        ("v_ddr_load_id",   ctypes.c_uint32),
        ("fm_ddr_store_id",   ctypes.c_uint32),
        ("qk_ddr_store_id",   ctypes.c_uint32),
        ("qkv_ddr_store_id",   ctypes.c_uint32),
        ("tsu_map_load_offset",   ctypes.c_uint64),
        ("q_ddr_load_offset",   ctypes.c_uint64),
        ("k_ddr_contex_load_offset",   ctypes.c_uint64),
        ("v_ddr_contex_load_offset",   ctypes.c_uint64),
        ("k_ddr_load_offset",   ctypes.c_uint64),
        ("v_ddr_load_offset",   ctypes.c_uint64),
        ("qk_ddr_store_offset",   ctypes.c_uint64),
        ("qkv_ddr_store_offset",   ctypes.c_uint64),
        ("fm_ddr_store_offset",   ctypes.c_uint64),
        ("npu_cmd_id",   ctypes.c_uint32),
        ("cmd_offset",   ctypes.c_uint64 * 8),
        ("cmd_size",   ctypes.c_uint32 * 8),
        ("cmd_count",   ctypes.c_uint32),

    ]


class S_RMS_NORM_PARAM_ADDRESS(ctypes.Structure):
    _fields_ = [
        ("in_fm_shape", FmShape),
        ("out_fm_shape", FmShape),
        ("out_fm_shape_valid", FmShape),
        ("in_fm_format_type",  ctypes.c_int32),
        ("out_format_type",  ctypes.c_int32),
        ("quant_bit",  ctypes.c_int32),
        ("fm_quant_type",  ctypes.c_int32),
        ("fm_quant_mode",  ctypes.c_int32),
        ("fm_quant_sym",  ctypes.c_int32),
        ("eps",   ctypes.c_float),
        ("requantparam",  ReQuantParam),
        ("zpparam",  ReQuantZpParam)
    ]

class S_LAYER_NORM_PARAM_ADDRESS(ctypes.Structure):
    _fields_ = [
        ("in_fm_shape", FmShape),
        ("out_fm_shape", FmShape),
        ("out_fm_shape_valid", FmShape),
        ("in_format_type",  ctypes.c_int32),
        ("input_dtype",  ctypes.c_int32),
        ("axis",  ctypes.c_uint32),
        ("epsilon",  ctypes.c_float),

        ("input_ddr_load_id",   ctypes.c_int32),
        ("scale_ddr_load_id",  ctypes.c_int32),
        ("bias_ddr_load_id",  ctypes.c_int32),
        ("output_ddr_store_id",  ctypes.c_int32),

        ("input_ddr_load_offset",   ctypes.c_uint32),
        ("scale_ddr_load_offset",  ctypes.c_uint32),
        ("bias_ddr_load_offset",  ctypes.c_uint32),
        ("output_ddr_store_offset",  ctypes.c_uint32),
    ]


class S_GROUP_NORM_PARAM_ADDRESS(ctypes.Structure):
    _fields_ = [
        ("in_fm_shape", FmShape),
        ("out_fm_shape", FmShape),
        ("in_fm_format_type",  ctypes.c_int32),
        ("input_dtype",  ctypes.c_int32),
        ("group_num",  ctypes.c_uint32),
        ("epsilon",  ctypes.c_float),

        ("input_ddr_load_id",   ctypes.c_int32),
        ("scale_ddr_load_id",  ctypes.c_int32),
        ("bias_ddr_load_id",  ctypes.c_int32),
        ("output_ddr_load_id",  ctypes.c_int32),

        ("input_ddr_load_offset",   ctypes.c_uint32),
        ("scale_ddr_load_offset",  ctypes.c_uint32),
        ("bias_ddr_load_offset",  ctypes.c_uint32),
        ("output_ddr_load_offset",  ctypes.c_uint32),
    ]


class S_INSTANCE_NORM_PARAM_ADDRESS(ctypes.Structure):
    _fields_ = [
        ("in_fm_shape", FmShape),
        ("out_fm_shape", FmShape),
        ("in_fm_format_type",  ctypes.c_int32),
        ("input_dtype",  ctypes.c_int32),
        ("epsilon",  ctypes.c_float),

        ("input_ddr_load_id",   ctypes.c_int32),
        ("scale_ddr_load_id",  ctypes.c_int32),
        ("bias_ddr_load_id",  ctypes.c_int32),
        ("output_ddr_load_id",  ctypes.c_int32),

        ("input_ddr_load_offset",   ctypes.c_uint32),
        ("scale_ddr_load_offset",  ctypes.c_uint32),
        ("bias_ddr_load_offset",  ctypes.c_uint32),
        ("output_ddr_load_offset",  ctypes.c_uint32),
    ]


class S_RMS_NORM_OP_PARAM(ctypes.Structure):
    _fields_ = [
        ("rms_norm_param_addrless", S_RMS_NORM_PARAM_ADDRESS),
        ("fm_ddr_load_id", ctypes.c_uint32),
        ("wt_ddr_load_id", ctypes.c_uint32),
        ("fm_ddr_store_id", ctypes.c_uint32),
        ("fm_ddr_load_offset", ctypes.c_uint32),
        ("wt_ddr_load_offset", ctypes.c_uint32),
        ("fm_ddr_store_offset", ctypes.c_uint32)
    ]

class S_ROPE_PARAM_ADDRESS(ctypes.Structure):
    _fields_ = [
        ("in_fm_shape", FmShape),
        ("in_pos_shape", FmShape),
        ("in_scale_shape", FmShape),
        ("out_fm_shape_valid", FmShape),
        ("out_fm_shape", FmShape),
        ("in_fm_format_type",  ctypes.c_int32),
        ("out_format_type",  ctypes.c_int32),

        ("quant_bit",  ctypes.c_int32),
        ("fm_quant_type",  ctypes.c_int32),
        ("fm_quant_mode",  ctypes.c_int32),
        ("ropetype",  ctypes.c_int32),

        ("fm_quant_sym",  ctypes.c_int32),
        ("fm_requantparam",  ReQuantParam),
        ("out_requantparam",  ReQuantParam),
        ("zero_point_param",  ReQuantZpParam),
        ("rope_scale",  ctypes.c_float)
    ]

class S_ROPE_OP_PARAM(ctypes.Structure):
    _fields_ = [
        ("rope_param_addrless", S_ROPE_PARAM_ADDRESS),
        ("fm_ddr_load_id", ctypes.c_uint32),
        ("in_pos_cos_load_id", ctypes.c_uint32),
        ("in_pos_sin_load_id", ctypes.c_uint32),
        ("scalar_to_vec_id", ctypes.c_uint32),
        ("fm_ddr_store_id", ctypes.c_uint32),
        ("fm_ddr_load_offset", ctypes.c_uint32),
        ("in_pos_cos_load_offset", ctypes.c_uint32),
        ("in_pos_sin_load_offset", ctypes.c_uint32),
        ("scalar_to_vec_id_offset", ctypes.c_uint32),
        ("fm_ddr_store_offset", ctypes.c_uint32)
    ]

class S_GATHER_PARAM_ADDRESS(ctypes.Structure):
    _fields_ = [
        ("in_fm_shape", FmShape),
        ("in_index_shape", FmShape),
        ("out_fm_shape", FmShape),
        ("out_fm_shape_valid", FmShape),

        ("in_format_type",  ctypes.c_int32),
        ("out_format_type",  ctypes.c_int32),

        ("quant_bit",  ctypes.c_int32),
        ("gather_axis",  ctypes.c_int32),
        ("gather_opt_mode",  ctypes.c_int32),

        ("fm_ddr_load_id",  ctypes.c_uint32),
        ("index_ddr_load_id",  ctypes.c_uint32),
        ("fm_ddr_store_id",  ctypes.c_uint32),

        ("fm_ddr_load_offset",  ctypes.c_uint32),
        ("index_ddr_load_offset",  ctypes.c_uint32),
        ("fm_ddr_store_offset",  ctypes.c_uint32),
    ]

class S_MOE_FFN_PARAM_ADDRESS(ctypes.Structure):
    _fields_ = [
        ('in1_fm_shape', FmShape),
        ('in2_fm_shape', FmShape),
        ('out_fm_shape', FmShape),
        ('out_fm_shape_valid', FmShape),

        ('in1_fm_format_type', ctypes.c_int32),
        ('in2_fm_format_type', ctypes.c_int32),
        ('out_fm_format_type', ctypes.c_int32),

        ('in1_dtype', ctypes.c_int32),
        ('in2_dtype', ctypes.c_int32),
        ('out_dtype', ctypes.c_int32),
        ("in1_scale",  ctypes.c_float),
        ("in1_zeropoint",  ctypes.c_int32),
        ("in2_scale",  ctypes.c_float),
        ("in2_zeropoint",  ctypes.c_int32),

        ("out_scale",  ctypes.c_float),
        ("out_zeropoint",  ctypes.c_int32),
        ('npu_max_tokens', ctypes.c_int32),

    ]

class S_MOE_FFN_OP_PARAM(ctypes.Structure):
         _pack_ = 1 #ctypes.sizeof(S_MOE_FFN_OP_PARAM)
         _fields_ = [
             ('moe_ffn_param_address', S_MOE_FFN_PARAM_ADDRESS),
             ('fm_in1_ddr_load_id', ctypes.c_uint32),
             ('fm_in2_ddr_load_id', ctypes.c_uint32),
             ('fm_out_ddr_store_id', ctypes.c_uint32),
             ('temp_ddr_id', ctypes.c_uint32),
             ('npu_cmd_ddr_id', ctypes.c_uint32),
             ('npu_coef_ddr_id', ctypes.c_uint32),
             ('fm_in1_ddr_load_offset', ctypes.c_uint64),
             ('fm_in2_ddr_load_offset', ctypes.c_uint64),
             ('fm_ddr_store_offset', ctypes.c_uint64),
             ('temp_ddr_offset', ctypes.c_uint64),
             
             ('npu_cmd_offset', ctypes.c_uint64 * 116),
             ('npu_cmd_size', ctypes.c_uint32 * 116),
             ('npu_coef_offset', ctypes.c_uint64 *116),
             ('npu_coef_size', ctypes.c_uint32 *116),
             ('out_scale', ctypes.c_float *116),
             ('out_zeropoint', ctypes.c_int32 *116),
             ('expert_count', ctypes.c_uint32)
             ]