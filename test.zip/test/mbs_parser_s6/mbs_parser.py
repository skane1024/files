import io
import struct
from enum import Enum
from enum import IntEnum
from vdsp_op_param_parser import *



from mbs_types import *


def fmt_field(name, info, show_field_info, indent=""):
    """格式化字段信息，根据 show_field_info 决定是否显示 offset/size"""
    if show_field_info:
        if isinstance(info['value'], (bytes, bytearray)):
            return (f"{indent}{name}: offset={info['offset']}, "
                    f"size={info['size']}, value={info['value']!r}")
        elif isinstance(info['value'], (list, tuple)):
            return (f"{indent}{name}: offset={info['offset']}, "
                    f"size={info['size']}, value={info['value']}")
        elif isinstance(info['value'], str):
            return (f"{indent}{name}: offset={info['offset']}, "
                    f"size={info['size']}, value={info['value']}")
        else:
            return (f"{indent}{name}: offset={info['offset']}, "
                    f"size={info['size']}, value={info['value']:#010X} ({info['value']})")
    else:
        if isinstance(info['value'], (bytes, bytearray)):
            return f"{indent}{name}: {info['value']!r}"
        elif isinstance(info['value'], (list, tuple)):
            return f"{indent}{name}: {info['value']}"
        elif isinstance(info['value'], str):
            return f"{indent}{name}: {info['value']}"
        else:
            return f"{indent}{name}: {info['value']:#010X} ({info['value']})"

class MBSParser:
    def __init__(self, data):
        # 使用 bytearray 保存数据，便于后续通过 set_field 修改字段值
        self.data = bytearray(data)
        self.index = 0

    #读取指定格式的数据
    def read(self, format_str):
        size = struct.calcsize(format_str)
        if self.index + size > len(self.data):
            raise ValueError("Insufficient data")
        value = struct.unpack_from(format_str, self.data, self.index)
        self.index += size
        return value[0] if len(value) == 1 else value

    #读取指定格式的数据
    def read_binary_block(self, format_str):
        size = struct.calcsize(format_str)
        if self.index + size > len(self.data):
            raise ValueError("Insufficient data")
        data = self.data[self.index: self.index+size]
        self.index += size
        return data

    #读取一个字段，同时记录其偏移、大小、值与格式，便于后续定位并修改字段的值
    def read_field(self, name, format_str, fields):
        offset = self.index
        value = self.read(format_str)
        fields[name] = {
            'offset': offset,
            'size': struct.calcsize(format_str),
            'value': value,
            'format': format_str,
        }
        return value

    #修改已记录字段的值（直接写回底层二进制数据）
    def set_field(self, fields, name, value):
        info = fields[name]
        struct.pack_into(info['format'], self.data, info['offset'], value)
        info['value'] = value

    #解析文件头
    def parse_header(self):
        header = {}
        fields = {}
        header['magic'] = self.read_field('magic', 'I', fields)
        if header['magic'] != MAGIC_EXPECTED:
            raise ValueError("Invalid magic value")
        header['version'] = self.read_field('version', 'I', fields)
        self.version = header['version']
        header['command_stream_flags'] = self.read_field('command_stream_flags', 'I', fields)
        header['command_stream_flags'] = header['command_stream_flags'] & 0xF
        header['reserved_1'] = self.read_field('reserved_1', 'I', fields)
        if header['version'] == VHA_MBS_VERSION_DYNAMIC_SHARE_WEIGHT:
            header['dynamic'] = DynamicFormat(header['reserved_1'])
        header['hw_capabilities_lo'] = self.read_field('hw_capabilities_lo', 'I', fields)
        header['hw_capabilities_hi'] = self.read_field('hw_capabilities_hi', 'I', fields)

        if header['version'] == VHA_MBS_VERSION_DYNAMIC_SHARE_WEIGHT:
            self.MBS_COUNT = header['dynamic'].MBS_COUNT
            self.HAS_VDSP = header['dynamic'].HAS_VDSP
            self.HAS_AIV = header['dynamic'].HAS_AIV
        else:
            self.MBS_COUNT = 1
            self.HAS_VDSP = 0
            self.HAS_AIV = 0
        if header['version'] < VHA_MBS_VERSION_CUSTOM_LAYERS_ADDED:
            raise ValueError("MBS版本低于VHA_MBS_VERSION_CUSTOM_LAYERS_ADDED(15),暂不支持")

        return header, fields

    #解析模型的输入输出信息
    def parse_network_io_descriptor(self):
        descriptor = {}
        fields = {}
        descriptor['size'] = self.read_field('size', 'I', fields)
        descriptor['tensor_length'] = self.read_field('tensor_length', 'I', fields)
        descriptor['tensor_value'] = self.read_field('tensor_value',
            'I' * descriptor['tensor_length'], fields)
        descriptor['format'] = self.read_field('format', 'I', fields)
        descriptor['memory_format'] = MemoryFormat(descriptor['format'])
        if descriptor['memory_format'].IS_Q8A:
            descriptor['format_scale'] = self.read_field('format_scale', 'I', fields)
        else:
            descriptor['format_scale'] = None
        descriptor['buffer_strides_length'] = self.read_field('buffer_strides_length', 'I', fields)
        if descriptor['buffer_strides_length'] > 0:
            descriptor['buffer_strides_value'] = self.read_field('buffer_strides_value',
                'I' * descriptor['buffer_strides_length'], fields)
        else:
            descriptor['buffer_strides_value'] = []
        descriptor['buffer_flags'] = self.read_field('buffer_flags', 'I', fields)
        descriptor['buffer_flags_obj'] = BufferFlags(descriptor['buffer_flags'])
        descriptor['name_length'] = self.read_field('name_length', 'I', fields)
        if descriptor['name_length'] > 0:
            name_offset = self.index
            descriptor['name'] = self.data[self.index:self.index + descriptor['name_length']]
            self.index += descriptor['name_length']
            fields['name'] = {
                'offset': name_offset,
                'size': descriptor['name_length'],
                'value': descriptor['name'],
                'format': f'{descriptor["name_length"]}s',
            }
            # 检查对齐情况  对齐到32
            remaining = (4 - (descriptor['name_length'] % 4)) % 4
            if remaining > 0:
                self.index += remaining
        else:
            descriptor['name'] = b''
        return descriptor, fields

    #解析模型的输入输出信息（整体模块）
    def parse_network_io(self):
        network_io = {}
        fields = {}

        network_io['inputs_count'] = self.read_field('inputs_count', 'I', fields)
        network_io['inputs'] = []
        for i in range(network_io['inputs_count']):
            desc, desc_fields = self.parse_network_io_descriptor()
            network_io['inputs'].append(desc)
            fields[f'input_{i}'] = desc_fields

        network_io['outputs_count'] = self.read_field('outputs_count', 'I', fields)
        network_io['outputs'] = []
        for i in range(network_io['outputs_count']):
            desc, desc_fields = self.parse_network_io_descriptor()
            network_io['outputs'].append(desc)
            fields[f'output_{i}'] = desc_fields

        return network_io, fields

    #解析每个segment的输入输出信息
    def parse_segment_io_descriptor(self):
        descriptor = {}
        fields = {}
        descriptor['buffer_id'] = self.read_field('buffer_id', 'I', fields)
        descriptor['buffer_offset'] = self.read_field('buffer_offset', 'I', fields)
        descriptor['buffer_size'] = self.read_field('buffer_size', 'I', fields)
        descriptor['memory_format'] = MemoryFormat(
            self.read_field('memory_format', 'I', fields))
        if descriptor['memory_format'].IS_Q8A:
            descriptor['format_scale'] = self.read_field('format_scale', 'I', fields)
        else:
            descriptor['format_scale'] = None
        descriptor['buffer_strides_length'] = self.read_field('buffer_strides_length', 'I', fields)
        if descriptor['buffer_strides_length'] > 0:
            descriptor['buffer_strides_value'] = self.read_field('buffer_strides_value',
                'I' * descriptor['buffer_strides_length'], fields)
        else:
            descriptor['buffer_strides_value'] = []
        descriptor['buffer_order'] = self.read_field('buffer_order', 'I', fields)
        descriptor['tensor_length'] = self.read_field('tensor_length', 'I', fields)
        descriptor['tensor_value'] = self.read_field('tensor_value',
            'I' * descriptor['tensor_length'], fields)
        descriptor['tensor_id'] = self.read_field('tensor_id', 'I', fields)

        descriptor['tensor_name_length'] = self.read_field('tensor_name_length', 'I', fields)
        if descriptor['tensor_name_length'] > 0:
            name_offset = self.index
            descriptor['tensor_name_length'] = self.data[self.index:self.index
                + descriptor['tensor_name_length']]
            self.index += len(descriptor['tensor_name_length'])
            fields['tensor_name'] = {
                'offset': name_offset,
                'size': len(descriptor['tensor_name_length']),
                'value': descriptor['tensor_name_length'],
                'format': f'{len(descriptor["tensor_name_length"])}s',
            }
            # 检查对齐情况  对齐到32
            remaining = (4 - (len(descriptor['tensor_name_length']) % 4)) % 4
            if remaining > 0:
                self.index += remaining
        else:
            descriptor['tensor_name'] = b''
        return descriptor, fields


    #解析模型的buffer信息
    def parse_buffer_section(self):
        buffer = {}
        fields = {}
        buffer['num_buffers'] = self.read_field('num_buffers', 'I', fields)
        buffer['buffer_type'] = []
        buffer['buffer_size'] = []
        for i in range(buffer['num_buffers']):
            buffer['buffer_type'].append(
                self.read_field(f'buffer_type_{i}', 'I', fields))
            buffer['buffer_size'].append(
                self.read_field(f'buffer_size_{i}', 'I', fields))
        return buffer, fields

    #解析segmments的信息
    def parse_segment_section(self):
        segment = {}
        fields = {}
        segment['num_segments'] = self.read_field('num_segments', 'I', fields)
        for ns in range(segment['num_segments']):
            segment['segment_id'] = self.read_field('segment_id', 'I', fields)
            segment_flag = self.read_field('segment_flag', 'H', fields)
            segment_type = self.read_field('segment_type', 'H', fields)
            segment['segment_type'] = SegmentType(segment_type)
            segment['segment_flag'] = SegmentFlag(segment_flag)
            segment['segment_estimated_cycles'] = self.read_field('segment_estimated_cycles', 'I', fields)
            segment['inputs_count'] = self.read_field('inputs_count', 'I', fields)
            segment['inputs'] = []
            for i in range(segment['inputs_count']):
                input_desc, input_fields = self.parse_segment_io_descriptor()
                segment['inputs'].append(input_desc)
                fields[f'input_{i}'] = input_fields
            segment['outputs_count'] = self.read_field('outputs_count', 'I', fields)
            segment['outputs'] = []
            for i in range(segment['outputs_count']):
                output_desc, output_fields = self.parse_segment_io_descriptor()
                segment['outputs'].append(output_desc)
                fields[f'output_{i}'] = output_fields

            segment['page_size'] = self.read_field('page_size', 'I', fields)
            segment['page_count'] = self.read_field('page_count', 'I', fields)
            if segment['page_count'] > 0:
                segment['page_idx'] = self.read_field('page_idx',
                    'I' * segment['page_count'], fields)
            else:
                segment['page_idx'] = []

            segment['cnn_num_mapped_regions'] = self.read_field('cnn_num_mapped_regions', 'I', fields)
            segment['cnn_mapped_region_buffer_id'] = self.read_field('cnn_mapped_region_buffer_id',
                'I' * segment['cnn_num_mapped_regions'], fields)

            if self.version >= VHA_MBS_VERSION_CMD_STREAM_PARTITIONS_ADDED: #TODO
                segment['partitions_count'] = self.read_field('partitions_count', 'I', fields)
                in_buf_size = segment['partitions_count']
                segment['partition_offset'] = self.read_field('partition_offset',
                    'I' * in_buf_size, fields)
                segment['partition_size'] = self.read_field('partition_size',
                    'I' * in_buf_size, fields)
                if (self.version == VHA_MBS_VERSION_VDSP_CMD_STREAM_PARTITIONS_ADDED
                    or VHA_MBS_VERSION_CMD_STREAM_PARTITIONS_ADDED or self.HAS_VDSP):
                    segment['partition_type'] = self.read_field('partition_type',
                        'I' * in_buf_size, fields)


            # segment['shared_circule_buffer_offset'] = self.read_field('shared_circule_buffer_offset', 'I', fields)
            # segment['num_cores'] = self.read_field('num_cores', 'I', fields)

            # FOR CNN segment
            segment['cnn_command_stream_size'] = self.read_field('cnn_command_stream_size', 'I', fields)
            segment['cnn_command_stream_id'] = self.read_field('cnn_command_stream_id', 'I', fields)
            segment['cnn_command_stream_id'] = segment['cnn_command_stream_id'] * segment['cnn_command_stream_size']

            cnn_stream_offset = self.index
            segment['cnn_command_stream'] = self.read_binary_block(
                'I' * segment['cnn_command_stream_size'])
            fields['cnn_command_stream'] = {
                'offset': cnn_stream_offset,
                'size': struct.calcsize('I' * segment['cnn_command_stream_size']),
                'value': '<binary>',
                'format': f'I * {segment["cnn_command_stream_size"]}',
            }

        return segment, fields



#解析segmments的信息
    def parse_segment_section_part(self):
        segment = {}
        fields = {}
        segment['num_segments'] = self.read_field('num_segments', 'I', fields)
        for ns in range(segment['num_segments']):
            segment['segment_id'] = self.read_field('segment_id', 'I', fields)
            segment_flag = self.read_field('segment_flag', 'H', fields)
            segment_type = self.read_field('segment_type', 'H', fields)
            segment['segment_type'] = SegmentType(segment_type)
            segment['segment_flag'] = SegmentFlag(segment_flag)
            segment['segment_estimated_cycles'] = self.read_field('segment_estimated_cycles', 'I', fields)
            segment['inputs_count'] = self.read_field('inputs_count', 'I', fields)
            segment['inputs'] = []
            for i in range(segment['inputs_count']):
                input_desc, input_fields = self.parse_segment_io_descriptor()
                segment['inputs'].append(input_desc)
                fields[f'input_{i}'] = input_fields
            segment['outputs_count'] = self.read_field('outputs_count', 'I', fields)
            segment['outputs'] = []
            for i in range(segment['outputs_count']):
                output_desc, output_fields = self.parse_segment_io_descriptor()
                segment['outputs'].append(output_desc)
                fields[f'output_{i}'] = output_fields

            segment['page_size'] = self.read_field('page_size', 'I', fields)
            segment['page_count'] = self.read_field('page_count', 'I', fields)
            if segment['page_count'] > 0:
                segment['page_idx'] = self.read_field('page_idx',
                    'I' * segment['page_count'], fields)
            else:
                segment['page_idx'] = []

            segment['cnn_num_mapped_regions'] = self.read_field('cnn_num_mapped_regions', 'I', fields)
            segment['cnn_mapped_region_buffer_id'] = self.read_field('cnn_mapped_region_buffer_id',
                'I' * segment['cnn_num_mapped_regions'], fields)

            segment['partitions_count'] = self.read_field('partitions_count', 'I', fields)
            in_buf_size = segment['partitions_count']
            segment['partition_offset'] = self.read_field('partition_offset','I' * in_buf_size, fields)
            segment['partition_size'] = self.read_field('partition_size','I' * in_buf_size, fields)
            # segment['partition_type'] = self.read_field('partition_type','I' * in_buf_size, fields)

            # segment['shared_circule_buffer_offset'] = self.read_field('shared_circule_buffer_offset', 'I', fields)
            # segment['num_cores'] = self.read_field('num_cores', 'I', fields)

            # FOR CNN segment
            segment['cnn_command_stream_size'] = self.read_field('cnn_command_stream_size', 'I', fields)
            segment['cnn_command_stream_id'] = self.read_field('cnn_command_stream_id', 'I', fields)
            segment['cnn_command_stream_id'] = segment['cnn_command_stream_id'] * segment['cnn_command_stream_size']

            cnn_stream_offset = self.index
            segment['cnn_command_stream'] = self.read_binary_block(
                'I' * segment['cnn_command_stream_size'])
            fields['cnn_command_stream'] = {
                'offset': cnn_stream_offset,
                'size': struct.calcsize('I' * segment['cnn_command_stream_size']),
                'value': '<binary>',
                'format': f'I * {segment["cnn_command_stream_size"]}',
            }

        return segment, fields


    #解析权重的数据
    def parse_coefficients_section(self):
        coefficients = {}
        fields = {}
        coefficients['coefficients_size'] = self.read_field('coefficients_size', 'I', fields)
        coeff_data_offset = self.index
        coefficients['coefficients_data'] = self.read_binary_block(
            'I' * coefficients['coefficients_size'])
        fields['coefficients_data'] = {
            'offset': coeff_data_offset,
            'size': struct.calcsize('I' * coefficients['coefficients_size']),
            'value': '<binary>',
            'format': f'I * {coefficients["coefficients_size"]}',
        }
        if self.version == VHA_MBS_VERSION_DYNAMIC_SHARE_WEIGHT and self.shape_index == 0:
            coefficients['shared_coefficients_size'] = self.read_field(
                'shared_coefficients_size', 'I', fields)
            shared_data_offset = self.index
            coefficients['shared_coefficients_data'] = self.read_binary_block(
                'I' * coefficients['shared_coefficients_size'])
            fields['shared_coefficients_data'] = {
                'offset': shared_data_offset,
                'size': struct.calcsize('I' * coefficients['shared_coefficients_size']),
                'value': '<binary>',
                'format': f'I * {coefficients["shared_coefficients_size"]}',
            }
        return coefficients, fields


    #解析VDSP权重的数据
    def parse_VDSP_coefficients_section(self):
        coefficients = {}
        fields = {}
        coefficients['coefficients_size'] = self.read_field('coefficients_size', 'I', fields)
        coeff_data_offset = self.index
        coefficients['coefficients_data'] = self.read_binary_block(
            'I' * coefficients['coefficients_size'])
        fields['coefficients_data'] = {
            'offset': coeff_data_offset,
            'size': struct.calcsize('I' * coefficients['coefficients_size']),
            'value': '<binary>',
            'format': f'I * {coefficients["coefficients_size"]}',
        }
        return coefficients, fields


    #解析VDSP算子参数
    def parse_VDSP_OP_param_section(self):
        op_param = {}
        fields = {}
        fields['vdsp_op_block_start'] = {'offset': self.index}
        op_param['vdsp_op_count'] = self.read('I')
        op_param['vdsp_op_list'] = []
        for i in range(op_param['vdsp_op_count']):
            op_param['vdsp_op_list'].append(self.read('I'))
        op_param_size_index = self.index
        op_param['op_param_size'] = self.read('I')
        fields['op_param_size'] = {'offset': op_param_size_index,'size': struct.calcsize('I'),'value': op_param['op_param_size'],'format': f'I'}
        op_param['op_param_data'] = self.read_binary_block('I' * op_param['op_param_size'])
        fields['vdsp_op_block_end'] = {'offset': self.index}
        return op_param, fields


    #解析blobs的信息
    def parse_general_blobs_section(self):
        blobs = {}
        blobs['blob_size'] = self.read('I')
        blobs['blob_buffer_id'] = self.read('I')
        if blobs['blob_size'] > 0:
            blobs['data'] = self.data[self.index:self.index + blobs['blob_size']]
            self.index += blobs['blob_size']
            # 检查对齐情况  对齐到32
            remaining = (4 - (blobs['blob_size'] % 4)) % 4
            if remaining > 0:
                # 跳过填充的字节
                self.index += remaining
        else:
            blobs['data'] = b''
        return blobs


    #extension block 的数据
    def parse_extension_section(self):
        extension = {}
        fields = {}
        extension['magic'] = self.read_field('magic', 'I', fields)
        if extension['magic'] != EXTENSION_MAGIC_EXPECTED:
            raise ValueError("Invalid extension magic value")
        extension['extension_count'] = self.read_field('extension_count', 'I', fields)
        for i in range(extension['extension_count']):
            sub_extension = {}
            word = self.read_field(f'extension_{i}_word', 'I', fields)
            sub_extension['block_size'] = (word >> 8) & 0x00FFFFFF  # 高24位
            sub_extension['block_type'] = word & 0x000000FF      # 低8位

            if sub_extension['block_size'] > 0:
                data_offset = self.index
                sub_extension['data_data'] = self.data[self.index:self.index
                    + sub_extension['block_size']]
                self.index += sub_extension['block_size']
                fields[f'extension_{i}_data'] = {
                    'offset': data_offset,
                    'size': sub_extension['block_size'],
                    'value': '<binary>',
                    'format': f'{sub_extension["block_size"]}s',
                }
                # 检查对齐情况  对齐到32
                remaining = (4 - (sub_extension['block_size'] % 4)) % 4
                if remaining > 0:
                    self.index += remaining
            else:
                sub_extension['data_data'] = b''
            extension[f"extension_{i}"] = sub_extension

        return extension, fields

    # 解析 brns 信息
    def parse_brns_section(self):
        brns = {}
        brns['count'] = self.read('I')
        brns['values'] = list(self.read('I' * brns['count']))
        return brns

    # 完整解析 MBS，返回 (output_text, results_list)
    def parse(self, show_field_info=False):
        buf = io.StringIO()
        results = []

        mbs_count = count_mbs(bytes(self.data))
        print(f"检测到 {mbs_count} 个 MBS", file=buf)

        for shape_index in range(mbs_count):
            result = {}
            self.shape_index = shape_index

            result['header'], header_fields = self.parse_header()
            result['header_fields'] = header_fields
            print("\nHeader:", file=buf)
            for name, info in header_fields.items():
                print(fmt_field(name, info, show_field_info, "    "), file=buf)

            # 解析模型的输入输出信息
            result['network_io'], network_io_fields = self.parse_network_io()
            result['network_io_fields'] = network_io_fields
            print(f"\nInputs Count: {result['network_io']['inputs_count']}", file=buf)
            for ic, desc in enumerate(result['network_io']['inputs']):
                print(f"\nInput Descriptor {ic}:", file=buf)
                print_io_fields(network_io_fields[f'input_{ic}'], desc, show_field_info, file=buf)
            for oc, desc in enumerate(result['network_io']['outputs']):
                print(f"\nOutput Descriptor {oc}:", file=buf)
                print_io_fields(network_io_fields[f'output_{oc}'], desc, show_field_info, file=buf)

            result['brns'] = self.parse_brns_section()
            print(f"\nbrns Count: {result['brns']['count']}", file=buf)
            print(f"brns : {result['brns']['values']}", file=buf)

            print("\nBuffer info:", file=buf)
            result['buffer'], buffer_fields = self.parse_buffer_section()
            result['buffer_fields'] = buffer_fields
            print_buffer_fields(result['buffer'], buffer_fields, show_field_info, file=buf)

            result['segments'], segment_fields = self.parse_segment_section()
            result['segment_fields'] = segment_fields
            print("\nSegments:", file=buf)
            print_segment_fields(result['segments'], segment_fields, show_field_info, file=buf)

            result['coeff'], coeff_fields = self.parse_coefficients_section()
            result['coeff_fields'] = coeff_fields
            print("\nCoefficients:", file=buf)
            for name, info in coeff_fields.items():
                print(fmt_field(name, info, show_field_info, "    "), file=buf)

            header = result['header']
            if header['version'] == VHA_MBS_VERSION_VDSP_CMD_STREAM_PARTITIONS_ADDED or \
                    (header['version'] == VHA_MBS_VERSION_DYNAMIC_SHARE_WEIGHT and header['dynamic'].HAS_VDSP):
                result['vdsp_coeff'], vdsp_coeff_fields = self.parse_VDSP_coefficients_section()
                result['vdsp_coeff_fields'] = vdsp_coeff_fields
                print("\nVDSP Coefficients:", file=buf)
                for name, info in vdsp_coeff_fields.items():
                    print(fmt_field(name, info, show_field_info, "    "), file=buf)

                result['vdsp_op_params'],result['vdsp_op_params_fields'] = self.parse_VDSP_OP_param_section()
                print("vdsp_op_count:", result['vdsp_op_params']['vdsp_op_count'], file=buf)
                print("vdsp_op_list:", result['vdsp_op_params']['vdsp_op_list'], file=buf)
                print("op_param_size:", result['vdsp_op_params']['op_param_size'], file=buf)

            result['extension'], result['extension_fields'] = self.parse_extension_section()
            results.append(result)

        return buf.getvalue(), results



def print_io_fields(fields, desc, show_field_info, file=None):
    """打印 IO 描述符的字段信息，以及 Memory Format 和 Buffer Flags 详情"""
    for name, info in fields.items():
        print(fmt_field(name, info, show_field_info, "    "), file=file)
    print(f"    Memory Format:", file=file)
    print(f"      Zero Point: {desc['memory_format'].ZERO_POINT}", file=file)
    print(f"      Is Q8A: {desc['memory_format'].IS_Q8A}", file=file)
    print(f"      Is Float: {desc['memory_format'].IS_FLOAT}", file=file)
    print(f"      Is Signed: {desc['memory_format'].IS_SIGNED}", file=file)
    print(f"      Exponent: {desc['memory_format'].EXPONENT}", file=file)
    print(f"      Plane Pack: {desc['memory_format'].PLANE_PACK}", file=file)
    print(f"      Bitdepth: {desc['memory_format'].BITDEPTH}", file=file)
    if desc['format_scale'] is not None:
        print(f"    Format Scale: {desc['format_scale']}", file=file)
    print(f"    Buffer Flags:", file=file)
    print(f"      Burst: {desc['buffer_flags_obj'].BURST}", file=file)
    print(f"      Alignment: {desc['buffer_flags_obj'].ALIGNMENT}", file=file)
    print(f"      Order: {desc['buffer_flags_obj'].ORDER}", file=file)


def print_segment_io_fields(fields, desc, show_field_info, file=None, indent="    "):
    """打印 Segment IO 描述符的字段信息"""
    for name, info in fields.items():
        print(fmt_field(name, info, show_field_info, indent), file=file)
    print(f"{indent}Memory Format:", file=file)
    print(f"{indent}  Zero Point: {desc['memory_format'].ZERO_POINT}", file=file)
    print(f"{indent}  Is Q8A: {desc['memory_format'].IS_Q8A}", file=file)
    print(f"{indent}  Is Float: {desc['memory_format'].IS_FLOAT}", file=file)
    print(f"{indent}  Is Signed: {desc['memory_format'].IS_SIGNED}", file=file)
    print(f"{indent}  Exponent: {desc['memory_format'].EXPONENT}", file=file)
    print(f"{indent}  Plane Pack: {desc['memory_format'].PLANE_PACK}", file=file)
    print(f"{indent}  Bitdepth: {desc['memory_format'].BITDEPTH}", file=file)
    if desc['format_scale'] is not None:
        print(f"{indent}Format Scale: {desc['format_scale']}", file=file)


def print_buffer_fields(buffer, fields, show_field_info, file=None):
    """打印 Buffer 字段信息"""
    print(fmt_field('num_buffers', fields['num_buffers'], show_field_info, "    "), file=file)
    for i in range(buffer['num_buffers']):
        bt = fields[f'buffer_type_{i}']
        bs = fields[f'buffer_size_{i}']
        print(fmt_field(f'buffer_type_{i+1}', bt, show_field_info, "    ")
              + f" ({get_buffer_type_name(bt['value'])})", file=file)
        print(fmt_field(f'buffer_size_{i+1}', bs, show_field_info, "    "), file=file)


def print_segment_fields(segment, fields, show_field_info, file=None):
    """打印 Segment 字段信息"""
    # 顶层字段
    top_keys = ['num_segments', 'segment_id', 'segment_flag', 'segment_type',
                'segment_estimated_cycles', 'inputs_count', 'outputs_count',
                'page_size', 'page_count', 'cnn_num_mapped_regions',
                'cnn_command_stream_size', 'cnn_command_stream_id']
    for key in top_keys:
        if key in fields:
            print(fmt_field(key, fields[key], show_field_info, "    "), file=file)

    # page_idx
    if 'page_idx' in fields:
        print(fmt_field('page_idx', fields['page_idx'], show_field_info, "    "), file=file)

    # cnn_mapped_region_buffer_id
    if 'cnn_mapped_region_buffer_id' in fields:
        print(fmt_field('cnn_mapped_region_buffer_id',
              fields['cnn_mapped_region_buffer_id'], show_field_info, "    "), file=file)

    # partitions
    for pkey in ['partitions_count', 'partition_offset', 'partition_size', 'partition_type']:
        if pkey in fields:
            print(fmt_field(pkey, fields[pkey], show_field_info, "    "), file=file)

    # cnn_command_stream
    if 'cnn_command_stream' in fields:
        print(fmt_field('cnn_command_stream', fields['cnn_command_stream'], show_field_info, "    "), file=file)

    # 输入 descriptors
    for i in range(segment['inputs_count']):
        print(f"\n    Input {i}:", file=file)
        if f'input_{i}' in fields:
            print_segment_io_fields(fields[f'input_{i}'], segment['inputs'][i], show_field_info, file=file, indent="        ")

    # 输出 descriptors
    for i in range(segment['outputs_count']):
        print(f"\n    Output {i}:", file=file)
        if f'output_{i}' in fields:
            print_segment_io_fields(fields[f'output_{i}'], segment['outputs'][i], show_field_info, file=file, indent="        ")


def count_mbs(data):
    """预扫描 MBS 文件，通过统计 magic number 出现次数来确定 MBS 个数"""
    import struct
    magic = 0x42beef42
    magic_bytes = struct.pack('I', magic)
    count = 0
    offset = 0
    while True:
        pos = data.find(magic_bytes, offset)
        if pos == -1:
            break
        count += 1
        offset = pos + 1
    return count



#TODO 支持小于15的版本         暂无需求
#TODO 支持software segments   暂无需求
#TODO hardware segment + soft segments   暂无需求
#TODO 多核   暂无需求

