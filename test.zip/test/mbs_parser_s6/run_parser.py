import os
import argparse

from mbs_parser import MBSParser
from vdsp_op_param_parser import *


def main(args, show_field_info=False):
    with open(args.mbs_path, 'rb') as file:
        data = file.read()

    result_path = os.path.join(os.path.dirname(args.mbs_path), "parse_result")
    if not os.path.exists(result_path):
        os.mkdir(result_path)

    parser = MBSParser(data)
    output_text, results = parser.parse(show_field_info=show_field_info)

    # 将解析输出保存到 parser.txt
    parser_txt_path = os.path.join(result_path, "parser.txt")
    with open(parser_txt_path, "w", encoding="utf-8") as f:
        f.write(output_text)
    print(f"解析结果已保存到: {parser_txt_path}")

    # 同时打印到控制台
    print(output_text)

    # 保存二进制文件
    for shape_index, result in enumerate(results):
        segments = result['segments']
        with open(os.path.join(result_path, f"command_stream_segid_{segments['segment_id']}_{shape_index}.bin"), "wb") as f:
            f.write(segments['cnn_command_stream'])

        coeff = result['coeff']
        if coeff['coefficients_size'] != 0:
            with open(os.path.join(result_path, f"npu_coefficients_{shape_index}.bin"), "wb") as f:
                f.write(coeff['coefficients_data'])
        if 'shared_coefficients_data' in coeff:
            with open(os.path.join(result_path, f"npu_shared_coefficients_{shape_index}.bin"), "wb") as f:
                f.write(coeff['shared_coefficients_data'])

        if 'vdsp_coeff' in result:
            with open(os.path.join(result_path, f"vdsp_coefficients_{shape_index}.bin"), "wb") as f:
                f.write(result['vdsp_coeff']['coefficients_data'])

            vdsp_op_params = result['vdsp_op_params']
            with open(os.path.join(result_path, f"vdsp_op_list_{shape_index}.txt"), "w") as f:
                f.write(' '.join(map(str, vdsp_op_params['vdsp_op_list'])))
            with open(os.path.join(result_path, f"op_param_data_{shape_index}.bin"), "wb") as f:
                f.write(vdsp_op_params['op_param_data'])

    if 'vdsp_op_params' in result:
        parse_op_parms(os.path.join(result_path, "vdsp_op_list_0.txt"),
                    os.path.join(result_path, "op_param_data_0.bin"),
                    result_path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='parse mbs')
    parser.add_argument('--mbs_path', type=str,
                        default="parse_case/FA_1104_GQA_1/QK_Matmul.mbs.bin", help='mbs_file_path')
    parser.add_argument('--show_field_info', action='store_true', default=False,
                        help='显示字段的 offset 和 size 信息')
    args = parser.parse_args()
    print(args)
    main(args, show_field_info=args.show_field_info)