"""
FA_test (n03) 用例: 把 fusion_cmd.bin 中 6 个子算子 CMD 合并进 mbs.bin 并修改 op_param。

与 fa_mbs.py 功能相同, 仅 CMD 来源不同 (本用例来自 fusion_header.bin/fusion_cmd.bin,
按 compiled_results.json 的 offset 列表切分)。公共流程见 fa_common.py 模块 docstring:
    1 提取 CMD -> 2 对齐拼接 -> 3 替换 CMD -> 4 reg_map -> 5 写 op_param -> 6 保存
"""
import os
import json
import struct

from fa_common import (ALIGNMENT, concat_bytes_with_align, print_concat_table,
                       get_cmd_buffer_id, replace_cmd, write_cmd_info_to_op_param,
                       add_buffer_to_reg_map)
from mbs_parser import MBSParser
from mbs_types import get_buffer_type_name


# ==================== 配置 ====================
CASE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "parse_case", "FA_test")

MBS_FILE = "mbs.bin"


# mbs.bin 中各分片的物理顺序与文件名
#   注意: 物理顺序是 npu_coeff -> vdsp_coeff -> vdsp_cmd
PART_FILES = [
    "header.bin",      # mbs header 部分
    "npu_cmd.bin",     # NPU CMD 部分
    "npu_coeff.bin",   # NPU coeff 部分
    "vdsp_coeff.bin",  # VDSP coeff 部分
    "vdsp_cmd.bin",    # VDSP CMD / op_param 部分
]

EXTENSION_MAGIC_EXPECTED = 0xAB12D34

# ==================== FA 融合算子配置 ====================
COMPILED_RESULTS = "compiled_results.json"

# fusion_header.bin / fusion_cmd.bin 中 6 个子算子的原始排列顺序 (按 index 0..5)
#   index 0: qk_0_mmm, 1: qk_1_mmm, 2: qkv_0_mmm, 3: qkv_1_mmm,
#   index 4: qk_matmul, 5: qkv_matmul
FUSION_OP_NAMES = ["qk_0_mmm", "qk_1_mmm", "qkv_0_mmm", "qkv_1_mmm",
                   "qk_matmul", "qkv_matmul"]

# 拼接到 npu_cmd.bin 后面的子算子 CMD 顺序
#   npu_cmd(主FA) + qk_matmul + qk_0_mmm + qk_1_mmm + qkv_matmul + qkv_0_mmm + qkv_1_mmm
# 这与 fa_mbs.py 的 OP_PARAM_SLOT_FROM_CHUNK = {1:0, 2:1, 3:2, 4:4, 5:5, 6:6} 对应:
#   chunk[0]=npu_cmd(主FA, 不映射 slot)
#   chunk[1]=qk_matmul -> slot0, chunk[2]=qk_0_mmm -> slot1, chunk[3]=qk_1_mmm -> slot2
#   chunk[4]=qkv_matmul -> slot4, chunk[5]=qkv_0_mmm -> slot5, chunk[6]=qkv_1_mmm -> slot6
FUSION_MERGE_ORDER = ["qk_matmul", "qk_0_mmm", "qk_1_mmm",
                      "qkv_matmul", "qkv_0_mmm", "qkv_1_mmm"]


def read_bin(name):
    path = os.path.join(CASE_DIR, name)
    with open(path, "rb") as f:
        return f.read()



def load_fusion_offsets():
    """从 compiled_results.json 读取 fusion header / cmd 的 offset 列表与 SIZE。"""
    path = os.path.join(CASE_DIR, COMPILED_RESULTS)
    with open(path, "r", encoding="utf-8") as f:
        j = json.load(f)
    blk = j["rank1"]["cmd"]["path"][0]
    return {
        "header_offset": blk["VDSP_Fusion_OP_HEADER_OFFSET"],
        "header_size": blk["VDSP_Fusion_OP_HEADER_SIZE"],
        "cmd_offset": blk["VDSP_Fusion_OP_CMD_OFFSET"],
        "cmd_size": blk["VDSP_Fusion_OP_CMD_SIZE"],
    }


def extract_fusion_segments(data, offsets, name):
    """按 offset 列表把 data 切成 len(offsets) 段。

    Args:
        data (bytes): fusion_header.bin 或 fusion_cmd.bin 的完整内容。
        offsets (list[int]): 各段起始偏移列表 (已升序)。
        name (str): 用于打印的名称。
    Returns:
        list[bytes]: 切出的各段字节。
    """
    segs = []
    for i in range(len(offsets)):
        s = offsets[i]
        e = offsets[i + 1] if i + 1 < len(offsets) else len(data)
        segs.append(data[s:e])
    return segs


def verify_fusion_files():
    """提取并验证 fusion_header.bin / fusion_cmd.bin 的 6 个子算子分段。"""
    info = load_fusion_offsets()
    fusion_header = read_bin("fusion_header.bin")
    fusion_cmd = read_bin("fusion_cmd.bin")

    print("\n=== FA 融合算子分段 (fusion_header.bin / fusion_cmd.bin) ===")
    print(f"json 配置: header_size={info['header_size']} header_offset={info['header_offset']}")
    print(f"          cmd_size={info['cmd_size']} cmd_offset={info['cmd_offset']}")
    print(f"实际文件: fusion_header.bin={len(fusion_header)} 字节, "
          f"fusion_cmd.bin={len(fusion_cmd)} 字节")
    assert len(fusion_header) == info["header_size"], \
        f"fusion_header.bin 长度 {len(fusion_header)} != json {info['header_size']}"
    assert len(fusion_cmd) == info["cmd_size"], \
        f"fusion_cmd.bin 长度 {len(fusion_cmd)} != json {info['cmd_size']}"
    print("文件大小与 json 配置一致 OK")

    header_segs = extract_fusion_segments(fusion_header, info["header_offset"], "header")
    cmd_segs = extract_fusion_segments(fusion_cmd, info["cmd_offset"], "cmd")

    print(f"\n{'index':<6}{'name':<14}{'header off/size':<22}{'cmd off/size':<22}{'header first16'}")
    print("-" * 92)
    for i, op_name in enumerate(FUSION_OP_NAMES):
        hs = info["header_offset"][i]
        he = info["header_offset"][i + 1] if i + 1 < len(info["header_offset"]) else len(fusion_header)
        cs = info["cmd_offset"][i]
        ce = info["cmd_offset"][i + 1] if i + 1 < len(info["cmd_offset"]) else len(fusion_cmd)
        print(f"{i:<6}{op_name:<14}{f'{hs}/{he - hs}':<22}{f'{cs}/{ce - cs}':<22}"
              f"{header_segs[i][:16].hex()}")

    # 校验每个 header 段以 mbs magic 0x42beef42 开头 (fusion header 是子 MBS 的 header)
    print("\n各 header 段 magic 校验:")
    all_header_ok = True
    for i, op_name in enumerate(FUSION_OP_NAMES):
        magic = struct.unpack_from("<I", header_segs[i], 0)[0]
        ok = magic == 0x42beef42
        all_header_ok &= ok
        print(f"  header[{i}] {op_name:<14} magic={magic:#x} "
              f"{'OK' if ok else 'MISMATCH'}")

    return header_segs, cmd_segs


def parse_fusion_cmd_segments(cmd_segs):
    """解析 fusion_cmd 各子算子段的 segment 信息, 并提取纯 NPU CMD (cnn_command_stream)。

    每个 cmd_seg 是截断的子 MBS: 首部的 num_segments(4) 被裁掉, 剩余为
        segment_id / segment_flag / segment_type / estimated_cycles / segment IO
        / page / cnn_num_mapped_regions / reg_id[] / cnn_command_stream_size(w)
        / cnn_command_stream_id / cnn_command_stream(纯 CMD 字节)
    因此构造时在段首补 num_segments=1, 再调用 parse_segment_section, 解析结果
    offset 需统一 -4 以换回在 cmd_seg 内的偏移。

    Returns:
        (seg_infos, pure_cmds):
            seg_infos: list[dict], 每项为解析出的 segment 字段
                       (含 segment_id/flag/type/reg_map/cnn_command_stream_size 等)
            pure_cmds: list[bytes], 每项为该子算子真正的 cnn_command_stream (纯 CMD)
    """
    seg_infos, pure_cmds = [], []
    for i, seg in enumerate(cmd_segs):
        p = MBSParser(struct.pack("<I", 1) + seg)   # 段首补 num_segments=1
        p.index = 0
        seg_info, fields = p.parse_segment_section_part()
        cmd_stream = fields['cnn_command_stream']
        # offset 扣除补的 num_segments(4 字节), 换回段内绝对偏移
        cmd_off = cmd_stream['offset'] - 4
        cmd = bytes(seg[cmd_off:cmd_off + cmd_stream['size']])
        assert len(cmd) == seg_info['cnn_command_stream_size'] * 4, \
            f"CMD 提取长度自洽失败: {FUSION_OP_NAMES[i]}"
        seg_infos.append(seg_info)
        pure_cmds.append(cmd)
    return seg_infos, pure_cmds


def merge_fusion_cmd_to_npu_cmd(npu_cmd, cmd_segs):
    """把 fusion 各子算子 CMD 按指定顺序拼接到 npu_cmd 后面  只包含CMD, 不包含segment的信息
    顺序: npu_cmd(主FA) + qk_matmul + qk_0_mmm + qk_1_mmm
          + qkv_matmul + qkv_0_mmm + qkv_1_mmm
    每个 chunk 按 256 字节对齐拼接。

    先从每个 fusion cmd 段中解析出 segment 元数据, 并提取真正的
    cnn_command_stream (纯 CMD), 再对提纯后的 CMD 做对齐拼接。

    Returns:
        (merged_bytes, info_list, seg_infos)
    """
    # 1) 提取 fusion 各段的 segment 信息与纯 CMD (cnn_command_stream)
    seg_infos, pure_cmds = parse_fusion_cmd_segments(cmd_segs)
    name_to_cmd = {FUSION_OP_NAMES[i]: pure_cmds[i] for i in range(len(FUSION_OP_NAMES))}

    # 2) 打印提取出的 segment 信息 (子算子元数据)
    print("\n=== 提取 fusion 各段 segment 信息 ===")
    print(f"{'name':<14}{'flag':<14}{'type':<10}{'ins':>5}{'outs':>5}"
          f"{'regs':>6}{'reg_id':<16}{'cmd_size(word)':>14}")
    print("-" * 88)
    for i, op_name in enumerate(FUSION_OP_NAMES):
        si = seg_infos[i]
        print(f"{op_name:<14}{str(si['segment_flag']):<14}{str(si['segment_type']):<10}"
              f"{si['inputs_count']:>5}{si['outputs_count']:>5}"
              f"{si['cnn_num_mapped_regions']:>6}"
              f"{str(si['cnn_mapped_region_buffer_id']):<16}"
              f"{si['cnn_command_stream_size']:>14}")
    print("-" * 88)

    # 3) 纯 CMD 按 256 字节对齐拼接 (主FA + 6 个子算子)
    chunks = [npu_cmd]
    origins = ["npu_cmd(主FA)"]
    for op_name in FUSION_MERGE_ORDER:
        chunks.append(name_to_cmd[op_name])
        origins.append(op_name)

    merged, info_list = concat_bytes_with_align(chunks, ALIGNMENT)
    print_concat_table(origins, info_list, merged)
    return merged, info_list, seg_infos


def tune_op_param(param):
    """FA_test 用例特有的算子参数修改 (公共部分由 fa_common.write_cmd_info_to_op_param 完成)。"""
    addr = param.S_FLASH_ATTENTION_PARAM_ADDRESS
    addr.q_fm_shape.fm_h = 4
    addr.k_fm_shape.fm_h = 1
    addr.v_fm_shape.fm_h = 1
    addr.q_fm_tiling_shape.fm_h = 4
    addr.k_fm_tiling_shape.fm_h = 1
    addr.v_fm_tiling_shape.fm_h = 1
    addr.k_fm_shape.fm_w = 0
    addr.v_fm_shape.fm_w = 0
    addr.out_fm_shape.fm_h = 4
    addr.out_fm_shape_valid.fm_h = 4
    addr.enable_npu_matmul_encode = 1
    addr.softmax_valid_hidden_size = 0
    addr.contex_seq = 128
    addr.q_in_scale = 0.07874
    addr.k_in_scale = 0.03937
    addr.v_in_scale = 0.04724
    addr.qk_out_scale = 0.02320
    addr.exp_out_scale = 0.007870
    addr.qkv_out_scale = 0.02989
    addr.fa_output_scale = 0.00069
    addr.softmax_scale = 1


def parse_fusion_headers(header_segs):
    """解析并打印每个 fusion header 段的详细信息。

    每个 fusion header 段是一个截断的子 MBS header, 包含:
        magic / version / command_stream_flags / reserved_1 / hw_capabilities
        -> network_io (inputs / outputs 描述符: tensor / name / format / buffer_flags)
        -> brns
        -> buffer section (num_buffers + buffer_type/buffer_size 对)
        -> num_segments (=1)
    注意: segment 的实际内容 (segment_flag / cnn_command_stream 等) 不在 header 段中,
          而是放在 fusion_cmd.bin, 因此解析到 num_segments 为止。
    """
    print("\n" + "=" * 60)
    print("=== 解析每个 fusion header 段 ===")
    print("=" * 60)
    for i, (op_name, seg) in enumerate(zip(FUSION_OP_NAMES, header_segs)):
        print(f"\n----- fusion header[{i}] {op_name} (len={len(seg)} 字节) -----")
        p = MBSParser(seg)
        try:
            header, _ = p.parse_header()
            print(f"  magic                = {header['magic']:#x}")
            print(f"  version              = {header['version']:#x}")
            print(f"  command_stream_flags = {header['command_stream_flags']}")
            print(f"  reserved_1           = {header['reserved_1']:#x}")
            print(f"  hw_capabilities_lo   = {header['hw_capabilities_lo']:#x}")
            print(f"  hw_capabilities_hi   = {header['hw_capabilities_hi']:#x}")

            nio, _ = p.parse_network_io()
            print(f"  inputs_count  = {nio['inputs_count']}")
            for ic, desc in enumerate(nio['inputs']):
                nm = desc['name'].decode(errors='replace') if desc.get('name') else ''
                mf, bf = desc['memory_format'], desc['buffer_flags_obj']
                print(f"    input[{ic}]  name={nm!r}")
                print(f"              tensor={tuple(desc['tensor_value'])} size={desc['size']}")
                print(f"              format={desc['format']:#x} "
                      f"(zp={mf.ZERO_POINT} q8a={mf.IS_Q8A} float={mf.IS_FLOAT} "
                      f"signed={mf.IS_SIGNED} bitdepth={mf.BITDEPTH})")
                print(f"              buffer_flags={desc['buffer_flags']:#x} "
                      f"(burst={bf.BURST} align={bf.ALIGNMENT} order={bf.ORDER})")
                if desc['buffer_strides_value']:
                    print(f"              buffer_strides={tuple(desc['buffer_strides_value'])}")
            print(f"  outputs_count = {nio['outputs_count']}")
            for oc, desc in enumerate(nio['outputs']):
                nm = desc['name'].decode(errors='replace') if desc.get('name') else ''
                mf, bf = desc['memory_format'], desc['buffer_flags_obj']
                print(f"    output[{oc}] name={nm!r}")
                print(f"              tensor={tuple(desc['tensor_value'])} size={desc['size']}")
                print(f"              format={desc['format']:#x} "
                      f"(zp={mf.ZERO_POINT} q8a={mf.IS_Q8A} float={mf.IS_FLOAT} "
                      f"signed={mf.IS_SIGNED} bitdepth={mf.BITDEPTH})")
                print(f"              buffer_flags={desc['buffer_flags']:#x} "
                      f"(burst={bf.BURST} align={bf.ALIGNMENT} order={bf.ORDER})")
                if desc['buffer_strides_value']:
                    print(f"              buffer_strides={tuple(desc['buffer_strides_value'])}")

            brns = p.parse_brns_section()
            print(f"  brns  count={brns['count']} values={brns['values']}")

            buf, _ = p.parse_buffer_section()
            print(f"  num_buffers = {buf['num_buffers']}")
            for k in range(buf['num_buffers']):
                print(f"    buffer[{k}] type={get_buffer_type_name(buf['buffer_type'][k])} "
                      f"size={buf['buffer_size'][k]:#x}")

            # header 段到此 + num_segments(4) 结束, segment 实际内容在 fusion_cmd.bin
            if p.index + 4 <= len(seg):
                num_segments = struct.unpack_from("<I", seg, p.index)[0]
                print(f"  num_segments = {num_segments} "
                      f"(segment 内容在 fusion_cmd.bin, header 段不含)")
            print(f"  解析结束: idx={p.index}/{len(seg)}")
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"  [解析失败] idx={p.index}/{len(seg)}: {e}")


def get_cmd(mbs_data):
    parser = MBSParser(mbs_data)
    _text, results = parser.parse(show_field_info=False)
    npu_cmd = results[0]['segments']['cnn_command_stream']
    return npu_cmd



def main():
    # 1. 获取模型的CMD: 主 FA 的 npu_cmd + fusion_cmd.bin 中 6 个子算子 CMD
    origin_mbs = bytearray(read_bin("mbs.bin"))
    header_segs, cmd_segs = verify_fusion_files()
    # parse_fusion_headers(header_segs)  # 需要详细打印每个 fusion header 段时打开
    npu_cmd = get_cmd(origin_mbs)

    # 2. CMD 按 256 字节对齐拼接
    merged_cmd, matmul_cmd_info_list, seg_infos = merge_fusion_cmd_to_npu_cmd(npu_cmd, cmd_segs)

    # 3. 读取目标模型, 把合并后的 CMD 整体替换进去
    #    (同时更新 cnn_command_stream_size 与 COMMAND_STREAM buffer size)
    new_mbs = replace_cmd(origin_mbs, merged_cmd)

    # 4. 把 CMD buffer 加入 reg_map
    cmd_buffer_id = get_cmd_buffer_id(new_mbs)
    new_mbs = add_buffer_to_reg_map(new_mbs, [cmd_buffer_id])

    # 5. 写 op_param (传 buffer id, 内部换算为 reg_map index; 用例差异走 tune_op_param)
    new_mbs = write_cmd_info_to_op_param(new_mbs, matmul_cmd_info_list,
                                         cmd_buffer_id, tune=tune_op_param)

    # 6. 保存最终结果
    out_mbs = os.path.join(CASE_DIR, "new/mbs_new_final.bin")
    with open(out_mbs, "wb") as f:
        f.write(new_mbs)


if __name__ == "__main__":
    main()
