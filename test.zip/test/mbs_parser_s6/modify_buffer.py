"""
修改 MBS 文件中 buffer 段指定 buffer_id 的 buffer 大小。

MBS buffer 表结构: [num_buffers][type_0][size_0][type_1][size_1]...[type_{n-1}][size_{n-1}]
其中 buffer 表的下标从 0 开始，但 buffer_id 从 1 开始，即:
    buffer_id = 下标 + 1   (下标 = buffer_id - 1)

用法示例:
    python3 modify_buffer.py --mbs_path xxx.mbs.bin --buffer_id 2 --new_size 0x400000
    python3 modify_buffer.py --mbs_path xxx.mbs.bin --buffer_id 2 --new_size 4194304 --output out.bin

注意: 该脚本只修改 buffer 段的 buffer_size 字段本身。
若该 buffer 同时被 segment 的 input/output descriptor 或 reg_map 引用，
且需要保持一致，请同步修改对应的 buffer_size (可参考 mbs_modify.modify_output_buffer_size)。
"""

import argparse
import struct

from mbs_parser import MBSParser
from mbs_types import get_buffer_type_name


def parse(data):
    """重新解析 MBS 二进制数据，返回第一个结果 dict。"""
    _, results = MBSParser(data).parse(show_field_info=False)
    return results[0]


def modify_buffer_size(data, buffer_id, new_size):
    """
    修改 buffer 段中指定 buffer_id 的 buffer 大小。

    Args:
        data:     bytes 或 bytearray 形式的 MBS 数据
        buffer_id: 目标 buffer 的 id (从 1 开始计数)
        new_size:  新的 buffer 大小（字节）

    Returns:
        bytes: 修改后的 MBS 数据
    """
    data = bytearray(data)
    r = parse(data)
    buf = r['buffer']
    buf_fields = r['buffer_fields']

    # buffer_id 从 1 开始计数, 转成 buffer 表下标
    idx = buffer_id - 1
    assert 0 <= idx < buf['num_buffers'], \
        f"buffer_id {buffer_id} 无效, 有效范围 1~{buf['num_buffers']}"

    bs = buf_fields[f'buffer_size_{idx}']
    old = bs['value']
    struct.pack_into('<I', data, bs['offset'], new_size)
    print(f"[modify_buffer_size] buffer[{idx}] (id={buffer_id}) "
          f"type={get_buffer_type_name(buf['buffer_type'][idx])} "
          f"size: {old:#X} -> {new_size:#X} @ offset={bs['offset']}")
    return bytes(data)


def main(args):
    with open(args.mbs_path, 'rb') as f:
        data = f.read()

    new_data = modify_buffer_size(data, args.buffer_id, args.new_size)

    output = args.output or args.mbs_path
    with open(output, 'wb') as f:
        f.write(new_data)
    print(f"修改后的 MBS 已保存到: {output}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='修改 MBS 中指定 buffer_id 的 buffer 大小')
    parser.add_argument('--mbs_path', type=str, default="parse_case/moe/moe_1030_w50/mbs.bin", help='mbs 文件路径')
    parser.add_argument('--buffer_id', type=int, default=2,
                        help='目标 buffer 的 id (从 1 开始, 默认 2)')
    parser.add_argument('--new_size', type=lambda x: int(x, 0), default=118784,
                        help='新的 buffer 大小(字节), 支持 0x 前缀十六进制, 如 0x400000')
    parser.add_argument('--output', type=str, default="parse_case/moe/moe_1030_w50/mbs_1.bin",
                        help='输出文件路径 (默认覆盖原文件)')
    args = parser.parse_args()
    main(args)
