"""
公共结构体定义
=============
存放所有算子共用的基础结构体：算子类型枚举 OpType、feature map 形状、
transpose 顺序、requant 参数等。

算子的具体结构体定义和打印函数见 op_types.py，
解析函数见 op_param_parser.py。
"""
import ctypes
from enum import Enum


class OpType(Enum):
    OP_TYPE_RMSNORM = 0
    OP_TYPE_SOFTMAX = 1
    OP_TYPE_MATMUL = 2
    OP_TYPE_ELEMENTWISE_ALGEBRA = 3
    OP_TYPE_ROPE = 4
    OP_TYPE_COPY = 5
    OP_TYPE_LAYER_NORM = 6
    OP_TYPE_STD_SOFTMAX = 7
    OP_TYPE_STD_GROUP_NORM = 8
    OP_TYPE_STD_INSTANCE_NORM = 9
    OP_TYPE_FLASH_ATTENTION = 10
    OP_TYPE_GATHER_ELEMENTS = 11
    OP_TYPE_RSQRT = 12
    op_VDSP_QUANT = 13
    op_VDSP_DEQUANT = 14
    op_VDSP_MOE_ROUTING = 15
    OP_TYPE_MOE_FFN = 16


class FmShape(ctypes.Structure):
    _fields_ = [
        ('fm_n', ctypes.c_uint32),
        ('fm_h', ctypes.c_uint32),
        ('fm_w', ctypes.c_uint32),
        ('fm_c', ctypes.c_uint32)
    ]

class Transpose(ctypes.Structure):
    _fields_ = [
        ('order1', ctypes.c_uint8),
        ('order2', ctypes.c_uint8),
        ('order3', ctypes.c_uint8),
        ('order4', ctypes.c_uint8)
    ]

class TilingNum(ctypes.Structure):
    _fields_ = [
        ('h_num', ctypes.c_uint32),
        ('w_num', ctypes.c_uint32),
        ('ic_num', ctypes.c_uint32)
    ]

class WeightShape(ctypes.Structure):
    _fields_ = [
        ('wt_n', ctypes.c_uint32),
        ('wt_h', ctypes.c_uint32),
        ('wt_ci', ctypes.c_uint32),
        ('wt_co', ctypes.c_uint32)
    ]

class PaddingParam(ctypes.Structure):
    _fields_ = [
        ('padding_top', ctypes.c_uint32),
        ('padding_down', ctypes.c_uint32),
        ('padding_left', ctypes.c_uint32),
        ('padding_right', ctypes.c_uint32)
    ]

class ParallelNum(ctypes.Structure):
    _fields_ = [
        ('h_num', ctypes.c_uint32),
        ('w_num', ctypes.c_uint32),
        ('ic_num', ctypes.c_uint32),
        ('oc_num', ctypes.c_uint32)
    ]

class ReQuantParam(ctypes.Structure):
    _fields_ = [
        ('multipliter', ctypes.c_uint32),
        ('shift', ctypes.c_uint8),
        ('res', ctypes.c_uint8),
        ('exponent', ctypes.c_int16)
    ]

class ReQuantZpParam(ctypes.Structure):
    _fields_ = [
        ('zeropoint_in', ctypes.c_int16 * 4),
        ('zeropoint_out', ctypes.c_int16 *4),
        ('wt_zeropoint', ctypes.c_int16 *2)
    ]
