"""检查 PART_FILES 拼接后是否等于 parse_case/FA_test/mbs.bin"""
import os

BASE = "parse_case/FA_test"
MBS = os.path.join(BASE, "mbs.bin")

# 与 fa_mbs_n03.py PART_FILES 相同的物理顺序
PART_FILES = [
    "header.bin",      # mbs header 部分
    "npu_cmd.bin",     # NPU CMD 部分
    "npu_coeff.bin",   # NPU coeff 部分
    "vdsp_coeff.bin",  # VDSP coeff 部分
    "vdsp_cmd.bin",    # VDSP CMD / op_param 部分
]

with open(MBS, 'rb') as f:
    mbs = f.read()

parts = []
for name in PART_FILES:
    with open(os.path.join(BASE, name), 'rb') as f:
        parts.append(f.read())

merged = b''.join(parts)

print(f"mbs.bin 长度: {len(mbs)}")
print(f"分片长度: {[len(p) for p in parts]}, 拼接总长: {len(merged)}")
print(f"拼接 == mbs.bin: {merged == mbs}")

if merged != mbs:
    # 逐分片在 mbs.bin 中查找位置，看是否以其他顺序/偏移嵌在里面
    for name, part in zip(PART_FILES, parts):
        off = mbs.find(part)
        print(f"  {name:<16} len={len(part):>6}  在 mbs.bin 中 offset={off}")

    # 假设: mbs.bin = 5 个分片按序拼接 + 尾部 extension 区 (magic 0xAB12D34)
    print(f"\n前 {len(merged)} 字节 == 拼接结果: {mbs[:len(merged)] == merged}")
    tail = mbs[len(merged):]
    magic = int.from_bytes(tail[:4], 'little')
    print(f"尾部 extension: 长度={len(tail)} magic={magic:#X} "
          f"(期望 0x{0xAB12D34:X})")

    # coeff 分片只有 4 字节，find 命中 offset=5 可能只是数值巧合，逐位置对比
    print(f"npu_coeff.bin  = {parts[2].hex()}  mbs[1100:1104] = {mbs[1100:1104].hex()}")
    print(f"vdsp_coeff.bin = {parts[3].hex()}  mbs[1104:1108] = {mbs[1104:1108].hex()}")

# ==================== 解析 mbs.bin ====================
from mbs_parser import MBSParser

report, results = MBSParser(mbs).parse(show_field_info=False)
r = results[0]
seg, sf = r['segments'], r['segment_fields']
buf = r['buffer']

print("\n==================== mbs.bin 解析 ====================")
print(f"version: {r['header']['version']:#x}   输入 {r['network_io']['inputs_count']} 个 / "
      f"输出 {r['network_io']['outputs_count']} 个   buffer {buf['num_buffers']} 个")
print(f"segment: num_segments={seg['num_segments']} "
      f"cmd_size={seg['cnn_command_stream_size']} words "
      f"@ offset={sf['cnn_command_stream']['offset']}")
print(f"reg_map: num={seg['cnn_num_mapped_regions']} ids={seg['cnn_mapped_region_buffer_id']}")
print("buffers:")
from mbs_types import get_buffer_type_name
for i in range(buf['num_buffers']):
    print(f"  buffer_{i} type={get_buffer_type_name(buf['buffer_type'][i])} "
          f"size={buf['buffer_size'][i]:#X}")
print("\nVDSP: op_count={} op_param_size={} words".format(
    r['vdsp_op_params']['vdsp_op_count'], r['vdsp_op_params']['op_param_size']))
ext = r.get('extension', {})
print(f"extension: count={ext.get('extension_count')}")
# ==================== 按解析边界重新生成分片到 new/ ====================
NEW_DIR = os.path.join(BASE, "new")
os.makedirs(NEW_DIR, exist_ok=True)

r0 = results[0]
sf, cf = r0['segment_fields'], r0['coeff_fields']
vcf = r0['vdsp_coeff_fields']
opf = r0['vdsp_op_params_fields']

# 各分片边界 (与原始分片约定一致):
#   header.bin  = 0 ~ num_segments 字段末尾
#   npu_cmd.bin = segment 体 + 内联 CMD (到 cnn_command_stream 末尾)
#   npu_coeff.bin / vdsp_coeff.bin = [size(4)][data]
#   vdsp_cmd.bin = 整个 vdsp op_param 区段 (extension 之前)
bounds = {
    "header.bin":     (0, sf['num_segments']['offset'] + 4),
    "npu_cmd.bin":    (sf['num_segments']['offset'] + 4,
                       sf['cnn_command_stream']['offset'] + sf['cnn_command_stream']['size']),
    "npu_coeff.bin":  (cf['coefficients_size']['offset'],
                       cf['coefficients_data']['offset'] + cf['coefficients_data']['size']),
    "vdsp_coeff.bin": (vcf['coefficients_size']['offset'],
                       vcf['coefficients_data']['offset'] + vcf['coefficients_data']['size']),
    "vdsp_cmd.bin":   (opf['vdsp_op_block_start']['offset'], opf['vdsp_op_block_end']['offset']),
}

new_sizes = {}
for name, (start, end) in bounds.items():
    data = mbs[start:end]
    new_sizes[name] = len(data)
    with open(os.path.join(NEW_DIR, name), 'wb') as f:
        f.write(data)
    same = data == parts[PART_FILES.index(name)]
    print(f"new/{name:<16} [{start}, {end}) len={len(data):>5}  "
          f"与原分片一致: {same}")

# ==================== 更新 compiled_results.json (路径不变, 只改 SIZE) ====================
# 直接在原文本上做替换, 保持原始排版 (json.dump 会重排格式)
import re

with open(os.path.join(BASE, "compiled_results.json"), encoding='utf-8') as f:
    text = f.read()

size_map = {
    'TC_HEADER_SIZE': new_sizes['header.bin'],
    'TC_CMD_SIZE': new_sizes['npu_cmd.bin'],
    'VDSP_CMD_SIZE': new_sizes['vdsp_cmd.bin'],
    'TC_COEFF_SIZE': new_sizes['npu_coeff.bin'],
    'VDSP_COEFF_SIZE': new_sizes['vdsp_coeff.bin'],
}
for key, val in size_map.items():
    text, n = re.subn(rf'("{key}":\s*)\d+', rf'\g<1>{val}', text)
    assert n == 1, f"{key} 替换 {n} 次, 预期 1 次"

out_json = os.path.join(NEW_DIR, "compiled_results.json")
with open(out_json, 'w', encoding='utf-8') as f:
    f.write(text)
print(f"\n已写出 {out_json}")
print("SIZE 更新:", {k: v for k, v in size_map.items()})
