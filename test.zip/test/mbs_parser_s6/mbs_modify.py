"""
MBS 修改工具

提供若干函数，用于在解析完 MBS 二进制数据后，直接对二进制字节流进行修改，
常用于 debug 场景（例如存储中间结果、扩大输出 buffer 等）。

功能 1: 修改输出 buffer 大小
功能 2: 新增/扩大 temp buffer
功能 3: 新增 buffer 到 reg_map



设计约定:
  - 每个函数接受 bytes 或 bytearray，返回修改后的 bytes。
  - 每个函数内部会重新解析输入数据，保证 offset 总是最新的，
    因此多个函数可以按任意顺序连续调用，不会因插入/修改导致 offset 失效。

用法示例:
    from mbs_modify import modify_output_buffer_size, add_or_expand_temp_buffer, add_buffer_to_reg_map
    from mbs_parser import MBSParser

    data = open("xxx.bin", "rb").read()

    data = modify_output_buffer_size(data, new_size=4194304)
    data = add_or_expand_temp_buffer(data, size=3*1081344, new_buffer_id=10)
    data = add_buffer_to_reg_map(data, [10])     # 把 temp buffer 加入 reg_map
    open("out.bin", "wb").write(data)
"""

import struct
from mbs_parser import MBSParser

from mbs_types import BufferType, get_buffer_type_name



def _pack_u32(value):
    """无符号 32 位小端打包"""
    return struct.pack('<I', value)


def _u32(data, offset):
    """读取 offset 处的无符号 32 位小端整数"""
    return struct.unpack_from('<I', data, offset)[0]


def parse(data):
    """重新解析 MBS 二进制数据，返回第一个结果 dict (offset 基于当前 data 内容)。"""

    _, results = MBSParser(data).parse(show_field_info=False)
    return results[0]


def network_output_size_offset(data):
    """
    返回网络输出描述符中 size 字段的绝对偏移。

    mbs_parser 的 parse_network_io_descriptor 未记录网络 IO 的 size 字段 offset，
    因此这里按相同逻辑临时解析一次，定位第一个网络输出描述符的 size 字段。
    返回 None 表示没有网络输出。
    """
    from mbs_parser import MBSParser
    p = MBSParser(data)
    p.index = 0
    p.parse_header()
    inputs_count = p.read('I')
    for _ in range(inputs_count):
        p.parse_network_io_descriptor()
    outputs_count = p.read('I')
    if outputs_count == 0:
        return None
    return p.index  # 第一个输出描述符的 size 字段 offset


# ==================== 功能 1: 修改输出 buffer 大小 ====================
def modify_output_buffer_size(data, new_size):
    """
    修改输出 buffer 的大小，用于 debug 时扩大缓冲区以存储中间结果。

    同步修改 3 处：
      1. 网络输出描述符 (network_io.outputs[0]) 的 size 字段
      2. buffer 表中所有 NETWORK_OUTPUT 类型的 buffer_size
      3. segment 输出描述符 (segments.outputs[*]) 的 buffer_size

    Args:
        data: bytes 或 bytearray 形式的 MBS 数据
        new_size: 新的 buffer 大小（字节）

    Returns:
        bytes: 修改后的 MBS 数据
    """
    data = bytearray(data)
    r = parse(data)
    changed = []

    # 1. 网络输出描述符的 size 字段
    net_bs_offset = network_output_size_offset(data)
    if net_bs_offset is not None:
        old = _u32(data, net_bs_offset)
        struct.pack_into('<I', data, net_bs_offset, new_size)
        changed.append(('network_io.output[0].size', net_bs_offset, old, new_size))
        print(f"[modify_output_buffer_size] 网络输出 size: {old:#X} -> {new_size:#X} @ offset={net_bs_offset}")
    else:
        print("[modify_output_buffer_size] 未找到网络输出描述符, 跳过")

    # 2. buffer 表中所有 NETWORK_OUTPUT 类型的 buffer_size
    buf = r['buffer']
    buf_fields = r['buffer_fields']
    for i in range(buf['num_buffers']):
        if buf['buffer_type'][i] == BufferType.NETWORK_OUTPUT.value:
            bs = buf_fields[f'buffer_size_{i}']
            old = bs['value']
            struct.pack_into('<I', data, bs['offset'], new_size)
            changed.append((f'buffer[{i}].buffer_size', bs['offset'], old, new_size))
            print(f"[modify_output_buffer_size] buffer[{i}] ({get_buffer_type_name(buf['buffer_type'][i])}) "
                  f"size: {old:#X} -> {new_size:#X} @ offset={bs['offset']}")

    # 3. segment 输出描述符的 buffer_size
    seg = r['segments']
    for oi, output in enumerate(seg['outputs']):
        bs = r['segment_fields'][f'output_{oi}']['buffer_size']
        old = bs['value']
        struct.pack_into('<I', data, bs['offset'], new_size)
        changed.append((f'segment.output[{oi}].buffer_size', bs['offset'], old, new_size))
        print(f"[modify_output_buffer_size] segment.output[{oi}] buffer_id={output['buffer_id']} "
              f"size: {old:#X} -> {new_size:#X} @ offset={bs['offset']}")

    return bytes(data)


# 修改CMD buffer大小 ====================
def modify_cmd_buffer_size(data, new_size):
    """
    修改CMD buffer 的大小，用于CMD拼接的场景。
    Args:
        data: bytes 或 bytearray 形式的 MBS 数据
        new_size: 新的 buffer 大小（字节）
    Returns:
        bytes: 修改后的 MBS 数据
    """
    parse_result = parse(bytearray(data))
    # 2. buffer COMMAND_STREAM
    buf = parse_result['buffer']
    buf_fields = parse_result['buffer_fields']
    for i in range(buf['num_buffers']):
        if buf['buffer_type'][i] == BufferType.COMMAND_STREAM.value:
            bs = buf_fields[f'buffer_size_{i}']
            old = bs['value']
            struct.pack_into('<I', data, bs['offset'], new_size)
            print(f"[modify_output_buffer_size] buffer[{i}] ({get_buffer_type_name(buf['buffer_type'][i])}) "
                  f"size: {old:#X} -> {new_size:#X} @ offset={bs['offset']}")
    return bytes(data)


# 修改CMD buffer 大小
def modify_VDSP_CMD_buffer_size(data, new_size):
    """
    修改VDSP buffer 的大小,用于VDSP算子参数的场景
    Args:
        data: bytes 或 bytearray 形式的 MBS 数据
        new_size: 新的 buffer 大小（字节）
    Returns:
        bytes: 修改后的 MBS 数据
    """
    data = bytearray(data)
    parse_result = parse(data)
    # 2. buffer 表中所有 VDSP_OP_PARAMS
    buf = parse_result['buffer']
    buf_fields = parse_result['buffer_fields']
    for i in range(buf['num_buffers']):
        if buf['buffer_type'][i] == BufferType.VDSP_OP_PARAMS.value:
            bs = buf_fields[f'buffer_size_{i}']
            old = bs['value']
            struct.pack_into('<I', data, bs['offset'], new_size)
            print(f"[modify_output_buffer_size] buffer[{i}] ({get_buffer_type_name(buf['buffer_type'][i])}) "
                  f"size: {old:#X} -> {new_size:#X} @ offset={bs['offset']}")

    #同时需要修改op param部分的 size  和buffer size要匹配
    op_pram_size_fields = parse_result['vdsp_op_params_fields']['op_param_size']
    assert new_size % 4 == 0
    struct.pack_into('<I', data, op_pram_size_fields['offset'], new_size // 4)

    return bytes(data)


# ==================== 功能 2: 新增/扩大 temp buffer ====================
def add_or_expand_temp_buffer(data, size, new_buffer_id=None):
    """
    在 buffer 表中新增一个 TEMPORARY buffer；若已有 TEMPORARY buffer 则直接扩大其大小。
    Args:
        data: bytes 或 bytearray 形式的 MBS 数据
        size: temp buffer 的新大小（字节）
        new_buffer_id: 新增 buffer 的 buffer id（建议取值 > 现有最大 buffer id，
                       避免与已有 buffer 冲突）。若省略则由函数自动分配
                       （= 当前 buffer 个数）。

    Returns:
        bytes: 修改后的 MBS 数据。buffer id 通过 print 输出，或由调用方自行推算
               （新增时为原 buffer 个数）。
    """
    data = bytearray(data)
    r = parse(data)
    buf = r['buffer']
    buf_fields = r['buffer_fields']
    num_buffers = buf['num_buffers']

    # 已有 temp buffer 的下标（可能多个）
    tmp_idx = [i for i in range(num_buffers)
               if buf['buffer_type'][i] == BufferType.TEMPORARY.value]

    if tmp_idx:
        # 已有 temp buffer：直接扩大，不新增
        idx = tmp_idx[0]
        bs = buf_fields[f'buffer_size_{idx}']
        old = bs['value']
        struct.pack_into('<I', data, bs['offset'], size)
        print(f"[add_or_expand_temp_buffer] 已有 TEMPORARY buffer[{idx}], "
              f"size: {old:#X} -> {size:#X} @ offset={bs['offset']}")
        return bytes(data),tmp_idx

    new_buffer_id = num_buffers + 1  # 自动分配 > 现有最大下标
    payload = _pack_u32(BufferType.TEMPORARY.value) + _pack_u32(size)

    # buffer 表结构: [num_buffers][type_0][size_0]...[type_n-1][size_n-1]
    # 新 buffer 追加在现有 buffer 表末尾（此处紧邻 segment 区段开始）
    insert_off = buf_fields['num_buffers']['offset'] + 4 + num_buffers * 2 * 4
    old_len = len(data)
    data[insert_off:insert_off] = payload
    # 同步递增 buffer 个数计数（否则后续 segment 区段解析会错位）
    cnt_field = buf_fields['num_buffers']
    struct.pack_into('<I', data, cnt_field['offset'], num_buffers + 1)
    new_len = len(data)
    print(f"[add_or_expand_temp_buffer] 新增 TEMPORARY buffer_id={new_buffer_id}, size={size:#X} "
          f"@ offset={insert_off} (buffer 个数 {num_buffers} -> {num_buffers + 1}, "
          f"文件长度 {old_len} -> {new_len})")
    return bytes(data), new_buffer_id


# ==================== 功能 3: 新增 buffer 到 reg_map ====================
def add_buffer_to_reg_map(data, buffer_ids):
    """
    将一个新 buffer（或多个 buffer）的 id 追加到 segment 的
    cnn_mapped_region_buffer_id 列表中，同时 cnn_num_mapped_regions 相应增加。

    Args:
        data: bytes 或 bytearray 形式的 MBS 数据
        buffer_ids: 需要加入 reg_map 的 buffer id  ,这里的buffer id 是 buffer 表中的 buffer id

    只追加 reg_map 中尚不存在的 buffer id,已映射过的会被跳过。
    """
    data = bytearray(data)
    r = parse(data)
    seg_fields = r['segment_fields']

    reg_cnt_field = seg_fields['cnn_num_mapped_regions']
    old_cnt = reg_cnt_field['value']

    # reg_map 中已有的 buffer id (parser 在个数为 1 时返回单个 int, >1 时返回 tuple, 0 时为空 tuple)
    ids_field = seg_fields['cnn_mapped_region_buffer_id']
    val = ids_field['value']
    if old_cnt == 0:
        existing = []
    elif isinstance(val, tuple):
        existing = list(val)
    else:
        existing = [val]

    # 过滤: 只保留 reg_map 中不存在且自身不重复的 buffer id
    to_add = []
    for bid in buffer_ids:
        if bid in existing:
            continue
        if bid not in to_add:
            to_add.append(bid)
    skipped = [bid for bid in buffer_ids if bid in existing]
    if skipped:
        print(f"[add_buffer_to_reg_map] buffer_id={skipped} 已存在于 reg_map, 跳过")
    if not to_add:
        print(f"[add_buffer_to_reg_map] 无需新增, reg_map 保持 {old_cnt} 项")
        return bytes(data)

    new_cnt = old_cnt + len(to_add)

    # 1. 修改 cnn_num_mapped_regions  增加 len(to_add) 个 buffer
    struct.pack_into('<I', data, reg_cnt_field['offset'], new_cnt)
    print(f"[add_buffer_to_reg_map] cnn_num_mapped_regions: {old_cnt} -> {new_cnt} "
          f"@ offset={reg_cnt_field['offset']}")

    # 2. 在现有 cnn_mapped_region_buffer_id 数组末尾追加 to_add
    insert_off = ids_field['offset'] + ids_field['size']
    payload = b''.join(_pack_u32(bid) for bid in to_add)
    old_len = len(data)
    data[insert_off:insert_off] = payload
    new_len = len(data)
    print(f"[add_buffer_to_reg_map] 追加 buffer_id={to_add} 到 reg_map "
          f"@ offset={insert_off} (文件长度 {old_len} -> {new_len})")
    return bytes(data)
