import numpy as np
import math


# BASE_DIR = "model/expert_w50a5"   # 保存新模型的目录
# EXPERT_COMPUTE_COUNT = 2         #专家计算的个数
# USE_EXPERT = True

# # 模型参数
# # w50a5
# TOKEN_DIMS = 3072
# HIDDEN_DIMS = 320
# N_DIMS       = 3072             # 每 token 特征维度
# NUM_EXPERTS  = 116              # 专家的个数
# TOP_K        = 8                # 每个 token 被路由到的专家数
# NPU_MAX_TOKEN_COUNT = 72
# TOKEN_COUNT = 1024




# # #w10a1
BASE_DIR = "model/expert_w10a1"   # 保存新模型的目录
EXPERT_COMPUTE_COUNT = 2         #专家计算的个数
USE_EXPERT = True
TOKEN_DIMS = 1024
HIDDEN_DIMS = 256
NPU_MAX_TOKEN_COUNT = 172
N_DIMS       = 1024             # 每 token 特征维度
NUM_EXPERTS  = 96               # 专家的个数
TOP_K        = 8                # 每个 token 被路由到的专家数
TOKEN_COUNT = 2048



# int8 量化值域
INT8_QMIN = np.iinfo(np.int8).min   # -128
INT8_QMAX = np.iinfo(np.int8).max   # 127


def round_away_from_zero(data):
    return np.sign(data) * np.floor(np.abs(data) + 0.5)

# 计算量化参数
# symmetric=True  : 对称量化, scale = max(|x_min|,|x_max|) / QMAX, zero_point = 0
# symmetric=False : 非对称量化, scale 由 x_min/x_max 的完整范围均分到 [QMIN, QMAX]
def compute_quant_params(data, symmetric=True):
    x_min = float(data.min())
    x_max = float(data.max())
    print(f"min:{x_min}   max:{x_max}")
    if symmetric:
        scale = max(abs(x_min), abs(x_max)) / INT8_QMAX
        zero_point = 0
    else:
        scale = (x_max - x_min) / (INT8_QMAX - INT8_QMIN)
        zero_point = INT8_QMIN - int(round_away_from_zero(x_min / scale))
        zero_point = int(np.clip(zero_point, INT8_QMIN, INT8_QMAX))

    #scale只保留5位有效数字
    if scale > 0:
        exp = math.floor(math.log10(abs(scale)))
        step = 10.0 ** (exp - 4)
        scale = float(np.ceil(scale / step) * step)
        
    if scale <= 0.0:
        scale = 1.0
    return scale, zero_point


# 对数据做 int8 量化
# 给定 scale 时按给定参数量化；未给定时统计数据范围自动计算量化参数
# symmetric 仅影响自动计算参数的行为，对称/非对称可选
def int8_quantize(data, scale=None, zero_point=None, symmetric=True):
    x = np.asarray(data, dtype=np.float32)
    if scale is None:
        scale, zero_point = compute_quant_params(x, symmetric)
    elif zero_point is None:
        zero_point = 0

    q = round_away_from_zero(x / scale + zero_point)
    q = np.clip(q, INT8_QMIN, INT8_QMAX).astype(np.int8)
    return q, scale, zero_point


def to_np128(data, num_tokens, n_dims):
    data = data.reshape((num_tokens, n_dims))
    data = data.transpose((1, 0))
    data = data.reshape(n_dims // 128, 128, num_tokens)
    data = data.transpose(0, 2, 1)
    if data.shape[1] == 1: #for generate golden result, 1 pad to 2
        data = np.pad(data, ((0, 0), (0, 1), (0, 0)), mode="constant", constant_values=0)
    return data


# 从 router 矩阵扫描当前专家的 (token_id, weight)
def scan_expert_tokens(router_matrix, expert_id):
    expert_row = router_matrix[expert_id]
    token_ids  = np.nonzero(expert_row)[0]
    weights    = expert_row[token_ids]
    return token_ids, weights


# 专家计算
def expert_forward(input_data, num_tokens, expert_onnx_model=""):
    # print(input_data.shape)
    if expert_onnx_model != "":
        import onnxruntime as ort
        input_data_1 = input_data.transpose((1, 0))
        input_data_1 = input_data_1.reshape((1, N_DIMS, 1, num_tokens))
        input_data_1 = input_data_1.astype(np.float32)
        so = ort.SessionOptions()
        so.log_severity_level = 3
        session = ort.InferenceSession(expert_onnx_model, so)
        input_name_0 = session.get_inputs()[0].name
        input_data_map = {input_name_0: input_data_1}
        outputs = session.run(None, input_data_map)[0]
        outputs = outputs.transpose(0, 3, 2, 1)
        outputs = outputs.reshape(num_tokens, N_DIMS)
        print("expert result: ", np.min(outputs), np.max(outputs))
        return outputs
    return input_data


# 生成 router 矩阵 (NUM_EXPERTS, num_tokens), 非零值 = 权重
#每个 token 只被路由到 8 个专家" 每个 token 分给它所选 8 个专家的权重之和 = 1.0
def build_router_matrix(rng, num_tokens):
    router_matrix = np.zeros((NUM_EXPERTS, num_tokens), dtype=np.float32)
    routing_scores = rng.random((NUM_EXPERTS, num_tokens), dtype=np.float32)
    topk_experts = np.argpartition(-routing_scores, TOP_K, axis=0)[:TOP_K]
    for token_id in range(num_tokens):
        selected_experts = topk_experts[:, token_id]
        raw_weights = np.exp(routing_scores[selected_experts, token_id])
        router_matrix[selected_experts, token_id] = raw_weights / raw_weights.sum()
    router_matrix = router_matrix.astype(np.float16)
    return router_matrix




def rename_model_file(path, new_number):
    import re
    import os
    """
    将文件名中所有数字替换为指定数字
    例: model_1_qdq.onnx -> model_5_qdq.onnx
        expert_w10a1/model_3.onnx -> expert_w10a1/model_5.onnx
    """
    dir_name = os.path.dirname(path)
    file_name = os.path.basename(path)
    
    # 替换文件名中所有连续数字
    new_file_name = re.sub(r'\d+', str(new_number), file_name)
    new_path = os.path.join(dir_name, new_file_name)
    
    return new_path

def modify_infershape(model_path, origin, new):
    import onnx
    m = onnx.load(model_path)

    for io in list(m.graph.input) + list(m.graph.output):
        dims = io.type.tensor_type.shape.dim
        if dims[-1].HasField("dim_value") and dims[-1].dim_value == origin:
            dims[-1].dim_value = new
            
    for vi in m.graph.value_info:
        dims = vi.type.tensor_type.shape.dim
        if len(dims) > 0 and dims[-1].HasField("dim_value") and dims[-1].dim_value == origin:
            dims[-1].dim_value = new

    m = onnx.shape_inference.infer_shapes(m, strict_mode=True, data_prop=True)
    onnx.checker.check_model(m)
    
    onnx.save(m, rename_model_file(model_path, new))



def read_quant_params(txt_path):
    """读取 txt 文件中的量化参数"""
    params = {}
    with open(txt_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or ':' not in line:
                continue
            key, value = line.split(':', 1)
            key = key.strip()
            value = value.strip()
            # 尝试转成数字
            try:
                if '.' in value or 'e' in value.lower():
                    params[key] = float(value)
                else:
                    params[key] = int(value)
            except ValueError:
                params[key] = value
    return params


def compare_arrays(arr1, arr2, print_results=True):

    if arr1.shape != arr2.shape:
        raise ValueError("数据shape不同")
    
    a1 = arr1.astype(np.float64)
    a2 = arr2.astype(np.float64)
    
    flat1 = a1.ravel()
    flat2 = a2.ravel()
    
    mean1 = np.mean(flat1)
    mean2 = np.mean(flat2)
    var1 = np.var(flat1)
    var2 = np.var(flat2)
    
    error = flat1 - flat2
    mae = np.mean(np.abs(error))                # 平均绝对误差
    max_abs_error = np.max(np.abs(error))       # 最大绝对误差
    
    tol = 1e-8
    nonzero_ratio = np.count_nonzero(np.abs(error) > tol) / error.size
    
    norm1 = np.linalg.norm(flat1)
    norm2 = np.linalg.norm(flat2)
    if norm1 == 0 or norm2 == 0:
        cosine_sim = 0.0
    else:
        cosine_sim = np.dot(flat1, flat2) / (norm1 * norm2)
    
    results = {
        "mean_arr1": mean1,
        "mean_arr2": mean2,
        "variance_arr1": var1,
        "variance_arr2": var2,
        "mean_absolute_error": mae,
        "max_absolute_error": max_abs_error,
        "nonzero_error_ratio": nonzero_ratio,
        "cosine_similarity": cosine_sim,
    }
    
    if print_results:
        print("========== 数组对比结果 ==========")
        print(f"数组1 均值: {mean1:.6f}")
        print(f"数组2 均值: {mean2:.6f}")
        print(f"数组1 方差: {var1:.6f}")
        print(f"数组2 方差: {var2:.6f}")
        print(f"平均绝对误差 (MAE): {mae:.6f}")
        print(f"最大绝对误差: {max_abs_error:.6f}")
        print(f"误差非零比例: {nonzero_ratio:.2%}")
        print(f"余弦相似度: {cosine_sim:.6f}")
        print("===================================")
    
    return results

