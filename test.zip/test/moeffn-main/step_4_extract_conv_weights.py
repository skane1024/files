"""从 model_172_qdq.onnx 中提取两个 Conv 的 int8 权重及量化参数。

输出 (与模型同目录):
  weight1_int8.bin / weight2_int8.bin : int8 权重原始数据
  scale1.bin / scale2.bin             : float32 per-channel scale
  zero1.bin / zero2.bin               : int32 zero point
  zero1_int8.bin / zero2_int8.bin     : int8 zero point
"""

import os
import numpy as np
import onnx
from common import *


MODEL_PATH = os.path.join(BASE_DIR, f"expert_{NPU_MAX_TOKEN_COUNT}_qdq.onnx")
OUT_DIR = os.path.join(os.path.dirname(MODEL_PATH),"model_bin")

def to_file(arr: np.ndarray, name: str) -> None:
    path = os.path.join(OUT_DIR, name)
    arr.tofile(path)
    print(f"{name}: shape={arr.shape} dtype={arr.dtype} size={arr.nbytes} bytes")

def main() -> None:
    model = onnx.load(MODEL_PATH)
    inits = {i.name: i for i in model.graph.initializer}

    #  Conv: conv1 (gate_up) 和 conv3 (down)
    conv_nodes = [n for n in model.graph.node if n.op_type == "Conv"]
    assert len(conv_nodes) == 2, f"expected 2 Conv nodes, got {len(conv_nodes)}"
    os.makedirs(OUT_DIR, exist_ok=True)

    for idx, conv in enumerate(conv_nodes, start=1):
        weight_q_name = conv.input[1]  # Conv 的第 2 个输入是权重
        # 量化模型中权重先经过 DequantizeLinear
        dq = next(n for n in model.graph.node if n.op_type == "DequantizeLinear" and n.output[0] == weight_q_name)
        w_q = onnx.numpy_helper.to_array(inits[dq.input[0]])
        scale = onnx.numpy_helper.to_array(inits[dq.input[1]]).astype(np.float32)
        zero = onnx.numpy_helper.to_array(inits[dq.input[2]])

        assert w_q.dtype == np.int8, f"conv{idx} weight dtype is {w_q.dtype}"
        to_file(w_q.reshape(-1).astype(np.int8), f"weight{idx}_int8.bin")
        to_file(scale, f"scale{idx}.bin")
        to_file(zero.astype(np.int32), f"zero{idx}.bin")
        to_file(zero.astype(np.int8), f"zero{idx}_int8.bin")
        print(f"conv{idx} ({conv.name}): weight {w_q.shape}, "
              f"scale/zero per-channel count {scale.size}")


if __name__ == "__main__":
    main()
