# 模拟 NPU 在 generation 阶段的 MoE FFN 计算流程, 并与 step_5 生成的 golden 对比
#
# 硬件行为:
#   1. token 输入为 int8;
#   2. router 权重为 float16, 遍历所有专家, 权重为 0 表示未选中;
#   3. 选中专家时: int8 输入用输入量化参数反量化为浮点 -> 送 QDQ 专家模型计算
#      -> 专家输出用专家输出量化参数(down_gemm_out)量化为 int8 -> 再反量化为浮点;
#   4. 与权重加权后累加; 每累加一次, 用最终输出量化参数把累加结果量化为 int8,
#      下一轮累加前再反量化回浮点(累加器被约束在输出格点上);
#   5. 全部专家算完, 最后一次量化的 int8 即为输出。
import os
import json
import numpy as np
from common import *
from moe_ffn_ref import expert_onnx_forward

GEN_DIR = f"{BASE_DIR}/moe_golden_decoder"


def load_quant_params(path):
    params = {}
    with open(path) as f:
        for line in f:
            key, value = line.split(":")
            params[key.strip()] = float(value)
    return params


def hw_quantize(data, scale, zeropoint):
    q = round_away_from_zero(np.asarray(data, dtype=np.float32) / scale + zeropoint)
    return np.clip(q, INT8_QMIN, INT8_QMAX).astype(np.int8)


def hw_dequantize(q, scale, zeropoint):
    return (np.asarray(q, dtype=np.float32) - zeropoint) * scale


def hw_dequantize_f16(q, scale, zeropoint):
    # 硬件: int8 反量化到 float16
    return ((np.asarray(q, dtype=np.float32) - zeropoint) * scale).astype(np.float16)


def sim_generation_hw():
    # 输入/最终输出量化参数: 取 golden 生成的 quant_params.txt
    params = load_quant_params(f"{GEN_DIR}/quant_params.txt")
    in_scale, in_zeropoint = params["in_scale"], params["in_zeropoint"]
    out_scale, out_zeropoint = params["out_scale"], params["out_zeropoint"]

    # 专家输出量化参数: 取 expert_quant_params.json 的 down_gemm_out
    with open(os.path.join(BASE_DIR, "expert_quant_params.json")) as f:
        exp_out = json.load(f)["down_gemm_out"]
    exp_scale, exp_zeropoint = float(exp_out["scale"]), float(exp_out["zeropoint"])

    # int8 输入 (np128 布局), 只取有效 token 列
    x_np128 = np.fromfile(f"{GEN_DIR}/token_data_np128_int8.bin", dtype=np.int8).reshape(N_DIMS // 128, 2, 128)
    x_int8 = x_np128[:, 0, :].reshape(1, N_DIMS)

    # router 权重, float16
    router = np.fromfile(f"{GEN_DIR}/expert_tokens.bin", dtype=np.float16).reshape(1, NUM_EXPERTS)

    expert_path = os.path.join(BASE_DIR, "expert_1_qdq.onnx")
    # 硬件: int8 输入反量化到 float16, 再送专家计算(onnx 要求 float32 容器, 数值在 fp16 格点上)
    x_float = hw_dequantize_f16(x_int8, in_scale, in_zeropoint).astype(np.float32)

    acc_q = hw_quantize(np.zeros((1, N_DIMS), dtype=np.float32), out_scale, out_zeropoint)
    for expert_id in range(NUM_EXPERTS):
        weight = float(router[0, expert_id])
        if weight == 0.0:
            continue
        y = expert_onnx_forward(x_float, 1, N_DIMS, expert_path)
        # 专家输出量化 int8 -> 反量化 float16
        y_deq_f16 = hw_dequantize_f16(hw_quantize(y, exp_scale, exp_zeropoint), exp_scale, exp_zeropoint)
        # 累加器 int8 -> float16 -> float32 加权求和 -> float16 -> 量化 int8
        acc_f32 = hw_dequantize_f16(acc_q, out_scale, out_zeropoint).astype(np.float32) + weight * y_deq_f16.astype(np.float32)
        acc_q = hw_quantize(acc_f32.astype(np.float16), out_scale, out_zeropoint)
        print(f"expert {expert_id} weight {weight}")

    # 组装 np128, pad 区硬件不写, 保持 0
    sim_np128 = np.zeros_like(x_np128)
    sim_np128[:, 0, :] = acc_q.reshape(N_DIMS // 128, 128)
    sim_np128.tofile(f"{GEN_DIR}/sim_result_np128_int8.bin")

    # 与 golden 对比
    golden_np128 = np.fromfile(f"{GEN_DIR}/golden_result_np128_int8.bin", dtype=np.int8).reshape(x_np128.shape)
    diff_valid = sim_np128[:, 0, :].astype(np.int32) - golden_np128[:, 0, :].astype(np.int32)
    diff_pad = sim_np128[:, 1, :].astype(np.int32) - golden_np128[:, 1, :].astype(np.int32)

    print("\n===== 有效 token 列 (int8 LSB) =====")
    print("max abs diff:", np.max(np.abs(diff_valid)), " mean abs diff:", np.mean(np.abs(diff_valid)))
    hist = np.bincount(np.abs(diff_valid).ravel())
    for n, cnt in enumerate(hist):
        if cnt:
            print(f"  |diff| == {n}: {cnt}/{diff_valid.size}")
    print("dequant 后最大浮点误差:", np.max(np.abs(diff_valid)) * out_scale)

if __name__ == "__main__":
    sim_generation_hw()
