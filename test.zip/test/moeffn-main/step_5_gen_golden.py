import os
import numpy as np
from common import *
from moe_ffn_ref import expert_onnx_forward


IN_SCALE = 0.003921568859368563
IN_ZEROPOINT = 0



# prefill 阶段 golden: 1024 token, w72 专家模型, 只计算前 2 个专家
# use_expert=True  : 输入先送专家模型计算, 再加权求和
# use_expert=False : 跳过专家计算, 直接对输入数据加权求和
def gen_prefill_golden(out_dir=BASE_DIR, use_expert=USE_EXPERT):
    prefile_token_count = TOKEN_COUNT
    rng = np.random.default_rng(55)
    expert_path = os.path.join(BASE_DIR, f"expert_{NPU_MAX_TOKEN_COUNT}_qdq.onnx") if use_expert else ""
    os.makedirs(f"{out_dir}/moe_golden_encoder", exist_ok=True)

    # token 数据
    token_data = rng.standard_normal(size=(prefile_token_count, N_DIMS)).astype(np.float32)
    token_data = token_data.clip(-0.5,0.5)
    token_data_float32 = token_data.transpose((1,0)).reshape((1,N_DIMS,1,prefile_token_count))
    token_data_float32.tofile(f"{out_dir}/moe_golden_encoder/token_data_1_{N_DIMS}_1_{prefile_token_count}_f32.bin")

    token_data_np128 = to_np128(token_data, prefile_token_count, N_DIMS)
    # token_data_np128.tofile(f"{out_dir}/token_data_np128_f16.bin")
    os.makedirs(f"{out_dir}/moe_golden_encoder/", exist_ok=True)

    token_data_np128_int8, in_scale, in_zeropoint = int8_quantize(token_data_np128, IN_SCALE, IN_ZEROPOINT)
    token_data_np128_int8.tofile(f"{out_dir}/moe_golden_encoder/token_data_np128_int8.bin")
    print("in scale_zeropoint:", IN_SCALE, IN_ZEROPOINT, np.min(token_data), np.max(token_data))
    # router 矩阵 (NUM_EXPERTS, NUM_TOKENS), 非零值 = 权重
    router_matrix = build_router_matrix(rng, prefile_token_count)
    router_matrix_float32 = router_matrix.astype(np.float32)
    router_matrix_float32.tofile(f"{out_dir}/moe_golden_encoder/expert_tokens_1_1_{NUM_EXPERTS}_{prefile_token_count}_f32.bin")
    router_matrix = router_matrix.astype(np.float16)
    router_matrix.tofile(f"{out_dir}/moe_golden_encoder/expert_tokens.bin")


    #纯浮点计算的golden
    float_golden_result = np.zeros((prefile_token_count, N_DIMS), dtype=np.float32)
    for expert_id in range(EXPERT_COMPUTE_COUNT):
        token_ids, token_weights = scan_expert_tokens(router_matrix, expert_id)
        if len(token_ids) == 0:
            continue
        input_data = token_data[token_ids].astype(np.float32)
        float_golden_result[token_ids] += token_weights[:, None].astype(np.float32) * expert_onnx_forward(input_data, len(token_ids), N_DIMS, expert_path)
    float_golden, out_scale, out_zeropoint = int8_quantize(float_golden_result)



    # golden 结果 (float32 累加, 与 reference 一致)
    golden_result = np.zeros((prefile_token_count, N_DIMS), dtype=np.float32)
    for expert_id in range(EXPERT_COMPUTE_COUNT):
        token_ids, token_weights = scan_expert_tokens(router_matrix, expert_id)
        if len(token_ids) == 0:
            continue
        print(token_ids)
        print(token_weights)
        print(len(token_ids))
        input_data = token_data[token_ids].astype(np.float32)
        input_data = (round_away_from_zero(input_data / in_scale + in_zeropoint) - in_zeropoint) * in_scale
        # token_weights = (round_away_from_zero(token_weights / out_scale + out_zeropoint) - out_zeropoint) * out_scale
        golden_result[token_ids] += token_weights[:, None].astype(np.float32) * expert_onnx_forward(input_data, len(token_ids), N_DIMS, expert_path)

    golden_result_float32 = golden_result.transpose((1,0))
    golden_result_float32.tofile(f"{out_dir}/moe_golden_encoder/golden_result_1_{N_DIMS}_1_{prefile_token_count}_f32.bin")

    golden_result_np128_f16 = to_np128(golden_result.astype(np.float16), prefile_token_count, N_DIMS)
    # golden_result_np128_f16.tofile(f"{out_dir}/golden_result_np128_f16.bin")

    golden_result_np128_int8, out_scale, out_zeropoint = int8_quantize(golden_result_np128_f16, out_scale, out_zeropoint)
    golden_result_np128_int8.tofile(f"{out_dir}/moe_golden_encoder/golden_result_np128_int8.bin")
    print("out scale_zeropoint:", out_scale, out_zeropoint)

    # 将输入/输出量化参数保存到同一个 txt 文件
    with open(f"{out_dir}/moe_golden_encoder/quant_params.txt", "w") as f:
        f.write(f"in_scale: {in_scale}\n")
        f.write(f"in_zeropoint: {in_zeropoint}\n")
        f.write(f"out_scale: {out_scale}\n")
        f.write(f"out_zeropoint: {out_zeropoint}\n")

    return out_scale, out_zeropoint



# generation 阶段 golden: 1 token, w1 专家模型, 计算全部专家, int8/router 数据补零
# use_expert=True  : 输入先送专家模型计算, 再加权求和
# use_expert=False : 跳过专家计算, 直接对输入数据加权求和
def gen_generation_golden(out_dir=BASE_DIR, use_expert=USE_EXPERT):
    gen_token_count = 1
    rng = np.random.default_rng(55)
    expert_path = os.path.join(BASE_DIR, "expert_1_qdq.onnx") if use_expert else ""
    os.makedirs(out_dir, exist_ok=True)
    # 生成随机的输入数据 token 数据
    token_data = rng.standard_normal(size=(gen_token_count, N_DIMS)).astype(np.float32)
    token_data = token_data.clip(-0.3,0.3)
    os.makedirs(f"{out_dir}/moe_golden_decoder/", exist_ok=True)


    token_data_float32 = token_data.transpose((1,0)).reshape((1,N_DIMS,1,gen_token_count))
    token_data_float32.tofile(f"{out_dir}/moe_golden_decoder/token_data_1_{N_DIMS}_1_{gen_token_count}_f32.bin")

    token_data_np128 = to_np128(token_data, gen_token_count, N_DIMS)
    # token_data_np128.tofile(f"{out_dir}/token_data_np128_f16.bin")


    token_data_np128_int8, in_scale, in_zeropoint = int8_quantize(token_data_np128, IN_SCALE, IN_ZEROPOINT, symmetric=False)
    token_data_np128_int8.tofile(f"{out_dir}/moe_golden_decoder/token_data_np128_int8.bin")
    # token_data_np128_int8_pad = np.pad(token_data_np128_int8.reshape(-1),((0, 1024*3072)), mode="constant", constant_values=0)
    # token_data_np128_int8_pad.tofile(f"{out_dir}/moe_golden_decoder/token_data_np128_int8_pad.bin")
    print("in scale_zeropoint:", in_scale, in_zeropoint, np.min(token_data), np.max(token_data))

    # router 矩阵 (NUM_EXPERTS, gen_token_count), 非零值 = 权重
    router_matrix = build_router_matrix(rng, gen_token_count)
    router_matrix_float32 = router_matrix.astype(np.float32)
    router_matrix_float32.tofile(f"{out_dir}/moe_golden_decoder/expert_tokens_1_1_{NUM_EXPERTS}_{gen_token_count}_f32.bin")
    router_matrix.tofile(f"{out_dir}/moe_golden_decoder/expert_tokens.bin")
    # router_matrix_pad = np.pad(router_matrix.reshape(-1),((0, 116*1024)), mode="constant", constant_values=0)
    # router_matrix_pad.tofile(f"{out_dir}/moe_golden_decoder/expert_tokens_pad.bin")

    #纯浮点计算的golden
    float_result_int8, out_scale, out_zeropoint = int8_quantize(expert_onnx_forward(token_data[0], 1, N_DIMS, expert_path), symmetric=False)
    print(out_scale)
    print(out_zeropoint)



    # golden 结果 考虑量化反量化的误差
    golden_result = np.zeros((gen_token_count, N_DIMS), dtype=np.float32)
    for expert_id in range(NUM_EXPERTS):
        token_ids, token_weights = scan_expert_tokens(router_matrix, expert_id)
        if len(token_ids) == 0:
            continue
        print(expert_id, token_weights)
        input_data = token_data[token_ids]
        input_data = (round_away_from_zero(input_data / in_scale + in_zeropoint) - in_zeropoint) * in_scale
        # router 权重为 float 数据, 不做量化, 直接乘专家结果
        golden_result[token_ids] += token_weights[:, None] * expert_onnx_forward(input_data, len(token_ids), N_DIMS, expert_path)
        # print(np.min(golden_result), np.max(golden_result))

    golden_result_float32 = golden_result.transpose((1,0))
    golden_result_float32.tofile(f"{out_dir}/moe_golden_decoder/golden_result_1_{N_DIMS}_1_{gen_token_count}_f32.bin")

    golden_result_np128 = to_np128(golden_result.astype(np.float16), gen_token_count, N_DIMS)
    # golden_result_np128.tofile(f"{out_dir}/golden_result_np128_f16.bin")

    # 输出量化参数按真实 golden 结果范围统计(非对称), 用 fp16 数据统计避免 fp16 舍入导致的截断
    out_scale, out_zeropoint = compute_quant_params(golden_result.astype(np.float16), symmetric=False)
    golden_result_np128_int8 = int8_quantize(golden_result_np128, out_scale, out_zeropoint, symmetric=False)[0]
    golden_result_np128_int8.tofile(f"{out_dir}/moe_golden_decoder/golden_result_np128_int8.bin")
    print("out scale_zeropoint:", out_scale, out_zeropoint)
    # 饱和检查: 舍入后仍超出 int8 值域(被 clip)的点
    q_check = round_away_from_zero(golden_result_np128.astype(np.float32)/out_scale + out_zeropoint)
    clip_hi = np.count_nonzero(q_check > INT8_QMAX)
    clip_lo = np.count_nonzero(q_check < INT8_QMIN)
    print("clip high/low:", clip_hi, clip_lo, " golden min/max:", np.min(golden_result), np.max(golden_result))

    # 将输入/输出量化参数保存到同一个 txt 文件
    with open(f"{out_dir}/moe_golden_decoder/quant_params.txt", "w") as f:
        f.write(f"in_scale: {in_scale}\n")
        f.write(f"in_zeropoint: {in_zeropoint}\n")
        f.write(f"out_scale: {out_scale}\n")
        f.write(f"out_zeropoint: {out_zeropoint}\n")


if __name__ == "__main__":
    gen_prefill_golden()
    print("\n\n\n\n")
    gen_generation_golden()
