"""对比两个 ONNX 模型的推理输出的数值差异。
"""
import numpy as np
import onnxruntime as ort
from common import compare_arrays

MODEL_A = "expert_new/expert_72_qdq.onnx"   ##需要确保输入数据范围和量化模型时的输入范围一致
MODEL_B = "expert_new/expert_72.onnx"

SEED = 42

def main():
    sess_a = ort.InferenceSession(MODEL_A, providers=["CPUExecutionProvider"])
    sess_b = ort.InferenceSession(MODEL_B, providers=["CPUExecutionProvider"])

    in_a = sess_a.get_inputs()[0]
    in_b = sess_b.get_inputs()[0]
    print("模型A 输入:", in_a.name, in_a.shape, "类型:", in_a.type)
    print("模型B 输入:", in_b.name, in_b.shape, "类型:", in_b.type)
    
    assert in_a.shape == in_b.shape
    assert in_a.type == in_b.type

    rng = np.random.default_rng(SEED)
    input = rng.standard_normal(in_a.shape).astype(np.float32)
    input = input.clip(-0.5,0.5) #需要确保输入数据范围和量化模型时的输入范围一致
    out_a = np.asarray(sess_a.run(None, {in_a.name: input})[0])
    out_b = np.asarray(sess_b.run(None, {in_b.name: input})[0])
    
    print("输出A:", out_a.shape, out_a.dtype)
    print("输出B:", out_b.shape, out_b.dtype)

    compare_arrays(out_a, out_b)


if __name__ == "__main__":
    main()