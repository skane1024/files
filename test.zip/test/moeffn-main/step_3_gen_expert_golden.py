import os
import numpy as np
from common import *
import json
from moe_ffn_ref import expert_onnx_forward


expert_quant_json_file_path = os.path.join(BASE_DIR, "expert_quant_params.json")
with open(expert_quant_json_file_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

IN_SCALE     = data["gate_up_gemm_in"]["scale"]
IN_ZEROPOINT = data["gate_up_gemm_in"]["zeropoint"]
OUT_SCALE     = data["down_gemm_out"]["scale"]
OUT_ZEROPOINT = data["down_gemm_out"]["zeropoint"]


def gen_prefill_golden():
    NUM_TOKENS = NPU_MAX_TOKEN_COUNT
    rng = np.random.default_rng(55)
    expert_path = os.path.join(BASE_DIR, f"expert_{NPU_MAX_TOKEN_COUNT}_qdq.onnx")
    os.makedirs(os.path.join(BASE_DIR, "expert_golden"), exist_ok=True)
    token_data = rng.standard_normal(size=(NUM_TOKENS, TOKEN_DIMS)).astype(np.float16)
    token_data = token_data.clip(-0.5,0.5)
    token_data_np128 = to_np128(token_data, NUM_TOKENS, TOKEN_DIMS)
    token_data_f32 = token_data.astype(np.float32)
    token_data_f32.tofile(f"{BASE_DIR}/expert_golden/expert_{NUM_TOKENS}_in_float32.bin")

    token_data_np128_int8, in_scale, in_zeropoint = int8_quantize(token_data_np128, IN_SCALE, IN_ZEROPOINT)
    token_data_np128_int8.tofile(f"{BASE_DIR}/expert_golden/expert_{NUM_TOKENS}_in_np128_int8.bin")

    golden_result_f16 = expert_onnx_forward(token_data, NUM_TOKENS, TOKEN_DIMS, expert_path)

    golden_result_np128_f16 =  to_np128(golden_result_f16, NUM_TOKENS, TOKEN_DIMS)
    golden_result_np128_int8, out_scale, out_zeropoint = int8_quantize(golden_result_np128_f16, OUT_SCALE, OUT_ZEROPOINT)
    golden_result_np128_int8.tofile(f"{BASE_DIR}/expert_golden/expert_{NUM_TOKENS}_out_np128_int8.bin")
    
    golden_result_f32 = golden_result_f16.astype(np.float32)
    golden_result_f32.tofile(f"{BASE_DIR}/expert_golden/expert_{NUM_TOKENS}_out_float32.bin")
    
    
def gen_generation_golden():
    NUM_TOKENS = 1
    rng = np.random.default_rng(55)
    expert_path = os.path.join(BASE_DIR, f"expert_{NUM_TOKENS}_qdq.onnx")
    os.makedirs(os.path.join(BASE_DIR, "expert_golden"), exist_ok=True)
    token_data = rng.standard_normal(size=(NUM_TOKENS, TOKEN_DIMS)).astype(np.float16)
    token_data = token_data.clip(-0.5,0.5)
    token_data_np128 = to_np128(token_data, NUM_TOKENS, TOKEN_DIMS)
    
    token_data_f32 = token_data.astype(np.float32)
    token_data_f32.tofile(f"{BASE_DIR}/expert_golden/expert_{NUM_TOKENS}_in_float32.bin")

    token_data_np128_int8, in_scale, in_zeropoint = int8_quantize(token_data_np128, IN_SCALE, IN_ZEROPOINT)
    token_data_np128_int8.tofile(f"{BASE_DIR}/expert_golden/expert_{NUM_TOKENS}_in_np128_int8.bin")

    golden_result_f16 = expert_onnx_forward(token_data, NUM_TOKENS, TOKEN_DIMS, expert_path)

    golden_result_np128_f16 =  to_np128(golden_result_f16, NUM_TOKENS, TOKEN_DIMS)
    golden_result_np128_int8, out_scale, out_zeropoint = int8_quantize(golden_result_np128_f16, OUT_SCALE, OUT_ZEROPOINT)
    golden_result_np128_int8.tofile(f"{BASE_DIR}/expert_golden/expert_{NUM_TOKENS}_out_np128_int8.bin")
    
    golden_result_f32 = golden_result_f16.astype(np.float32)
    golden_result_f32.tofile(f"{BASE_DIR}/expert_golden/expert_{NUM_TOKENS}_out_float32.bin")

if __name__ == "__main__":
    gen_prefill_golden()
    gen_generation_golden()
