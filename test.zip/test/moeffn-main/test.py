import numpy as np

data = np.fromfile("/home/yongkang.shu/NPU_IN_VDSP/moeffn-main/out_img_cast1_r1_i0.out", dtype = np.int8)[:3072 * 2 *17]
data = data.reshape((17,3072*2))
data1 = data[1,:]
data1.tofile("/home/yongkang.shu/NPU_IN_VDSP/moeffn-main/np_input_1.out")
data1 = data[2,:]
data1.tofile("/home/yongkang.shu/NPU_IN_VDSP/moeffn-main/np_output_1.out")

# data1 = data[3,:]
# data1.tofile("/home/yongkang.shu/NPU_IN_VDSP/moeffn-main/np_output_2.out")
# data1 = data[4,:]
# data1.tofile("/home/yongkang.shu/NPU_IN_VDSP/moeffn-main/np_output_3.out")


# data1 = data[5,:]
# data1.tofile("/home/yongkang.shu/NPU_IN_VDSP/moeffn-main/np_output_4.out")
# data1 = data[6,:]
# data1.tofile("/home/yongkang.shu/NPU_IN_VDSP/moeffn-main/np_output_5.out")


# data1 = data[7,:]
# data1.tofile("/home/yongkang.shu/NPU_IN_VDSP/moeffn-main/np_output_6.out")
# data1 = data[8,:]
# data1.tofile("/home/yongkang.shu/NPU_IN_VDSP/moeffn-main/np_output_7.out")
import onnxruntime as ort


input_float = np.fromfile("/home/yongkang.shu/NPU_IN_VDSP/moeffn-main/model/expert_w50a5/moe_golden_decoder/token_data_1_3072_1_1_f32.bin", dtype = np.float32)
input_float = input_float.reshape(1,3072,1,1)
print(np.min(input_float))
print(np.max(input_float))


sess_a = ort.InferenceSession("/home/yongkang.shu/NPU_IN_VDSP/moeffn-main/model/expert_w50a5/expert_1_qdq.onnx", providers=["CPUExecutionProvider"])
result = sess_a.run(None, {"gate_up_gemm_in": input_float})[0]

print(np.min(result))
print(np.max(result))

print((np.max(result) - np.min(result))/256)

# # result = (result / 0.002810429083183408) + 86
# # print(result)

# result = (result / 0.0005180100000000001) + 24
# print(result)



# # npu_out = data[2,:].reshape(1,3072*2)
# # print(npu_out)
# npu_out = (npu_out.astype(np.float32)  - 86) * 0.002810429083183408
# print(np.min(npu_out))
# print(np.max(npu_out))


# print(0.1259 + 0.12103 + 0.1302 + 0.129+ 0.11945 + 0.1241 + 0.12244 + 0.1279)




