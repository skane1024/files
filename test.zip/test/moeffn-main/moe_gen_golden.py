import os
import math
import numpy as np
import onnxruntime as ort
from common import compare_arrays


DATA_DIR = "model/expert_w50a5"   # 默认测试数据目录

EXPERT_COMPUTE_COUNT = 2          # prefill 阶段实际只算前 2 个有 token 的专家


# 计算量化参数
# symmetric=True  : 对称量化, scale = max(|x_min|,|x_max|) / QMAX, zero_point = 0
# symmetric=False : 非对称量化, scale 由 x_min/x_max 的完整范围均分到 [QMIN, QMAX]

INT8_QMIN = np.iinfo(np.int8).min   # -128
INT8_QMAX = np.iinfo(np.int8).max   # 127

def round_away_from_zero(data):
    return np.sign(data) * np.floor(np.abs(data) + 0.5)

def compute_quant_params(data, symmetric=True):
    x_min = float(data.min())
    x_max = float(data.max())
    print(f"min:{x_min}   max:{x_max}")
    if symmetric:
        scale = max(abs(x_min), abs(x_max)) / INT8_QMAX
        zero_point = 0
    else:
        scale = (x_max - x_min) / (INT8_QMAX - INT8_QMIN)
        zero_point = INT8_QMIN - int(round_away_from_zero(x_min / scale))
        zero_point = int(np.clip(zero_point, INT8_QMIN, INT8_QMAX))

    #scale只保留5位有效数字
    if scale > 0:
        exp = math.floor(math.log10(abs(scale)))
        step = 10.0 ** (exp - 4)
        scale = float(np.ceil(scale / step) * step)

    if scale <= 0.0:
        scale = 1.0
    return scale, zero_point

# 专家形式 A: ONNX 模型推理
# 模型输入/输出形状 (1, n_dims, 1, max_tokens), float32
# 模型 token 维固定 (w72/w1), token 数超过上限时分块推理;
# 最后一块不足 max_tokens 时补零送入, 推理后丢弃补零部分
# (专家 FFN 无跨 token 计算, 分块与整批结果逐 token 一致)
def expert_onnx_forward(input_data, num_tokens, n_dims, expert_model_path):
    if expert_model_path == "":
        return input_data
    x = np.asarray(input_data, dtype=np.float32)
    if x.ndim == 1:
        x = x[None, :]
    so = ort.SessionOptions()
    so.log_severity_level = 3
    session = ort.InferenceSession(expert_model_path, so)
    input_name = session.get_inputs()[0].name
    max_tokens = session.get_inputs()[0].shape[3]
    if not isinstance(max_tokens, int) or max_tokens is None:   # 动态轴模型, 一次送入
        max_tokens = num_tokens

    results = []
    for start in range(0, num_tokens, max_tokens):
        chunk = x[start:start + max_tokens]
        n = chunk.shape[0]
        if n < max_tokens:
            pad = np.zeros((max_tokens, n_dims), dtype=np.float32)
            pad[:n] = chunk
            chunk = pad
        inp = chunk.T.reshape(1, n_dims, 1, max_tokens)
        out = session.run(None, {input_name: inp})[0]
        out = out.transpose(0, 3, 2, 1).reshape(max_tokens, n_dims)
        results.append(out[:n])
    return np.concatenate(results, axis=0)


# 从 router 矩阵扫描当前专家的 (token_id, weight)
def scan_expert_tokens(router_matrix, expert_id):
    expert_row = router_matrix[expert_id]
    token_ids  = np.nonzero(expert_row)[0]
    weights    = expert_row[token_ids]
    return token_ids, weights

def _compute_golden(token_dequant, router, expert_model_path_list):
    num_tokens, n_dims = token_dequant.shape
    golden_result = np.zeros((num_tokens, n_dims), dtype=np.float32)
    expert_count = router.shape[0]
    if(num_tokens != 1):
        expert_count = EXPERT_COMPUTE_COUNT
        print(f"使用{expert_count} 个专家参与计算")
    for expert_id in range(expert_count):
        token_ids, token_weights = scan_expert_tokens(router, expert_id)
        if len(token_ids) == 0:
            continue
        print(token_ids, token_weights)
        expert_out = expert_onnx_forward(token_dequant[token_ids], len(token_ids), n_dims,expert_model_path_list[expert_id])
        wcol = token_weights[:, None]
        golden_result[token_ids] += wcol.astype(np.float16) * expert_out.astype(np.float32)
    return golden_result




def moeffn_golden(token_embedding, expert_routing, expert_model_path_list,
                  in_quant_param=None, out_quant_param=None):
    """
    MoE FFN golden 计算, 考虑输入/输出量化反量化的误差。
      token_embedding     : (1, n_dims, 1, num_tokens) float32数据
      expert_routing      : (1, 1, num_experts, num_tokens)  float32 或者float16
      expert_model_path_list : 每个专家的 ONNX 模型路径, 必须一一对应

    输入/输出的量化参数可以给, 也可以不给:
      in_quant_param / out_quant_param : {"scale":.., "zeropoint":..}
          给了  -> 直接用给定参数对输入/输出做量化反量化后计算
          没给  -> 自动按数据范围计算量化参数(对称量化), 再量化反量化计算
    返回:
      golden_result_4d  : float32, (1, n_dims, 1, num_tokens)
      in_quant_param/out_quant_param: 实际使用的量化参数(自动计算时带回给使用者)
    """
    assert token_embedding.dtype == np.float32
    assert len(token_embedding.shape) == 4
    assert token_embedding.shape[0] == 1
    assert token_embedding.shape[2] == 1
    token_embedding =np.squeeze(token_embedding, (0,2))  #(n_dims, num_tokens)
    token_data = token_embedding.transpose((1,0))   #(num_tokens, n_dims)


    assert expert_routing.dtype == np.float32 or expert_routing.dtype == np.float16
    assert len(expert_routing.shape) == 4
    assert expert_routing.shape[0] == 1
    assert expert_routing.shape[1] == 1
    expert_routing = expert_routing.astype(np.float16)
    router =np.squeeze(expert_routing, (0,1))  #(num_experts, num_tokens)
    num_tokens, n_dims = token_data.shape
    num_experts = len(expert_model_path_list)

    if router.shape == (num_experts, num_tokens):
        pass
    else:
        raise ValueError(
            f"expert_routing shape {router.shape} 与 (num_experts={num_experts}, "
            f"num_tokens={num_tokens}) 不匹配, 也无法转置匹配")
    assert len(expert_model_path_list) == num_experts, \
        f"expert_model_path_list 长度 {len(expert_model_path_list)} != 专家数 {num_experts}"


    # ---- 输入量化参数: 给了就用, 没给自动计算 ----
    if in_quant_param is None:
        in_scale, in_zeropoint = compute_quant_params(token_data)
        in_quant_param = {"scale": in_scale, "zeropoint": in_zeropoint}
    else:
        in_scale, in_zeropoint = in_quant_param["scale"], in_quant_param["zeropoint"]
    print(f"moe_ffn in_scale: {in_scale}, moe_ffn in_zeropoint: {in_zeropoint}")
    token_data_deq = (round_away_from_zero(token_data / in_scale + in_zeropoint) - in_zeropoint) * in_scale

    if out_quant_param is None:
        #无输出量化参数，先用浮点计算一遍，计算量化参数
        float_golden = _compute_golden(token_data_deq, router, expert_model_path_list)
        out_scale, out_zeropoint = compute_quant_params(float_golden)
        out_quant_param = {"scale": out_scale, "zeropoint": out_zeropoint}
    else:
        out_scale, out_zeropoint = out_quant_param["scale"], out_quant_param["zeropoint"]
    print(f"moe_ffn out_scale: {out_scale}, moe_ffn out_zeropoint: {out_zeropoint}")

    golden_result = _compute_golden(token_data_deq, router, expert_model_path_list)
    print(f"min {np.min(golden_result.reshape(-1))},   max{np.max(golden_result.reshape(-1))}")

    golden_result_4d = golden_result.T.reshape(1, n_dims, 1, num_tokens).astype(np.float32)
    return golden_result_4d, in_quant_param, out_quant_param




def test_encoder():
    encoder_dir = f"{DATA_DIR}/moe_golden_encoder"
    n_dims = 3072
    num_experts = 116

    in_quant_param = {"scale": 0.0039371, "zeropoint": 0}
    out_quant_param = {"scale": 0.0002164, "zeropoint": 0}
    expert_paths = [f"{DATA_DIR}/expert_72_qdq.onnx"] * num_experts
    token_float_4d =  np.fromfile(f"{encoder_dir}/token_data_1_3072_1_1024_f32.bin", np.float32).reshape((1,3072,1,1024))
    router_float_4d = np.fromfile(f"{encoder_dir}/expert_tokens_1_1_116_1024_f32.bin", np.float32).reshape((1,1,116,1024))
    output, in_quant_param, out_quant_param = moeffn_golden(token_float_4d, router_float_4d, expert_paths,in_quant_param,out_quant_param)
    golden_ref = np.fromfile(f"{encoder_dir}/golden_result_1_3072_1_1024_f32.bin", np.float32).reshape((1,3072,1,1024))
    compare_arrays(golden_ref, output)


def test_decoder():
    decoder_dir = f"{DATA_DIR}/moe_golden_decoder"
    num_experts = 116
    in_quant_param = {"scale": 0.003921568859368563, "zeropoint": 0}
    out_quant_param = {"scale":0.00020941, "zeropoint": 33}
    token_float_4d =  np.fromfile(f"{decoder_dir}/token_data_1_3072_1_1_f32.bin", np.float32).reshape((1,3072,1,1))
    router_float_4d = np.fromfile(f"{decoder_dir}/expert_tokens_1_1_116_1_f32.bin", np.float32).reshape((1,1,116,1))
    expert_paths = [f"{DATA_DIR}/expert_1_qdq.onnx"] * num_experts  #用的同一个专家
    golden_ref = np.fromfile(f"{decoder_dir}/golden_result_1_3072_1_1_f32.bin", np.float32).reshape((1,3072,1,1))
    #如果in_quant_param和out_quant_param为NONE，内部会计算量化参数，模拟量化的计算
    output_d, in_quant_param, out_quant_param = moeffn_golden(token_float_4d, router_float_4d, expert_paths ,in_quant_param, out_quant_param)
    compare_arrays(golden_ref, output_d)



if __name__ == "__main__":
    test_encoder()
    test_decoder()